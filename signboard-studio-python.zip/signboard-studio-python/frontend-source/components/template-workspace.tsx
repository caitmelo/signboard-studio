"use client";
import {useEffect,useRef,useState} from 'react';
import {Plus,X,FileText,Check} from 'lucide-react';
import {TemplateBuilder} from './template-builder';
import {SavedTemplateEditor} from './saved-template-editor';
import {Button} from './ui/button';
import {MAX_PDF_BYTES} from '@/lib/pdf-upload';
type DesignTab={id:string;name:string;file?:File;visited:boolean;savedId?:string};
export function TemplateWorkspace(){
 const[tabs,setTabs]=useState<DesignTab[]>([{id:'initial',name:'New design',visited:true}]),[active,setActive]=useState('initial'),[error,setError]=useState('');const picker=useRef<HTMLInputElement>(null);
 const dirty=tabs.some(t=>!t.savedId&&(t.file||t.name!=='New design'));
 useEffect(()=>{if(!dirty)return;const warn=(e:BeforeUnloadEvent)=>{e.preventDefault();e.returnValue='';};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty]);
 function add(files:File[]){const accepted=files.filter(f=>f.name.toLowerCase().endsWith('.pdf')&&f.size<=MAX_PDF_BYTES);const rejected=files.filter(f=>!accepted.includes(f));setError(rejected.length?`Could not add: ${rejected.map(f=>f.name).join(', ')}. Choose PDFs up to 150 MB each.`:'');if(!accepted.length)return;
  const added=accepted.map((file,i)=>({id:crypto.randomUUID(),name:file.name,file,visited:i===0}));setTabs(current=>[...current.filter(t=>t.file||t.savedId||t.name!=='New design'),...added]);setActive(added[0].id);
 }
 function select(id:string){setActive(id);setTabs(ts=>ts.map(t=>t.id===id?{...t,visited:true}:t));}
 function close(t:DesignTab){if(!t.savedId&&(t.file||t.name!=='New design')&&!window.confirm('Close this design? Unsaved edits in this tab will be lost.'))return;const next=tabs.filter(x=>x.id!==t.id);if(!next.length){setTabs([{id:'initial',name:'New design',visited:true}]);setActive('initial');return;}setTabs(next);if(active===t.id)select(next[Math.min(tabs.indexOf(t),next.length-1)].id);}
 return <div className="pdf-tab-workspace"><div className="pdf-tab-bar"><div className="pdf-tab-list" role="tablist" aria-label="PDF designs" onKeyDown={e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const i=tabs.findIndex(t=>t.id===active),n=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;select(tabs[n].id);document.getElementById(`design-tab-${tabs[n].id}`)?.focus();}}>{tabs.map(t=><div className={`pdf-design-tab ${active===t.id?'active':''}`} key={t.id}><button id={`design-tab-${t.id}`} type="button" role="tab" aria-selected={active===t.id} aria-controls={`design-panel-${t.id}`} tabIndex={active===t.id?0:-1} onClick={()=>select(t.id)} title={t.name}>{t.savedId?<Check size={15}/>:<FileText size={15}/>}<span>{t.name}</span></button><button type="button" className="pdf-tab-close" aria-label={`Close ${t.name}`} onClick={()=>close(t)}><X size={14}/></button></div>)}</div><Button variant="ghost" className="pdf-add-tab" onClick={()=>picker.current?.click()}><Plus size={16}/>Add PDFs</Button><input ref={picker} type="file" multiple accept="application/pdf,.pdf" className="sr-only" onChange={e=>{add(Array.from(e.target.files??[]));e.target.value='';}}/></div>{error&&<div className="notice error" role="alert">{error}</div>}{tabs.map(t=><div key={t.id} id={`design-panel-${t.id}`} role="tabpanel" aria-labelledby={`design-tab-${t.id}`} hidden={active!==t.id}>{t.visited&&(t.savedId?<SavedTemplateEditor id={t.savedId}/>:<TemplateBuilder initialFile={t.file} onFiles={add} onNameChange={name=>setTabs(ts=>ts.map(x=>x.id===t.id?{...x,name}:x))} onSaved={savedId=>setTabs(ts=>ts.map(x=>x.id===t.id?{...x,savedId}:x))}/>)}</div>)}</div>;
}
