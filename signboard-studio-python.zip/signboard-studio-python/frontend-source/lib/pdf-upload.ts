import {PDFDocument} from 'pdf-lib';
import {PAPER_SIZES} from './print-specs';
export const MAX_PDF_BYTES=150*1024*1024;
// Structural compression is lossless: images, fonts, vectors and colour
// profiles are not rasterised, downsampled or recompressed with JPEG loss.
export async function optimisePdf(data:Uint8Array,fileName=''){
 if(data.length>MAX_PDF_BYTES)throw new Error('This PDF exceeds the 150 MB processing limit.');
 const paper=fileName.match(/\b(a[0-6]|dlx?)\b/i)?.[1].toLowerCase();
 const preparePaper=paper&&!/letter/i.test(fileName);
 if(data.length<20*1024*1024&&!preparePaper)return data;
 const doc=await PDFDocument.load(data,{updateMetadata:false});
 let trimmed=false;
 if(preparePaper){const [short,long]=PAPER_SIZES[paper];for(const page of doc.getPages()){
  const w=page.getWidth()*25.4/72,h=page.getHeight()*25.4/72,tri=/tri[ -]?fold/i.test(fileName);
  const fw=w>h?(tri?short*3-1:long):(tri?long:short),fh=w>h?(tri?long:short):(tri?short*3-1:long);
  const mx=(w-fw)/2,my=(h-fh)/2;
  // Recognise a full-size sheet with 3–5 mm uniform surplus bleed. Remove
  // only the excess outside the required 2 mm; retain the entire trim face.
  if(mx>=2.9&&mx<=5.1&&Math.abs(mx-my)<.05&&Math.abs(mx-Math.round(mx))<.05){const cut=(mx-2)*72/25.4,nw=(fw+4)*72/25.4,nh=(fh+4)*72/25.4;page.translateContent(-cut,-cut);page.setMediaBox(0,0,nw,nh);page.setCropBox(0,0,nw,nh);page.setBleedBox(0,0,nw,nh);page.setTrimBox(2*72/25.4,2*72/25.4,fw*72/25.4,fh*72/25.4);trimmed=true;}
 }}
 const compact=await doc.save({useObjectStreams:true,objectsPerTick:50});
 return trimmed||compact.length<data.length?compact:data;
}
async function checked(response:Response){const value=await response.json() as any;if(!response.ok)throw new Error(value.error||'The file could not be saved.');return value;}
export async function uploadTemplateAsset(id:string,key:string,data:Blob){
 const url=`/api/templates/${id}/assets/${key}`;
 if(data.size<=(key==='manifest'?8:20)*1024*1024){await checked(await fetch(url,{method:'PUT',headers:{'Content-Type':data.type},body:data}));return;}
 const runtime=await fetch('/runtime.json').then(r=>r.json() as Promise<{engine:string}>);
 if(runtime.engine==='server-python'){await checked(await fetch(url,{method:'PUT',headers:{'Content-Type':data.type},body:data}));return;}
 const endpoint=url+'/multipart';const {uploadId}=await checked(await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'start',size:data.size})}));
 const parts:any[]=[];try{for(let offset=0;offset<data.size;offset+=8*1024*1024){const partNumber=parts.length+1;parts.push(await checked(await fetch(`${endpoint}?uploadId=${encodeURIComponent(uploadId)}&partNumber=${partNumber}`,{method:'PUT',body:data.slice(offset,offset+8*1024*1024)})));}
 await checked(await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'complete',uploadId,parts})}));
 }catch(e){await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'abort',uploadId})}).catch(()=>{});throw e;}
}
