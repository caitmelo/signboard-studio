import {PDFArray,PDFDict,PDFDocument,PDFName,PDFNumber,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {operations,bytes,latin,multiply} from './pdf-content';

/** Clone changed Form instances so cleaning one corner cannot alter other uses. */
export function cleanCornerMarks(doc:PDFDocument,raw:string,resources:PDFDict,face:{x:number;y:number;width:number;height:number},unit:number,matrix=[1,0,0,1,0,0],depth=0):{raw:string;resources:PDFDict;changed:boolean}{
 if(depth>12)return{raw,resources,changed:false};
 const next=resources.clone(doc.context),xobjects=resources.lookupMaybe(PDFName.of('XObject'),PDFDict)?.clone(doc.context);
 if(xobjects)next.set(PDFName.of('XObject'),xobjects);
 let state={matrix,white:false},stack:typeof state[]=[],rect:number[]|undefined;
 const edits:{start:number;end:number;text:string}[]=[];
 for(const op of operations(raw)){
  const a=op.args.map(t=>Number(t.value));
  if(op.op==='q')stack.push({...state,matrix:[...state.matrix]});else if(op.op==='Q')state=stack.pop()??state;
  else if(op.op==='cm')state.matrix=multiply(state.matrix,a);
  else if(['k','g','rg'].includes(op.op))state.white=op.op==='k'?a.every(v=>v===0):a.every(v=>v===1);
  else if(['cs','sc','scn'].includes(op.op))state.white=false;
  else if(op.op==='re'){const m=state.matrix,p=multiply(m,[1,0,0,1,a[0],a[1]]),q=multiply(m,[1,0,0,1,a[0]+a[2],a[1]+a[3]]);rect=[Math.min(p[4],q[4]),Math.min(p[5],q[5]),Math.abs(p[4]-q[4]),Math.abs(p[5]-q[5])];}
  else if(['m','l','c','v','y'].includes(op.op))rect=undefined;
  else if(['f','f*','B','B*','S','s','n'].includes(op.op)){
   if(rect&&state.white&&['f','f*'].includes(op.op)){const[x,y,w,h]=rect;
    if(w>0&&h>0&&w<12*unit&&h<12*unit&&Math.abs(w-h)<unit&&
      [face.x,face.x+face.width].some(v=>Math.min(Math.abs(v-x),Math.abs(v-x-w))<.2)&&
      [face.y,face.y+face.height].some(v=>Math.min(Math.abs(v-y),Math.abs(v-y-h))<.2))edits.push({start:op.start,end:op.end,text:'n'});
   }rect=undefined;
  }else if(op.op==='Do'&&xobjects){
   const form=xobjects.lookup(PDFName.of(String(op.args[0]?.value)));
   if(!(form instanceof PDFRawStream)||form.dict.get(PDFName.of('Subtype'))?.toString()!=='/Form')continue;
   const fm=form.dict.lookupMaybe(PDFName.of('Matrix'),PDFArray)?.asArray().map(v=>(v as PDFNumber).asNumber())??[1,0,0,1,0,0];
   const child=cleanCornerMarks(doc,latin(decodePDFRawStream(form).decode()),form.dict.lookupMaybe(PDFName.of('Resources'),PDFDict)??resources,face,unit,multiply(state.matrix,fm),depth+1);
   if(child.changed){const replacement=doc.context.flateStream(bytes(child.raw));for(const[k,v]of form.dict.entries())if(!['Length','Filter','DecodeParms','Resources'].includes(k.decodeText()))replacement.dict.set(k,v);replacement.dict.set(PDFName.of('Resources'),child.resources);const ref=doc.context.register(replacement),name=`StudioClean${ref.objectNumber}`;xobjects.set(PDFName.of(name),ref);edits.push({start:op.start,end:op.end,text:`/${name} Do`});}
  }
 }
 for(const e of edits.sort((a,b)=>b.start-a.start))raw=raw.slice(0,e.start)+e.text+raw.slice(e.end);
 return{raw,resources:next,changed:edits.length>0};
}
