import {PDFDocument,PDFName,PDFArray,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {operations,bytes,latin,multiply} from './pdf-content';
import {isSignboard,bleedInsets} from './print-specs';
import type {PrintSpec} from './template-types';
// Only confidently identified printer furniture is removed. Never erase white artwork by colour alone.
export async function prepareSignboard(data:Uint8Array,pageIndex:number,spec:PrintSpec){
 if(!isSignboard(spec))return data;
 const doc=await PDFDocument.load(data,{updateMetadata:false}),page=doc.getPage(pageIndex),trim=page.getTrimBox(),media=page.getMediaBox();
 if(!(trim.x>media.x+.1&&trim.y>media.y+.1&&trim.width<media.width-.2&&trim.height<media.height-.2))return data;
 const unit=Math.min(trim.width/spec.faceWidth,trim.height/spec.faceHeight),fw=spec.faceWidth*unit,fh=spec.faceHeight*unit;
 const face={x:trim.x+(trim.width-fw)/2,y:trim.y+(trim.height-fh)/2,w:fw,h:fh},b=bleedInsets(spec);
 const crop={x:face.x-b.left*unit,y:face.y-b.bottom*unit,w:fw+(b.left+b.right)*unit,h:fh+(b.top+b.bottom)*unit};
 // Do not manufacture missing bleed or stretch artwork to fill it.
 if(crop.x<media.x-.2||crop.y<media.y-.2||crop.x+crop.w>media.x+media.width+.2||crop.y+crop.h>media.y+media.height+.2)return data;
 const content=page.node.Contents(),refs=content instanceof PDFArray?content.asArray():[content];let raw=refs.map(ref=>{const o=doc.context.lookup(ref);return o instanceof PDFRawStream?latin(decodePDFRawStream(o).decode()):'';}).join('\n');
 let state={m:[1,0,0,1,0,0],fillWhite:false,strokeWhite:false,strokeRed:false},stack:typeof state[]=[],pts:number[][]=[],rect=false;const edits:{start:number;end:number}[]=[];
 for(const op of operations(raw)){const a=op.args.map(t=>Number(t.value));const point=(x:number,y:number)=>{const m=state.m;pts.push([m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]]);};
 if(op.op==='q')stack.push({...state,m:[...state.m]});else if(op.op==='Q')state=stack.pop()??state;else if(op.op==='cm')state.m=multiply(state.m,a);
 else if(['g','rg','k'].includes(op.op))state.fillWhite=op.op==='k'?a.every(x=>x===0):a.every(x=>x===1);
 else if(['G','RG','K'].includes(op.op)){state.strokeWhite=op.op==='K'?a.every(x=>x===0):a.every(x=>x===1);state.strokeRed=op.op==='K'?a[0]<.2&&a[1]>.7&&a[2]>.7&&a[3]<.2:op.op==='RG'&&a[0]>.7&&a[1]<.2&&a[2]<.2;}
 else if(op.op==='re'){point(a[0],a[1]);point(a[0]+a[2],a[1]+a[3]);rect=true;}
 else if(['m','l','c','v','y'].includes(op.op)){for(let i=0;i<a.length;i+=2)point(a[i],a[i+1]);}
 else if(['S','s','f','F','f*','B','B*','b','b*','n'].includes(op.op)){
 if(pts.length&&op.op!=='n'){const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),x=Math.min(...xs),y=Math.min(...ys),w=Math.max(...xs)-x,h=Math.max(...ys)-y;
 const outside=x+w<=face.x+.1||x>=face.x+face.w-.1||y+h<=face.y+.1||y>=face.y+face.h-.1;
 const small=w<=12*unit&&h<=12*unit;const stroke=['S','s'].includes(op.op),white=stroke?state.strokeWhite:state.fillWhite;
 const border=stroke&&white&&rect&&Math.abs(w-fw)<2*unit&&Math.abs(h-fh)<2*unit&&Math.abs(x-face.x)<unit&&Math.abs(y-face.y)<unit;
 if((outside&&small&&(white||(stroke&&!state.strokeRed)))||border)edits.push({start:op.start,end:op.end});}
 pts=[];rect=false;}
 }
 for(const e of edits.reverse())raw=raw.slice(0,e.start)+' n '+raw.slice(e.end);
 page.node.set(PDFName.of('Contents'),doc.context.register(doc.context.flateStream(bytes(`q ${crop.x} ${crop.y} ${crop.w} ${crop.h} re W n\n${raw}\nQ`))));
 page.translateContent(-crop.x,-crop.y);page.setMediaBox(0,0,crop.w,crop.h);page.setCropBox(0,0,crop.w,crop.h);page.setBleedBox(0,0,crop.w,crop.h);page.setTrimBox(b.left*unit,b.bottom*unit,fw,fh);
 return doc.save();
}
