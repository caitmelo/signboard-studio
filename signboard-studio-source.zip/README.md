# Signboard Studio

A private test app for turning PDF print designs into reusable templates. Upload a PDF, select its artwork page, edit the detected text, images, QR links and full-size print dimensions, then save the template. Upload opens directly in a grouped content editor; no field-selection or approval step is required. Saved templates can be reopened for subsequent jobs. The original Stone Edgewrap editor remains available at `/edgewrap`.

## What works

- Upload PDF designs up to 25 MB; choose one artwork page from a multipage source.
- Extract live text, exact source baselines, font sizes, colours, character positions and font names. Suggest up to two agent name/phone pairs. All supported, readable text starts editable, including headlines, addresses, descriptions, property counts and contact details. Agent roles are suggested automatically; each field has a dropdown in the edit step to change its role or keep it fixed. Unsupported source geometry is still flagged. The PDF recompiles automatically after a role, font, size or media-definition change.
- Preserve fixed PDF artwork and logos. Selected original text becomes invisible without disturbing its text advances; replacement lettering is drawn as vector outlines in the matching font. Negative source font sizes combined with upright PDF transforms are normalized correctly. Rectangular text clips are retained and checked.
- Reuse usable embedded font outlines. All 18 supplied full Poppins WOFF weights and four supplied Nimbus Sans OTF styles are bundled and matched by font name. Nimbus Sans and Nimbus Roman are distinct families and are never substituted for each other. The UI distinguishes a full matching font from an embedded subset; it never silently substitutes another family. TrueType subsets without a name table can use the source PDF’s font identity. Name-keyed raw CFF subsets are decoded through a minimal in-memory sfnt envelope, using their exact charstrings and PDF character widths; this also enables the original Edgewrap “For Sale” lettering. Unsupported CID-keyed CFF mappings still need the full matching font. This recovers the exact 11 Roman characters embedded in the supplied photo PDF and enables both headline fields; arbitrary new headline wording still needs the full NimbusRomNo9L-Med / matching Nimbus Roman Bold font. The supplied NimbusSanL files do not fill that gap. A matching full TTF/OTF/WOFF font can be uploaded when an embedded subset lacks new characters.
- Retain original font sizes and source text anchors. Agent names and phones stay at their original x/y positions, including single-agent designs and replacement wording. Choosing one agent only hides Agent 2; it does not centre or rearrange the remaining fields. Missing glyphs, empty fields, face overflow, dynamic-field collisions and detected fixed-text collisions block generation.
- Detect separate raster image placements and decodable QR images. Make each frame an editable image, QR field or fixed artwork. Replace multiple JPEG/PNG/WebP images, swap their order between frames, select cover/contain and adjust crop position. Raster logos can use transparent PNG replacements; existing vector logos stay fixed.
- Keep replacement images at their original paint order, within the original clipping frame, so gradients, logos and text above the image remain above it. Original image instances are wrapped independently when possible, even if they reference the same image resource.
- Regenerate a vector QR from an HTTP(S) link using the template’s frame and sampled colours. Square/rounded modules are selectable during setup, with continuous finder eyes and a four-module quiet zone. QR colours are checked for contrast and print module size. Mark an undetected or vector QR area on the preview once, then reuse its link field. Custom eyes, multi-colour effects and embedded QR logos are not reconstructed automatically.
- Save template metadata in owner-scoped D1 SQLite and the original PDF, prepared base, manifest and thumbnail in R2 object storage. Incomplete uploads remain drafts; saved templates are immutable. Replacement image assets are saved privately when selected in a saved template and receive reusable asset IDs. There is no saved job history; resetting a job restores the original sample media and text.
- Generate and preview the same output PDF. Import and image colour preparation run in the browser. Files are uploaded when the user saves a template or selects replacement media in a saved template. The saved-template job endpoint uses the same rendering and preflight engine.

## Content groups

Every upload runs geometric and content-based grouping over the original detected text. The supplied photo design becomes eight groups: heading, address, details, agents, sale, viewing, bed/bath/car counts and agency contact. General layouts receive appropriate detected groups or ordinary text blocks; the importer does not force real-estate roles onto unrelated text. This is deterministic grouping from readable PDF text, positions, size, icon font names and recognizable content, not an AI/OCR guarantee for every possible design.

The grouped interface retains the original per-line font, size, colour, baseline and glyph positioning underneath. Heading/address text boxes allow line breaks; paragraph details wrap as a unit. Unchanged grouped values retain exact PDF glyph positioning and render pixel-identically to the previous output. New text uses the original line styles. Available horizontal space can extend to a neighbouring text region or the existing clip; content that cannot fit the available lines, source clipping or face at the original font size is blocked. Missing characters still require the full matching font. Complex inline rich text is not reconstructed into an arbitrary rich-text editor.

- **Agents:** Separate name and phone fields for each agent, with the one/two-agent toggle inside this group. The original agent positions are preserved; choosing one agent hides Agent 2 without moving Agent 1.
- **Sale:** For sale or Auction. Auction opens a calendar/time dialog and renders wording such as `Auction: Onsite 14th September at 12:00 pm`. Dates are validated and formatted from calendar components without a timezone conversion. Existing auction artwork can remain unchanged until the user picks a replacement date.
- **Viewing:** By appointment by default, or custom text. A template-specific character cap and actual glyph-width checks prevent overflow beside the View label.
- **Features:** Beds, baths, cars in that order; the template's icon glyphs are retained. Values are whole numbers 0–99 and still undergo collision checks.
- **Agency:** Editable phone and email/website. None removes the group; an empty individual field hides just that line.

Group definitions are persisted in the manifest, and older saved templates receive inferred groups for their existing editable fields on load. Reopening source setup also recovers fields that were fixed by an older importer. “Adjust content groups” lets the user move lines between groups, create a separate box, rename groups or change their type. Advanced individual text/font controls remain available in source setup. Definition changes are saved as a new template; job wording, auction scheduling and visibility remain job values, as before.

`lib/content-groups.ts` owns inference, group definitions, defaults, measured wrapping and structured content resolution. `components/content-editor.tsx` is shared by upload and saved-template editing. The existing `/api/templates/:id/render` accepts `content` keyed by persisted group key, alongside its existing `agents`, `text`, `media` and `oneAgent` inputs. Supplied content overrides raw text for its group; omitted content retains source/legacy values. Use the root `agents` list or agent-role text keys for agent details. Unknown content keys, invalid dates, overflow and missing glyphs return 422. Grouped jobs use the same rendering and print-preflight functions as the editor.

```json
{
  "mode": "proof",
  "agents": [{"name": "Ashton Beukers", "phone": "0410 591 789"}],
  "content": {
    "heading": "European\nElegance",
    "address": "4/48-50 Gladstone Street\nNorth Parramatta",
    "details": "Modern townhouse with a designer kitchen and open living.",
    "sale": {"type": "auction", "date": "2026-09-14", "time": "12:00"},
    "viewing": {"mode": "custom", "text": "Saturday 12–12:30 pm"},
    "features": {"beds": "4", "baths": "2", "cars": "2"},
    "agency": {"visible": false}
  }
}
```

## Supported PDF scope

The importer needs live horizontal text with usable encoding and metrics. Scanned or entirely outlined lettering cannot automatically become editable text. Rotated/mirrored text, nonrectangular text clipping, ligatures, reused text objects, complex colour spaces and visible annotations may require preparation in the source design. The UI reports these cases instead of guessing.

Image replacement needs distinct raster image objects. Images baked into a flattened full-page picture, rotated frames and image frames inside reused Form objects require source preparation; the importer reports unsupported frames. Complex artwork is not automatically rebuilt into a full design editor. Known CMYK/gray/process-colour gradients and soft masks are preserved; unsupported gradient colour spaces keep exports proof-only.

Canva synchronisation, external agent/logo connectors and external-app authentication are not implemented. This system does not create or export Canva files. The generic TypeScript engine and saved-template job endpoint are ready to be called behind a future authenticated integration. Saved templates offer “Edit all text & field roles (new copy)” to reopen the original PDF with the current importer, without another manual upload. New templates retain their source page index and field-role settings. Older manifests without these settings receive the new default editable fields when reopened; legacy multipage templates may need their artwork page selected again.

Fit checks use text geometry. They cannot determine whether a longer name aesthetically conflicts with a photograph or decorative shape; review the actual generated proof before printing.

## Print output

Print settings use the attached **Sprint Solutions Sign & Print Specs 2026**, plus the user's standing requirements: **every print product needs positive bleed on all four sides; every signboard needs two red 5 × 5 mm registration squares**. These rules apply in both the editor and the saved-template job API. A cached manifest's old `printIssues` list cannot bypass current rules. The legacy `marks: false` flag cannot disable signboard marks.

The Print size tab identifies the product from the filename when possible and allows it to be changed. Known products set their required bleed automatically. Face dimensions always describe the finished visible area at full size. Large-sign bleed figures shown at 25% in the source specification are multiplied by four; small-format and poster rules use the sheet's 100% delivery instructions.

| Product | Full-size bleed per side | Registration squares | Safe text margin |
| --- | --- | --- | --- |
| Edgewrap, supported sizes through 8x4 | 65 mm | Two 5 mm squares | Face containment |
| Edgewrap, supported sizes 8x6 and larger | 95 mm | Two 5 mm squares | Face containment |
| Linea | 65 mm | Two 5 mm squares | Face containment |
| Bannerwrap / illuminated signboard | 116 mm | Two 5 mm squares | Face containment |
| Pointer / corflute / A-frame signs | 2 mm | Two 5 mm squares | Face containment |
| Brochures, booklets, mailcards, cards, business cards | 2 mm | None added | 5 mm |
| Posters, backlit posters, digital vinyl banners | 2 mm | None added | Face containment |
| Other signboards | Confirmed positive measurements, optionally per side | Two 5 mm squares | Face containment |
| Other print products | Confirmed positive measurements, optionally per side | None added | Face containment |

The card/brochure family covers ordinary outer trim; unusual imposed products such as Quatro Packs and pull-up banners need their own confirmed dimensions and per-side bleed. No automatic folding, imposition or panel spacing is implemented. Stickers also require positive bleed under the user's latest instruction, which supersedes the sheet's no-bleed sticker exception; the app requires that product's measurements to be confirmed.

Filename sizes use Sprint sign presets and paper/card sizes (A0–A6, DL, DLX, business card) where available. Unknown short numeric sign sizes are converted from feet and require review; dimensions of 50 or more are treated as millimetres. Unknown product names require a product selection, with no automatic 65 mm Edgewrap assumption. The source-artwork bleed switch confirms existing artwork coverage; it does not make output bleed optional. Artwork without confirmed bleed can be edited, saved and downloaded as a proof but cannot pass print preflight. A square page's aspect ratio alone does not establish bleed. Saved older templates keep their dimensions; current product rules flag conflicts for correction in a new copy. The source and final sheet must have matching proportions. MediaBox and TrimBox proportions are checked against Sprint presets as well as the filename. The supplied “6x4 Photo Signboard” actually has an 8x6 layout: 2440 × 1832 mm face, 95 mm bleed at full size. That conflict blocks print export until the intended dimensions are confirmed; it does not block editing. Its original 800 × 533 px photograph is about 9 dpi at full size and needs a higher-resolution replacement.

- Full-size PDF, with TrimBox describing the visible face and BleedBox describing its exact bleed. MediaBox includes any additional space required to hold registration squares outside small bleeds. Large pages use PDF UserUnit so dimensions exceeding 200 inches remain valid.
- Every signboard gets two solid red 5 × 5 mm squares touching the outside of the bottom face corners. Existing small red corner squares near those positions are replaced. A sign with 2 mm bleed gets 3 mm additional media space at the left, right and bottom so the squares remain intact without inflating the BleedBox. Brochures/cards and other non-signboard products receive no added registration or crop marks. Separate top/bottom/left/right bleed is supported for confirmed custom products; text centring and media resolution use the true face/source geometry.
- Original DeviceCMYK artwork is preserved. Ordinary sRGB vectors, 8-bit RGB raster images and RGB indexed palettes are converted using a 33³ LittleCMS-generated lookup table targeting the source U.S. Web Coated (SWOP) v2 profile. The profile is embedded as the output intent.
- Current replacement images are checked at their final crop size. Images below the app’s 40 dpi minimum over a large frame block print export; this is a prototype preflight threshold, not a printer-specified resolution guarantee. Replacing a low-resolution source clears its resolution issue when the replacement is large enough. Sources without confirmed bleed, with unsupported image colour conversion, different output profiles or unembedded fixed fonts only offer a **proof PDF**. No PDF/X certification is asserted.
- Screen guides are not exported. Background bleed is never invented by stretching a source that lacks it.

The original Stone 6x4 preset has a 1220 × 1832 mm face, 65 mm bleed, and 1350 × 1962 mm full sheet. Its dedicated renderer remains vector-only PDF 1.3. Imported templates preserve their original embedded image/font resources and use PDF 1.7.

## Code and interfaces

- `lib/pdf-content.ts`: PDF content parsing, resource traversal and text extraction.
- `lib/template-engine.ts`: analyse, compile, evaluate and render functions; shared manifest is `lib/template-types.ts`.
- `lib/print-specs.ts`: Sprint product profiles, filename/size inference, mandatory print rules, saved-template compatibility and page/bleed/mark geometry. `components/print-settings.tsx` exposes product selection and confirms custom specifications.
- `lib/template-media.ts`: image-slot wrappers, QR detection/generation, CMYK image preparation and media preflight.
- `components/media-fields.tsx`: media setup, bulk image selection, reordering, crop controls and QR links.
- `components/template-builder.tsx`: upload, text/media review, font upload and test/save workflow.
- `components/saved-template-editor.tsx`: reopen a template and generate jobs.
- `/api/templates`: private template catalogue and draft creation.
- `/api/templates/:id/assets/:asset`: owner-scoped upload/download of template assets.
- `/api/templates/:id/complete`: finalize a complete template upload.
- `/api/templates/:id/media`: upload a prepared CMYK image asset (25 MB maximum) and receive its asset ID.
- `/api/templates/:id/media/:assetId`: private image-asset retrieval.
- `/api/templates/:id/render`: JSON jobs for any ready saved template. Validates fields, agents, media IDs, links, crop positions, fit and print preflight; returns a PDF or structured 422 errors.
- `/api/render`: original JSON renderer for `stone-6x4-edgewrap-v1`.

Every storage request requires the hosting platform's trusted authenticated-user header. Assets are isolated by owner; state-changing requests reject a foreign Origin. Source PDFs stay private to the Site owner. No external print submission occurs.

## Automated jobs

Open a saved template, make your edits, then expand **Automation** to copy the exact JSON and test the job endpoint in your signed-in session. Stable image keys map each uploaded asset to an existing frame; swapping the IDs changes their order. Omitted fields retain original template values.

```json
{
  "mode": "proof",
  "agents": [{"name": "Zoë Anderson", "phone": "0412 345 678"}],
  "media": {
    "image_1": {"assetId": "UUID_RETURNED_BY_UPLOAD", "fit": "cover", "focalX": 0.5, "focalY": 0.5},
    "qr_1": {"url": "https://example.com/property"}
  }
}
```

Send this JSON to `POST /api/templates/:id/render`. One supplied agent hides the second agent; names and phone numbers retain their original source anchors in both modes. Text can also be set with `text` using field IDs or agent roles. Send `sourceSlot` instead of `assetId` to use another original photo. A missing media key leaves that slot untouched. `mode: "print"` requires all print checks to pass; `proof` retains the same physical dimensions but is explicitly labelled as a proof.

For an external implementation, call the exported `prepareImage` helper with decoded sRGB pixels and the supplied colour table, then post its prepared PDF bytes to the media upload endpoint (`Content-Type: application/pdf`). The browser helper handles EXIF orientation and browser colour-profile decoding for JPEG/PNG/WebP. Raw JPEG/PNG/WebP requests are not accepted by the server upload route. The prepared PDF contains a CMYK image and optional gray alpha mask; the route validates its structure. Images are limited to 24 megapixels and 25 MB per upload.

The endpoints are protected by the private hosting session. The app must not accept an arbitrary caller-supplied user header as external authentication. A separate authenticated gateway/token integration is required before another app can call them directly; no API keys or external asset URLs are configured here.

## Verification

```sh
python scripts/create-import-fixture.py
./node_modules/.bin/esbuild scripts/check-template-import.mts --bundle --platform=browser --external:node:* --format=esm --outfile=work/check-template-import.mjs
node work/check-template-import.mjs
./node_modules/.bin/esbuild scripts/check-template-storage.mts --bundle --platform=node --packages=external --format=esm --alias:cloudflare:workers=./scripts/test-storage-env.mjs --outfile=work/check-template-storage.mjs
node work/check-template-storage.mjs
node --experimental-strip-types scripts/check-renderer.mts
# Default-editable text and Nimbus font regression:
./node_modules/.bin/esbuild scripts/check-default-text.mts --bundle --platform=browser --format=esm --external:node:* --outfile=work/check-default-text.mjs
node work/check-default-text.mjs "../upload/6x4 Photo Signboard (1).pdf"
# Real supplied photo/font regression and saved-media job checks:
./node_modules/.bin/esbuild scripts/check-media.mts --bundle --platform=browser --format=esm --external:node:* --outfile=work/check-media.mjs
node work/check-media.mjs "../upload/6x4 Photo Signboard (1).pdf"
./node_modules/.bin/esbuild scripts/check-media-api.mts --bundle --platform=browser --format=esm --external:node:* --alias:cloudflare:workers=./scripts/test-storage-env.mjs --outfile=work/check-media-api.mjs
node work/check-media-api.mjs "../upload/6x4 Photo Signboard (1).pdf"
./node_modules/.bin/esbuild scripts/check-qr-style.mts --bundle --platform=browser --format=esm --external:node:* --outfile=work/check-qr-style.mjs
node work/check-qr-style.mjs
node scripts/verify-media-pdfs.mjs
# Product-specific bleed / registration / actual job API regression:
python scripts/create-print-fixtures.py
./node_modules/.bin/esbuild scripts/check-print-rules.mts --bundle --platform=browser --format=esm --external:node:* --alias:cloudflare:workers=./scripts/test-storage-env.mjs --outfile=work/check-print-rules.mjs
node work/check-print-rules.mjs
# Semantic groups and structured job API:
./node_modules/.bin/esbuild scripts/check-content-groups.mts --bundle --platform=browser --format=esm --external:node:* --alias:cloudflare:workers=./scripts/test-storage-env.mjs --outfile=work/check-content-groups.mjs
node work/check-content-groups.mjs
npx tsc --noEmit
```

The print-rule suite uses independent ReportLab brochure, card, corflute and Bannerwrap fixtures. It verifies every physical bleed edge, complete mandatory signboard squares, no added marks on small-format print, asymmetric bleed, 5 mm safe text margins, square-page detection, missing-bleed proof handling and enforcement through the actual saved job route, including stale legacy manifests. PyMuPDF independently renders the output for visual inspection.

The import suite tests an independently generated landscape 8x4 design with an RGB image, and the attached Stone source when available. It checks original placement, page selection, CMYK content, full dimensions, marks, centring, glyph/overflow/collision errors and proof-only bleed handling. The storage suite applies the actual migration to SQLite and exercises upload/finalization/reload, ownership, authentication and limits with an in-memory object-store adapter. This does not substitute for testing the deployed storage provider.

The media suite uses the supplied photo PDF, prepares a high-resolution synthetic replacement, verifies independent slots and tests actual API requests. An independent PyMuPDF render plus jsQR decodes the QR codes from the final image-slot, marked-area and API PDFs. The source PDF is an optional local test input and is not bundled in the deployment.

Fixture generation requires Python with ReportLab, Pillow and fontTools; independent PDF media verification uses PyMuPDF. Generated PDFs live under ignored `work/`; they have been independently rendered and visually inspected. The application itself needs no Python runtime.

`template-source/build_template.py` recreates the original dedicated template; `build_colour_table.py` regenerates its colour-conversion table. PDF.js is bundled for actual PDF preview with its Apache 2.0 licence. Poppins is licensed under the SIL Open Font License included with the font assets. The project preserves the Sites Vinext build/hosting workflow.
