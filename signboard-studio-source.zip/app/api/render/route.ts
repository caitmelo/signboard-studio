import templateData from "@/public/template/edgewrap.json";
import { createJob, makePdf, type Template } from "@/lib/edgewrap";

/** The private Site's same renderer, exposed as a reusable HTTP seam.
 * External app integration still needs its own hosting/authentication arrangement.
 */
export async function POST(request: Request) {
  if (!request.headers.get("content-type")?.includes("application/json")) return Response.json({ error: "Send a JSON job." }, { status: 415 });
  if (Number(request.headers.get("content-length")) > 8192) return Response.json({ error: "Job is too large." }, { status: 413 });
  try {
    const reader = request.body?.getReader();
    if (!reader) return Response.json({ error: "A job is required." }, { status: 400 });
    const parts: Uint8Array[] = [];
    let size = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > 8192) { await reader.cancel(); return Response.json({ error: "Job is too large." }, { status: 413 }); }
      parts.push(value);
    }
    const bytes = new Uint8Array(size); let offset = 0;
    for (const part of parts) { bytes.set(part, offset); offset += part.length; }
    const body = JSON.parse(new TextDecoder().decode(bytes));
    if (!body || body.templateId !== templateData.id) return Response.json({ error: "Select stone-6x4-edgewrap-v1." }, { status: 400 });
    const template = templateData as Template;
    const job = createJob(template, body.agents);
    if (!job.valid) return Response.json({ status: "needs_adjustment", errors: job.errors }, { status: 422 });
    return new Response(makePdf(template, job), { headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": 'attachment; filename="Stone_6x4_Edgewrap_Print_25pct.pdf"',
      "Cache-Control": "private, no-store",
      "X-Template-Version": String(template.version),
    } });
  } catch {
    return Response.json({ error: "The job could not be read. Supply a templateId and an agents array." }, { status: 400 });
  }
}
