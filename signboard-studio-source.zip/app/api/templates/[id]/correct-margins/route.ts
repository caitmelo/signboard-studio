import {checkOrigin,failure,ownedTemplate} from '@/lib/template-storage';
import {normalizeSavedTemplate} from '@/lib/print-specs';
import {evaluateTemplate} from '@/lib/template-engine';
import {evaluateMedia} from '@/lib/template-media';
import type {SavedTemplate} from '@/lib/template-types';
const proofNotice='This template version is saved for proofs. Correct its outstanding issues and approve a new version before print export.';
function candidate(t:SavedTemplate):SavedTemplate{return {...t,review:undefined,printIssues:t.printIssues.filter(v=>v!==proofNotice),pages:t.pages?.map(candidate)};}
export async function POST(request:Request,context:{params:Promise<{id:string}>}){
 try{
  checkOrigin(request);const {id}=await context.params;const {template,bucket,db,owner}=await ownedTemplate(request,id);
  if(!template||template.status!=='ready')return new Response('Not found',{status:404});
  const stored=await bucket.get(`templates/${id}/manifest`);if(!stored)return new Response('Not found',{status:404});
  const original=await stored.json<SavedTemplate>(),corrected=normalizeSavedTemplate(candidate(original));
  if(!corrected.safeTextCorrected)return Response.json({error:'This template has no safe-margin corrections to save.'},{status:422});
  // Saved replacement assets need their own full media preflight. Keep those
  // jobs in the normal editor rather than approving absent image bytes here.
  if(Object.entries(original.defaults?.media??{}).some(([id,v])=>v.kind!=='original'||v.slotId!==id||v.fit||v.focalX!==undefined||v.focalY!==undefined))return Response.json({error:'Open Edit text, media & print settings to review the saved replacement images before saving a print version.'},{status:422});
  const text=evaluateTemplate(corrected,original.defaults?.text??{},original.defaults?.oneAgent??false,original.defaults?.content??{}),media=evaluateMedia(corrected);
  const issues=[...corrected.printIssues,...text.errors,...text.printIssues,...media.errors,...media.printIssues];
  if(issues.length)return Response.json({error:issues.join(' ')},{status:422});
  const next=crypto.randomUUID(),created=new Date().toISOString(),name=original.name.replace(/^QA \d{4}-\d{2}-\d{2} — /,'')+' · Print corrected';
  const manifest:SavedTemplate={...corrected,name,createdAt:created,review:{status:'approved',reviewedAt:created,revision:(original.review?.revision??1)+1,parentId:id}};
  await db.prepare("INSERT INTO sign_templates (id,owner_id,name,source_name,status,created_at) VALUES (?,?,?,?, 'draft',?)").bind(next,owner,name,manifest.sourceName,created).run();
  for(const key of ['source','base','thumbnail']){const asset=await bucket.get(`templates/${id}/${key}`);if(!asset)throw Error('The original artwork is incomplete.');await bucket.put(`templates/${next}/${key}`,asset.body,{httpMetadata:asset.httpMetadata});}
  await bucket.put(`templates/${next}/manifest`,JSON.stringify(manifest),{httpMetadata:{contentType:'application/json'}});
  await db.prepare("UPDATE sign_templates SET status='ready',field_count=?,face_width_mm=?,face_height_mm=? WHERE id=? AND owner_id=? AND status='draft'").bind(manifest.fields.length+(manifest.media?.filter(s=>s.role!=='fixed').length??0),Math.round(manifest.spec.faceWidth),Math.round(manifest.spec.faceHeight),next,owner).run();
  return Response.json({id:next},{status:201});
 }catch(e){return failure(e);}
}
