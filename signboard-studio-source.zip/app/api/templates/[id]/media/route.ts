import {checkOrigin,failure,ownedTemplate}from'@/lib/template-storage';
import {validatePreparedImage}from'@/lib/template-media';
export async function POST(request:Request,context:{params:Promise<{id:string}>}){
 try{checkOrigin(request);const{id}=await context.params;const{template,bucket}=await ownedTemplate(request,id);if(!template)return new Response('Not found',{status:404});
  if(!request.headers.get('content-type')?.includes('application/pdf'))return Response.json({error:'Upload a prepared CMYK image PDF.'},{status:415});const max=25*1024*1024;if(Number(request.headers.get('content-length'))>max)return Response.json({error:'The prepared image exceeds 25 MB. Use a smaller image.'},{status:413});
  const reader=request.body?.getReader();if(!reader)return Response.json({error:'No image received.'},{status:400});const chunks:Uint8Array[]=[];let length=0;while(true){const next=await reader.read();if(next.done)break;length+=next.value.length;if(length>max){await reader.cancel();return Response.json({error:'The prepared image exceeds 25 MB. Use a smaller image.'},{status:413});}chunks.push(next.value);}const data=new Uint8Array(length);let at=0;for(const chunk of chunks){data.set(chunk,at);at+=chunk.length;}
  const dimensions=await validatePreparedImage(data);const assetId=crypto.randomUUID();let name='Uploaded image';try{name=decodeURIComponent(request.headers.get('x-image-name')??name).slice(0,240);}catch{}
  await bucket.put(`templates/${id}/media/${assetId}`,data,{httpMetadata:{contentType:'application/pdf'},customMetadata:{width:String(dimensions.width),height:String(dimensions.height),name}});
  return Response.json({assetId,...dimensions,name},{status:201});
 }catch(e){return failure(e,422);}
}
