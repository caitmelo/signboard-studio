import type { Metadata } from "next";
import "./globals.css";
import {getChatGPTUser,chatGPTSignInPath} from "./chatgpt-auth";
import "./templates.css";

export const metadata: Metadata = {
  title: "Signboard Studio · PDF Templates",
  description: "Upload signboard designs, generate reusable templates and create full-size PDFs with your agent details.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const user=await getChatGPTUser();
  return (
    <html lang="en">
      <body className="antialiased">{!user&&<div className="account-notice"><span>Sign in to save templates and create drafts from reference files.</span><a href={chatGPTSignInPath("/")} target="_top">Sign in with ChatGPT</a></div>}{children}</body>
    </html>
  );
}
