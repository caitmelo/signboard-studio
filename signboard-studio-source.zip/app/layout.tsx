import type { Metadata } from "next";
import "./globals.css";
import "./templates.css";

export const metadata: Metadata = {
  title: "Signboard Studio · PDF Templates",
  description: "Upload signboard designs, generate reusable templates and create full-size PDFs with your agent details.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
