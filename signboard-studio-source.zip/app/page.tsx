import { TemplateLibrary } from "@/components/template-library";
export default function Home() { return <TemplateLibrary/>; }
