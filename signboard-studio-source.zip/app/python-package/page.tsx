import {PythonPackage} from '@/components/python-package';
export default function Page(){return <PythonPackage/>;}
