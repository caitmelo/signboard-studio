import { SavedTemplateEditor } from "@/components/saved-template-editor";
export default async function TemplatePage({params}:{params:Promise<{id:string}>}) { const{id}=await params;return <SavedTemplateEditor id={id}/>; }
