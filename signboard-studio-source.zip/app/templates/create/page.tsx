import {DesignBuilder} from '@/components/design-builder';
export default function Create(){return <DesignBuilder/>}
