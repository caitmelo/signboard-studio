import {TemplateWorkspace} from "@/components/template-workspace";
export default function NewTemplate(){return <TemplateWorkspace/>;}
