"use client";
import {useState} from 'react';
import {Copy,Download,Loader2} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {contentGroups,defaultGroupValue} from '@/lib/content-groups';
import type {MediaValues,SavedTemplate,ContentValues} from '@/lib/template-types';

export function AutomationJob({id,template,values,oneAgent,media,proof,disabled,content}:{content:ContentValues;id:string;template:SavedTemplate;values:Record<string,string>;oneAgent:boolean;media:MediaValues;proof:boolean;disabled:boolean}){
 const[status,setStatus]=useState(''),[busy,setBusy]=useState(false);
 const slots=Object.fromEntries((template.media??[]).filter(s=>s.role!=='fixed').flatMap<[string,Record<string,string|number>]>(slot=>{
  const value=media[slot.id];if(!value)return [];
  if(value.kind==='qr')return [[slot.key,{url:value.url}]];
  const crop={...(value.fit?{fit:value.fit}:{}),...(value.focalX!==undefined?{focalX:value.focalX}:{}),...(value.focalY!==undefined?{focalY:value.focalY}:{})};
  if(value.kind==='image')return value.image.assetId?[[slot.key,{assetId:value.image.assetId,...crop}]]:[];
  if(value.slotId===slot.id&&!Object.keys(crop).length)return [];
  return [[slot.key,{sourceSlot:template.media?.find(s=>s.id===value.slotId)?.key??value.slotId,...crop}]];
 }));
 const body=JSON.stringify({mode:proof?'proof':'print',oneAgent,text:Object.fromEntries(template.fields.filter(f=>f.role.startsWith('agent')&&(!oneAgent||!f.role.startsWith('agent2_'))).map(f=>[f.role.startsWith('agent')?f.role:f.id,values[f.id]??f.text])),content:Object.fromEntries(contentGroups(template).filter(g=>g.kind!=='agents').map(g=>[g.key,content[g.key]??defaultGroupValue(g,template.fields,values)])),media:slots},null,2);
 const endpoint=`/api/templates/${id}/render`;
 async function copy(){try{await navigator.clipboard.writeText(body);setStatus('Job JSON copied.');}catch{setStatus('Select the JSON below and copy it.');}}
 async function run(){setBusy(true);setStatus('');try{const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body});if(!response.ok){const result=await response.json()as{error?:string;errors?:string[]};throw new Error(result.errors?.join(' ')??result.error??'The job could not run.');}const url=URL.createObjectURL(await response.blob());const link=document.createElement('a');link.href=url;link.download=`Signboard_API_${response.headers.get('X-Print-Status')==='ready'?'Print':'Proof'}.pdf`;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);setStatus('The job endpoint generated your PDF.');}catch(e){setStatus(e instanceof Error?e.message:'The job could not run.');}finally{setBusy(false);}}
 return <details className="automation-job"><summary>Automation · use this template in a job</summary><p>The JSON below follows your current edits. Uploaded images have reusable asset IDs; assigning them to different image keys changes their order.</p><code className="job-endpoint">POST {endpoint}</code><pre tabIndex={0}>{body}</pre><div className="media-actions"><Button variant="outline" size="sm" onClick={copy}><Copy size={15}/>Copy JSON</Button><Button variant="outline" size="sm" disabled={disabled||busy} onClick={run}>{busy?<Loader2 className="spin" size={15}/>:<Download size={15}/>}Test job API</Button></div>{status&&<p role="status">{status}</p>}<p className="help-text">This endpoint uses your signed-in private app session. Connecting another app requires its own authentication setup.</p></details>;
}
