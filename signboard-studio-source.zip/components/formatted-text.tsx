"use client";
import {useRef,useState} from 'react';
import {Bold,Italic,Type} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Textarea} from '@/components/ui/textarea';
import {applyStyle,remapStyles} from '@/lib/rich-text';
import type {TextStyleRange} from '@/lib/template-types';
export function FormattedText({id,label,text,styles,disabled,rows=2,maxLength=3000,onChange}:{id?:string;label:string;text:string;styles:TextStyleRange[];disabled?:boolean;rows?:number;maxLength?:number;onChange:(text:string,styles:TextStyleRange[])=>void}){
 const ref=useRef<HTMLTextAreaElement>(null),[selection,setSelection]=useState<[number,number]>([0,0]);const selected=selection[1]>selection[0];const active=styles.filter(s=>s.start<=selection[0]&&s.end>selection[0]).at(-1);
 function format(bold:boolean,italic:boolean){if(!selected)return;onChange(text,applyStyle(styles,selection[0],selection[1],bold,italic));requestAnimationFrame(()=>{ref.current?.focus();ref.current?.setSelectionRange(...selection);});}
 return <div className="formatted-text"><div className="text-format-toolbar" role="toolbar" aria-label={`${label} formatting`}>
  <Button type="button" variant="ghost" size="sm" title="Bold selected text" aria-label={`Bold ${label}`} disabled={disabled||!selected} onMouseDown={e=>e.preventDefault()} aria-pressed={!!active?.bold} onClick={()=>format(!active?.bold,!!active?.italic)}><Bold size={15}/></Button>
  <Button type="button" variant="ghost" size="sm" title="Italic selected text" aria-label={`Italic ${label}`} disabled={disabled||!selected} onMouseDown={e=>e.preventDefault()} aria-pressed={!!active?.italic} onClick={()=>format(!!active?.bold,!active?.italic)}><Italic size={15}/></Button>
  <Button type="button" variant="ghost" size="sm" title="Normal selected text" aria-label={`Normal ${label}`} disabled={disabled||!selected} onMouseDown={e=>e.preventDefault()} onClick={()=>format(false,false)}><Type size={15}/><span>Normal</span></Button>
 </div><Textarea ref={ref} id={id} aria-label={label} value={text} disabled={disabled} rows={rows} maxLength={maxLength} onSelect={e=>setSelection([e.currentTarget.selectionStart,e.currentTarget.selectionEnd])} onChange={e=>onChange(e.target.value,remapStyles(text,e.target.value,styles))}/><p className="format-hint">Select text to format it. Styles appear in the preview.</p></div>;
}
