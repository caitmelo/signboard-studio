"use client";
import {useState} from 'react';
import {Button} from '@/components/ui/button';
import {Checkbox} from '@/components/ui/checkbox';
import {Select,SelectContent,SelectItem,SelectTrigger,SelectValue} from '@/components/ui/select';
import {combineFragments,separateFragments} from '@/lib/template-corrections';
import type {Analysis,MediaSlot} from '@/lib/template-types';

export function PhotoCorrections({slots,onChange}:{slots:MediaSlot[];onChange:(slots:MediaSlot[])=>void}){
 const [parent,setParent]=useState(''),[selected,setSelected]=useState<string[]>([]),[error,setError]=useState('');
 function merge(){try{onChange(combineFragments(slots,parent,selected));setSelected([]);setError('');}catch(e){setError((e as Error).message);}}
 return <div className="correction-card"><h3>Combine photo fragments</h3><p className="help-text">Choose the complete photo frame, then select overlapping fragments that belong to it. Their original positions are retained.</p><Select value={parent} onValueChange={v=>{setParent(v);setSelected([]);setError('');}}><SelectTrigger aria-label="Main photo frame"><SelectValue placeholder="Choose main photo"/></SelectTrigger><SelectContent>{slots.filter(s=>s.supported&&!s.region&&s.role!=='qr').map(s=><SelectItem key={s.id} value={s.id}>{s.label} · {s.id}</SelectItem>)}</SelectContent></Select>{slots.filter(s=>s.id!==parent&&s.supported&&!s.region&&s.role!=='qr').map(s=><label className="correction-choice" key={s.id}><Checkbox checked={selected.includes(s.id)} onCheckedChange={v=>setSelected(x=>v?[...x,s.id]:x.filter(id=>id!==s.id))}/>{s.preview&&<img src={s.preview} alt=""/>}<span>{s.label} · {s.id}</span></label>)}<Button variant="outline" disabled={!parent||!selected.length} onClick={merge}>Combine into one photo slot</Button>{error&&<p role="alert" className="notice error">{error}</p>}{slots.filter(s=>s.fragments?.length).map(s=><div className="correction-card" key={s.id}><p>{s.label}: {(s.fragments?.length??0)+1} image pieces</p><Button variant="outline" onClick={()=>{onChange(separateFragments(slots,s.id));setSelected([]);}}>Separate image pieces</Button></div>)}</div>;
}

export function AnalysisNotes({analysis}:{analysis:Analysis}){
 const text=analysis.runs.filter(r=>!r.supported||!r.encodingComplete),media=analysis.media?.filter(s=>!s.supported||s.flattenedShading)??[];
 return <div className="correction-card"><h3>Analysis notes</h3>{!text.length&&!media.length?<p className="help-text">No unsupported text or media effects were detected. Compare the generated preview with the original before approving.</p>:<>{text.map(r=><p className="help-text" key={r.id}><strong>{r.text}</strong>: {r.issue??'The character mapping is incomplete. An editable source is needed.'}</p>)}{media.map(s=><p className="help-text" key={s.id}><strong>{s.label}</strong>: {s.flattenedShading?'Shading is baked into this photo. A field correction cannot restore a separate fade layer; replacements remain proof-only.':s.issue}</p>)}</>}</div>;
}
