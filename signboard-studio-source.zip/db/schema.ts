import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";

export const templates = sqliteTable("sign_templates", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  name: text("name").notNull(),
  sourceName: text("source_name").notNull(),
  status: text("status").notNull().default("draft"),
  fieldCount: integer("field_count").notNull().default(0),
  faceWidth: integer("face_width_mm").notNull().default(0),
  faceHeight: integer("face_height_mm").notNull().default(0),
  createdAt: text("created_at").notNull(),
}, table => [index("idx_sign_templates_owner_status").on(table.ownerId, table.status)]);
