# Font recovery and direct save

- Read FontDescriptor/FontName when a PDF omits BaseFont.
- Read the embedded font's real family before requesting a full font.
- Recover monochrome vector Type 3 glyph programs, including fonts identified only by R39 or F1.
- Match anonymised vector subsets to supplied fonts using glyph outlines and advances; do not substitute a merely similar font. Load only sample glyphs during matching.
- Use the matched full family for content and formatting, including newly typed characters.
- Keep embedded fonts usable when a catalogue request fails.
- Remove the mandatory user review checkbox. Save template remains gated by successful preparation/rendering, with existing print checks preserved.

Validation: synthetic R39 Type 3 PDF using the supplied Nimbus Roman Bold outlines, heading replacement with new characters, manifest JSON round-trip and PDF export. Original/recovered glyph masks matched at 4x raster resolution after normalising ink intensity. A mismatched outline sample was not substituted.

The screenshot's original PDF was not supplied in this turn. This verifies the reproduced font-reference failure class, not that exact document. The managed browser preview service was unavailable; authenticated save/reopen could not be tested. This is not a claim of universal PDF font support.
