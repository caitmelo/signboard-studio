# Regression status — 21 September 2026

## Implemented
- Preserve the source CMYK output profile; transform ICC RGB images and supported axial/radial gradients into that profile.
- Recognise process-colour DeviceN/Indexed images without falsely treating them as RGB or spot colours.
- Decode large browser JPEGs with the native image decoder; keep the 48 MP pixel limit.
- Match Python's bounded PDF decompression allowance to valid 48 MP CMYK images.
- Add missing paper bleed without moving trim artwork; refresh generated bleed from final edited content at export.
- Preserve replacement-image colour profiles in both renderers.
- Classify letter greetings/sign-offs separately from headings.
- Repair the builder focus type check used by keyboard deletion.

## Verified
- Eight attached template PDFs, 14 pages: analysis, compilation and representative edits rendered without edit errors.
- Export trim dimensions matched each confirmed manifest: signboards 25%, paper 100%.
- JavaScript and Python output comparisons: all 14 pages matched at the 900-pixel comparison width (mean pixel difference 0).
- ICC conversion matched independent Pillow results within two channel levels; supported gradient conversion and process/spot classification passed.
- Missing DL bleed produces a 214 × 103 mm sheet with a 210 × 99 mm trim. A changed-colour fixture confirms all generated bleed edges and corners follow the edited artwork.
- TypeScript and production builds passed.

## Still outstanding — do not describe the entire system as verified
- Two booklet pages contain existing artwork inside the configured safe margin: trifold page 2 and A5 booklet page 3. Original elements were not silently moved.
- Rasterised icon numbers are not always separately editable.
- Browser save/reopen, persisted media replacement and scanned-vs-digital reconstruction require completing the browser sign-in. The browser remains signed out.
- The managed browser preview service is unavailable in this session, so the latest browser-native decoding changes have not received browser verification.
- Regression edits are representative, not an exhaustive edit of every possible field or upload format.
- Filename/physical-size discrepancies still require confirmation; the regression uses the detected dimensions. Dimension tests do not prove the filename is correct.

The scanned draft builder is an approximation workflow; identical quality to an original layered digital PDF has not been established.
