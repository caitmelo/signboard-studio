CREATE TABLE `sign_templates` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`name` text NOT NULL,
	`source_name` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`field_count` integer DEFAULT 0 NOT NULL,
	`face_width_mm` integer DEFAULT 0 NOT NULL,
	`face_height_mm` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_sign_templates_owner_status` ON `sign_templates` (`owner_id`,`status`);