import jpeg from 'jpeg-js';

export async function decodePrintJpeg(encoded:Uint8Array,width:number,height:number):Promise<Uint8Array>{
  if(width*height>48_000_000)throw Error('Photo exceeds the colour conversion limit');
  // Browser-native decoding avoids jpeg-js's large per-block JS allocations.
  // Colour conversion is deliberately deferred to the PDF's ICC transform.
  if(typeof window!=='undefined'&&typeof createImageBitmap==='function'){
    const bitmap=await createImageBitmap(new Blob([encoded.slice().buffer],{type:'image/jpeg'}),{colorSpaceConversion:'none',premultiplyAlpha:'none'});
    const canvas=document.createElement('canvas');
    try{
      if(bitmap.width!==width||bitmap.height!==height)throw Error('JPEG dimensions do not match the PDF image');
      canvas.width=width;canvas.height=height;
      const context=canvas.getContext('2d',{willReadFrequently:true});if(!context)throw Error('Photo decoding is unavailable');
      context.drawImage(bitmap,0,0);
      const rgba=context.getImageData(0,0,width,height).data,rgb=new Uint8Array(width*height*3);
      for(let i=0,j=0;i<rgba.length;i+=4,j+=3){rgb[j]=rgba[i];rgb[j+1]=rgba[i+1];rgb[j+2]=rgba[i+2]}
      return rgb;
    }finally{bitmap.close();canvas.width=canvas.height=0}
  }
  const decoded=jpeg.decode(encoded,{useTArray:true,formatAsRGBA:false,maxMemoryUsageInMB:1024,maxResolutionInMP:48});
  if(decoded.width!==width||decoded.height!==height)throw Error('JPEG dimensions do not match the PDF image');
  return decoded.data;
}
