import {PDFDocument,PDFName,PDFString,PDFHexString,rgb,degrees} from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import QRCode from 'qrcode';
import type {PrintSpec} from './template-types';
export type Element={id:string;kind:'text'|'image'|'rectangle'|'ellipse'|'line'|'qr';label:string;x:number;y:number;w:number;h:number;text:string;font:string;size:number;color:string;align:'left'|'center'|'right';lineHeight:number;rotation:number;opacity:number;hidden:boolean;locked:boolean;shape:'rectangle'|'square'|'circle'|'oval'|'rounded';src?:string;fit:'cover'|'contain';zoom:number;focalX:number;focalY:number;flipX:boolean;flipY:boolean;dynamic:boolean};
export type Scene={reference?:{src:string;notes:string[]};version:1;name:string;spec:PrintSpec;pages:{background:string;elements:Element[]}[]};
export const MM=72/25.4;
export const uid=()=>crypto.randomUUID();
export function newElement(kind:Element['kind']):Element{return{id:uid(),kind,label:kind==='text'?'Text':kind==='image'?'Image':kind==='qr'?'QR code':'Shape',x:15,y:15,w:kind==='text'?110:60,h:kind==='text'?30:60,text:kind==='qr'?'https://example.com':'Your text',font:'Poppins-Regular',size:18,color:'#344254',align:'left',lineHeight:1.25,rotation:0,opacity:1,hidden:false,locked:false,shape:'rectangle',fit:'cover',zoom:1,focalX:.5,focalY:.5,flipX:false,flipY:false,dynamic:['text','image','qr'].includes(kind)};}
export function color(hex:string){return rgb(parseInt(hex.slice(1,3),16)/255,parseInt(hex.slice(3,5),16)/255,parseInt(hex.slice(5,7),16)/255);}
export function loadImage(src:string):Promise<HTMLImageElement>{return new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('This image could not be opened.'));i.src=src;});}
export async function framedImage(e:Element){
 const image=await loadImage(e.src!);const scale=Math.min(1,Math.sqrt(12000000/(image.naturalWidth*image.naturalHeight)));const ratio=e.w/e.h;
 const c=document.createElement('canvas');c.width=Math.max(1,Math.round(Math.min(5000,Math.max(image.naturalWidth,image.naturalHeight*ratio))*scale));c.height=Math.max(1,Math.round(c.width/ratio));
 if(c.width*c.height>16000000){const s=Math.sqrt(16000000/(c.width*c.height));c.width=Math.floor(c.width*s);c.height=Math.floor(c.height*s);}
 const g=c.getContext('2d')!;g.beginPath();if(e.shape==='circle'||e.shape==='oval')g.ellipse(c.width/2,c.height/2,c.width/2,c.height/2,0,0,Math.PI*2);else if(e.shape==='rounded')g.roundRect(0,0,c.width,c.height,Math.min(c.width,c.height)*.12);else g.rect(0,0,c.width,c.height);g.clip();
 g.translate(c.width/2,c.height/2);g.rotate(e.rotation*Math.PI/180);g.scale(e.flipX?-1:1,e.flipY?-1:1);const turn=e.rotation%180!==0,fw=turn?c.height:c.width,fh=turn?c.width:c.height;const s=(e.fit==='cover'?Math.max(fw/image.width,fh/image.height):Math.min(fw/image.width,fh/image.height))*e.zoom;const w=image.width*s,h=image.height*s;
 g.drawImage(image,-fw/2+(fw-w)*e.focalX,-fh/2+(fh-h)*e.focalY,w,h);return c.toDataURL('image/png');
}
export async function scenePdf(scene:Scene){
 const doc=await PDFDocument.create();doc.registerFontkit(fontkit);const catalog=await fetch('/template/fonts/manifest.json').then(r=>r.json()) as Record<string,string>;const fonts=new Map<string,any>();const b=scene.spec.bleed;const W=(scene.spec.faceWidth+2*b)*MM,H=(scene.spec.faceHeight+2*b)*MM;
 for(const design of scene.pages){const p=doc.addPage([W,H]);p.setTrimBox(b*MM,b*MM,scene.spec.faceWidth*MM,scene.spec.faceHeight*MM);p.setBleedBox(0,0,W,H);p.drawRectangle({x:0,y:0,width:W,height:H,color:color(design.background)});
 for(const e of design.elements.filter(e=>!e.hidden)){const x=(e.x+b)*MM,y=H-(e.y+b+e.h)*MM,w=e.w*MM,h=e.h*MM;
 if(e.kind==='text'){if(!fonts.has(e.font)){const file=catalog[e.font];if(!file)throw Error(`Font ${e.font} is not installed.`);const r=await fetch('/template/fonts/'+file);if(!r.ok)throw Error('Font could not load. Try again.');fonts.set(e.font,await doc.embedFont(await r.arrayBuffer(),{subset:true,customName:e.font}));}const f=fonts.get(e.font),lines:string[]=[];
 for(const paragraph of e.text.split('\n')){let line='';for(const word of paragraph.split(' ')){const trial=line?line+' '+word:word;if(f.widthOfTextAtSize(trial,e.size)>w&&line){lines.push(line);line=word;}else line=trial;}lines.push(line);}
 if(lines.length*e.size*e.lineHeight>h+.1)throw Error(`${e.label}: increase the text box height or reduce the font size.`);
 for(const [i,line]of lines.entries()){const tw=f.widthOfTextAtSize(line,e.size);if(tw>w+.1)throw Error(`${e.label}: a word is wider than its text box.`);p.drawText(line,{x:x+(e.align==='center'?(w-tw)/2:e.align==='right'?w-tw:0),y:y+h-e.size-i*e.size*e.lineHeight,size:e.size,font:f,color:color(e.color),opacity:e.opacity});}
 }else if(e.kind==='image'&&e.src){const img=await doc.embedPng(await framedImage(e));p.drawImage(img,{x,y,width:w,height:h,opacity:e.opacity});}
 else if(e.kind==='qr'){const png=await QRCode.toDataURL(e.text,{errorCorrectionLevel:'M',width:640,margin:4,color:{dark:e.color,light:'#ffffff'}});p.drawImage(await doc.embedPng(png),{x,y,width:w,height:h});}
 else if(e.kind==='ellipse')p.drawEllipse({x:x+w/2,y:y+h/2,xScale:w/2,yScale:h/2,color:color(e.color),opacity:e.opacity});
 else if(e.kind==='line')p.drawLine({start:{x,y:y+h/2},end:{x:x+w,y:y+h/2},thickness:Math.max(.5,h),color:color(e.color),opacity:e.opacity});
 else p.drawRectangle({x,y,width:w,height:h,color:color(e.color),opacity:e.opacity});
 }}doc.catalog.set(PDFName.of('StudioDesign'),PDFHexString.fromText(JSON.stringify(scene)));doc.setTitle(scene.name);return doc.save({useObjectStreams:false});
}
export async function sceneFromPdf(data:Uint8Array):Promise<Scene|undefined>{const d=await PDFDocument.load(data);const s=d.catalog.lookupMaybe(PDFName.of('StudioDesign'),PDFHexString);return s?JSON.parse(s.decodeText()):undefined;}
