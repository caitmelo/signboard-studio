import {PDFArray,PDFDict,PDFDocument,PDFName,PDFNumber,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {rgbIccTransform} from './icc-conversion';
const profiles=new Map<string,Promise<Uint8Array>>();
const documents=new WeakMap<Uint8Array,Promise<{icc:Uint8Array;table:Uint8Array}|undefined>>();
export const profileText=(value:Uint8Array)=>{let s='';for(let i=0;i<value.length;i+=8192)s+=String.fromCharCode(...value.subarray(i,i+8192));return btoa(s)};
export const profileBytes=(value:string)=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
export async function documentColour(source:Uint8Array){
 if(!documents.has(source))documents.set(source,(async()=>{
  const doc=await PDFDocument.load(source),intents=doc.catalog.lookupMaybe(PDFName.of('OutputIntents'),PDFArray);
  if(!intents?.size())return;
  const intent=doc.context.lookup(intents.get(0));if(!(intent instanceof PDFDict))return;
  const stream=doc.context.lookup(intent.get(PDFName.of('DestOutputProfile')));if(!(stream instanceof PDFRawStream)||stream.dict.lookupMaybe(PDFName.of('N'),PDFNumber)?.asNumber()!==4)return;
  const icc=decodePDFRawStream(stream).decode();if(icc.length>2_000_000)throw Error('The embedded print profile is too large');
  const key=profileText(icc);
  if(!profiles.has(key))profiles.set(key,(async()=>{
    const response=await fetch('/colour/srgb.icc');if(!response.ok)throw Error('The RGB colour profile could not load');
    const transform=await rgbIccTransform(new Uint8Array(await response.arrayBuffer()),icc);
    try{const samples=new Uint8Array(33**3*3);let at=0;for(let r=0;r<33;r++)for(let g=0;g<33;g++)for(let b=0;b<33;b++){samples[at++]=Math.round(r*255/32);samples[at++]=Math.round(g*255/32);samples[at++]=Math.round(b*255/32)}return transform.convert(samples)}finally{transform.close()}
  })().catch(e=>{profiles.delete(key);throw e}));
  return {icc,table:await profiles.get(key)!};
 })().catch(e=>{documents.delete(source);throw e}));
 return documents.get(source)!;
}
