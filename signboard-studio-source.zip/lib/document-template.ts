import {PDFDocument,PDFRawStream,PDFName,PDFString} from 'pdf-lib';
import type {SavedTemplate,Analysis,ContentValues,MediaValues} from './template-types';
import {compileDesign,type EngineAssets} from './template-engine';
export function pageValues<T>(values:Record<string,T>,keys:string[]){const wanted=new Set(keys);return Object.fromEntries(Object.entries(values).filter(([k])=>wanted.has(k)));}
export function namespacePage(t:SavedTemplate,index:number):SavedTemplate{
 const prefix=`p${index+1}_`,id=(s:string)=>prefix+s;
 return {...t,fields:t.fields.map(f=>({...f,id:id(f.id)})),fieldSettings:t.fieldSettings?.map(f=>({...f,id:id(f.id)})),groups:t.groups?.map(g=>({...g,id:id(g.id),key:id(g.key),fieldIds:g.fieldIds.map(id),bindings:Object.fromEntries(Object.entries(g.bindings??{}).map(([k,v])=>[k,id(v)]))})),media:t.media?.map(s=>({...s,id:id(s.id),key:id(s.key),fragments:s.fragments?.map(f=>({...f,id:id(f.id),key:id(f.key)}))}))};
}
const prepared=new WeakMap<Analysis,Promise<Awaited<ReturnType<typeof compileDesign>>>>();
export async function compileDocument(source:Uint8Array,analyses:Analysis[],name:string,assets:EngineAssets){
 if(analyses.length===1)return compileDesign(source,analyses[0],name,assets);
 const output=await PDFDocument.create(),pages:SavedTemplate[]=[];
 for(const [i,a] of analyses.entries()){
  let cached=prepared.get(a);if(!cached){cached=compileDesign(source,a,name,assets);prepared.set(a,cached);cached.catch(()=>prepared.delete(a));}const b=await cached,doc=await PDFDocument.load(b.base);
  for(const [,obj] of doc.context.enumerateIndirectObjects())if(obj instanceof PDFRawStream){const slot=obj.dict.lookupMaybe(PDFName.of('SignboardSlot'),PDFString);if(slot)obj.dict.set(PDFName.of('SignboardSlot'),PDFString.of(`p${i+1}_${slot.decodeText()}`));}
  const [page]=await output.copyPages(doc,[0]);output.addPage(page);pages.push(namespacePage(b.manifest,i));
 }
 const manifest:SavedTemplate={...pages[0],name,pages,fields:pages.flatMap(p=>p.fields),fieldSettings:pages.flatMap(p=>p.fieldSettings??[]),groups:pages.flatMap(p=>p.groups??[]),media:pages.flatMap(p=>p.media??[]),fonts:Object.assign({},...pages.map(p=>p.fonts)),fixedText:[],warnings:pages.flatMap((p,i)=>p.warnings.map(w=>`Page ${i+1}: ${w}`)),printIssues:pages.flatMap((p,i)=>p.printIssues.map(w=>`Page ${i+1}: ${w}`))};
 return {base:await output.save(),manifest};
}
