/** Deterministic, vector-only Edgewrap renderer. No browser or network dependencies. */
export type Agent = { name: string; phone: string };
export type Glyph = { advance: number; path: string; bounds: number[] | null };
export type Template = {
  id: string; version: number; staticCommands: string; iccBase64: string;
  unitsPerEm: number; glyphs: Record<string, Glyph>;
};
export type Line = { text: string; x: number; y: number; size: number; width: number; color: number[]; bounds: number[]; agent: number; field: "name" | "phone" };
export type Job = { valid: boolean; errors: string[]; agents: Agent[]; lines: Line[]; templateId: string };
const MM = 72 / 25.4;
const WIDTH = 337.5 * MM;
const HEIGHT = 490.5 * MM;
const BLEED = 16.25 * MM;
const CENTRES = { name: [285.0591257, 661.87685135], phone: [285.0597955, 661.8782304] };
const PALETTE = { name: [0.734, 0.013, 0.297, 0], phone: [0, 0, 0, 0] };

export function createJob(template: Template, input: Agent[]): Job {
  const errors: string[] = [];
  const lines: Line[] = [];
  const agents: Agent[] = [];
  if (!Array.isArray(input) || input.length < 1 || input.length > 2) {
    return { valid: false, errors: ["Supply one or two agents."], agents, lines, templateId: template.id };
  }
  for (const [i, agent] of input.entries()) {
    const clean: Agent = { name: "", phone: "" };
    for (const field of ["name", "phone"] as const) {
      const label = `Agent ${i + 1} ${field === "name" ? "name" : "phone number"}`;
      if (!agent || typeof agent[field] !== "string") { errors.push(`${label} is required.`); continue; }
      const value = agent[field].normalize("NFC").trim();
      clean[field] = value;
      if (!value) { errors.push(`${label} is required.`); continue; }
      if (value.length > (field === "name" ? 120 : 40)) { errors.push(`${label} is too long.`); continue; }
      const missing = [...new Set([...value].filter(c => !template.glyphs[String(c.codePointAt(0))]))];
      if (missing.length) { errors.push(`${label} uses characters not supported by this font: ${missing.join(" ")}.`); continue; }
      const size = field === "name" ? 31.2417 : 40.9614;
      const scale = size / template.unitsPerEm;
      const width = [...value].reduce((total, c) => total + template.glyphs[String(c.codePointAt(0))].advance, 0) * scale;
      const x = (input.length === 1 ? WIDTH / 2 : CENTRES[field][i]) - width / 2;
      const y = field === "name" ? 330.5898 : 283.6514;
      let cursor = 0;
      let box = [Infinity, Infinity, -Infinity, -Infinity];
      for (const c of value) {
        const glyph = template.glyphs[String(c.codePointAt(0))];
        if (glyph.bounds) {
          box = [Math.min(box[0], cursor + glyph.bounds[0]), Math.min(box[1], glyph.bounds[1]), Math.max(box[2], cursor + glyph.bounds[2]), Math.max(box[3], glyph.bounds[3])];
        }
        cursor += glyph.advance;
      }
      if (!Number.isFinite(box[0])) { errors.push(`${label} needs visible characters.`); continue; }
      const bounds = [x + box[0] * scale, y + box[1] * scale, x + box[2] * scale, y + box[3] * scale];
      // Expand around the original centre while keeping the whole frame on the face.
      if (Math.min(x, bounds[0]) < BLEED || Math.max(x + width, bounds[2]) > WIDTH - BLEED || bounds[1] < BLEED || bounds[3] > HEIGHT - BLEED) {
        errors.push(`${label} reaches outside the visible face. Shorten it to keep the original font size.`);
      }
      lines.push({ text: value, x, y, size, width, color: PALETTE[field], bounds, agent: i, field });
    }
    agents.push(clean);
  }
  if (input.length === 2) {
    for (const field of ["name", "phone"] as const) {
      const left = lines.find(l => l.agent === 0 && l.field === field);
      const right = lines.find(l => l.agent === 1 && l.field === field);
      // A 10 mm gap at final scale prevents the two frames from touching.
      if (left && right && Math.max(left.x + left.width, left.bounds[2]) + 2.5 * MM > Math.min(right.x, right.bounds[0])) {
        errors.push(`The two ${field === "name" ? "names" : "phone numbers"} are too close. Shorten the details to keep them separate.`);
      }
    }
  }
  return { valid: errors.length === 0, errors, agents, lines, templateId: template.id };
}

const number = (value: number) => {
  if (!Number.isFinite(value)) throw new Error("Invalid PDF coordinate.");
  return Number(value.toFixed(7)).toString();
};
const encode = (value: string) => new TextEncoder().encode(value);
const combine = (chunks: Uint8Array[]): Uint8Array<ArrayBuffer> => {
  const result = new Uint8Array(chunks.reduce((size, c) => size + c.length, 0));
  let offset = 0;
  for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.length; }
  return result;
};

export function makePdf(template: Template, job: Job): Uint8Array<ArrayBuffer> {
  if (!job.valid || job.templateId !== template.id) throw new Error("The job must pass validation before export.");
  // Source and dynamic glyphs stay at the requested 25% delivery scale.
  const commands = ["q 1 0 0 1 0 0 cm", `0.796 0.675 0.459 0.337 k 0 0 ${number(WIDTH)} ${number(HEIGHT)} re f`, "q", template.staticCommands, "Q"];
  for (const line of job.lines) {
    commands.push(`q ${line.color.map(number).join(" ")} k`);
    let cursor = line.x;
    const scale = line.size / template.unitsPerEm;
    for (const c of line.text) {
      const glyph = template.glyphs[String(c.codePointAt(0))];
      if (glyph.path) commands.push(`q ${number(scale)} 0 0 ${number(scale)} ${number(cursor)} ${number(line.y)} cm\n${glyph.path}\nf\nQ`);
      cursor += glyph.advance * scale;
    }
    commands.push("Q");
  }
  const square = 1.25 * MM;
  commands.push(`0 1 1 0 k\n${number(BLEED - square)} ${number(BLEED - square)} ${number(square)} ${number(square)} re f\n${number(WIDTH - BLEED)} ${number(BLEED - square)} ${number(square)} ${number(square)} re f\nQ\n`);
  const content = encode(commands.join("\n"));
  const icc = Uint8Array.from(atob(template.iccBase64), c => c.charCodeAt(0));
  const sheet = `[0 0 ${number(WIDTH)} ${number(HEIGHT)}]`;
  const face = `[${number(BLEED)} ${number(BLEED)} ${number((WIDTH - BLEED))} ${number((HEIGHT - BLEED))}]`;
  const stream = (bytes: Uint8Array, extra = "") => combine([encode(`<< /Length ${bytes.length} ${extra} >>\nstream\n`), bytes, encode("\nendstream")]);
  const objects: Uint8Array[] = [
    encode("<< /Type /Catalog /Pages 2 0 R /OutputIntents [6 0 R] >>"),
    encode("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"),
    encode(`<< /Type /Page /Parent 2 0 R /MediaBox ${sheet} /CropBox ${sheet} /BleedBox ${sheet} /TrimBox ${face} /Resources << /ProcSet [/PDF] >> /Contents 4 0 R >>`),
    stream(content),
    stream(icc, "/N 4 /Alternate /DeviceCMYK"),
    encode("<< /Type /OutputIntent /S /GTS_PDFX /OutputConditionIdentifier (CGATS TR 001) /Info (U.S. Web Coated \\(SWOP\\) v2) /RegistryName (http://www.color.org) /DestOutputProfile 5 0 R >>"),
    encode(`<< /Title (Stone 6x4 Edgewrap - ${job.agents.length} Agent${job.agents.length === 2 ? "s" : ""} - 25 Percent Print) /Creator (Edgewrap Studio v1) /Subject (Face 1220 x 1832 mm; 65 mm bleed; two red 5 mm registration squares outside bottom face corners. Supplied at 25 percent. Output at 400 percent for final size.) >>`),
  ];
  const chunks: Uint8Array[] = [encode("%PDF-1.3\n%"), new Uint8Array([226, 227, 207, 211, 10])];
  let length = chunks.reduce((n, c) => n + c.length, 0);
  const offsets = [0];
  for (const [i, object] of objects.entries()) {
    offsets.push(length);
    const wrapped = combine([encode(`${i + 1} 0 obj\n`), object, encode("\nendobj\n")]);
    chunks.push(wrapped); length += wrapped.length;
  }
  const xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.slice(1).map(offset => `${String(offset).padStart(10, "0")} 00000 n \n`).join("")}trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info 7 0 R >>\nstartxref\n${length}\n%%EOF\n`;
  chunks.push(encode(xref));
  return combine(chunks);
}
