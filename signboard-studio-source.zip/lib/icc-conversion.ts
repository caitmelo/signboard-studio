import {instantiate,TYPE_RGB_8,TYPE_CMYK_8} from 'lcms-wasm';
let runtime:Promise<any>|undefined;
let target:Promise<Uint8Array>|undefined;
export async function rgbIccTransform(profile:Uint8Array,outputProfile?:Uint8Array){
  runtime??=instantiate(typeof window==='undefined'?undefined:{locateFile:()=>'/colour/lcms.wasm'}).catch(e=>{runtime=undefined;throw e});
  target??=fetch('/template/colour/CGATS001Compat-v2-micro.icc').then(async r=>{if(!r.ok)throw Error('Print colour profile could not load');return new Uint8Array(await r.arrayBuffer())}).catch(e=>{target=undefined;throw e});
  const [cms,output]=await Promise.all([runtime,outputProfile??target]);
  const inputHandle=cms.cmsOpenProfileFromMem(profile,profile.length),outputHandle=cms.cmsOpenProfileFromMem(output,output.length);
  let transform=0;
  try{
    if(!inputHandle||!outputHandle)throw Error('Invalid ICC profile');
    transform=cms.cmsCreateTransform(inputHandle,TYPE_RGB_8,outputHandle,TYPE_CMYK_8,0,0);
    if(!transform)throw Error('Unsupported ICC conversion');
  }finally{if(inputHandle)cms.cmsCloseProfile(inputHandle);if(outputHandle)cms.cmsCloseProfile(outputHandle)}
  return {
    convert(rgb:Uint8Array){if(!transform||rgb.length%3)throw Error('Invalid RGB colour samples');return cms.cmsDoTransform(transform,rgb,rgb.length/3) as Uint8Array},
    close(){if(transform){cms.cmsDeleteTransform(transform);transform=0}},
  };
}
