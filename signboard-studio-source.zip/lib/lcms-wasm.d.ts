declare module 'lcms-wasm' {
 export function instantiate(options?:{locateFile?:(name:string)=>string}):Promise<any>;
 export const TYPE_RGB_8:number;
 export const TYPE_CMYK_8:number;
}
