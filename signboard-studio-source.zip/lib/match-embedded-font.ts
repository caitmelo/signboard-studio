import type {FontData} from './template-types';
// Recognise anonymised embedded subsets by their vector outlines, not by a
// guessed family or similar-looking widths. Ambiguous matches stay embedded.
export async function matchEmbeddedFont(embedded:FontData,names:string[],load:(name:string)=>Promise<FontData|undefined>){
 const chars=Object.keys(embedded.glyphs).filter(cp=>/[A-Za-z]/.test(String.fromCodePoint(Number(cp)))&&embedded.glyphs[cp].path).slice(0,8);
 if(chars.length<3)return undefined;
 const matches:FontData[]=[];
 for(const name of names){let font:FontData|undefined;try{font=await load(name);}catch{continue;}if(!font)continue;let valid=true;
  for(const cp of chars){const a=embedded.glyphs[cp],b=font.glyphs[cp];if(!b||Math.abs(a.advance/embedded.unitsPerEm-b.advance/font.unitsPerEm)>.003){valid=false;break;}
   const aa=a.path.match(/[a-zA-Z]+|-?\d+(?:\.\d+)?/g)??[],bb=b.path.match(/[a-zA-Z]+|-?\d+(?:\.\d+)?/g)??[];
   if(aa.length!==bb.length||aa.some((v,i)=>/[a-z]/i.test(v)?v!==bb[i]:Math.abs(Number(v)/embedded.unitsPerEm-Number(bb[i])/font.unitsPerEm)>.0015)){valid=false;break;}
  }if(valid)matches.push(font);
 }
 const unique=[...new Map(matches.map(f=>[f.name,f])).values()];
 return unique.length===1?unique[0]:undefined;
}
