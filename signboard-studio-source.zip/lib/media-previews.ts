import type {MediaSlot} from './template-types';
// Fallback for PDFs whose embedded image codec cannot supply a thumbnail.
export async function fillMediaPreviews(data:Uint8Array,slots:MediaSlot[],pageIndex=0):Promise<MediaSlot[]>{
 if(typeof document==='undefined'||!slots.some(s=>s.role!=='fixed'&&!s.preview))return slots;
 let task:any;try{const url='/pdfjs/pdf.mjs';const lib=await import(/* @vite-ignore */ url);lib.GlobalWorkerOptions.workerSrc='/pdfjs/pdf.worker.mjs';task=lib.getDocument({data:data.slice(),isEvalSupported:false,wasmUrl:'/pdfjs/wasm/',standardFontDataUrl:'/pdfjs/standard_fonts/'});const doc=await task.promise,page=await doc.getPage(pageIndex+1),viewport=page.getViewport({scale:1});const scale=Math.min(2,1800/Math.max(viewport.width,viewport.height));const v=page.getViewport({scale});const canvas=document.createElement('canvas');canvas.width=Math.ceil(v.width);canvas.height=Math.ceil(v.height);await page.render({canvas,canvasContext:canvas.getContext('2d'),viewport:v}).promise;
 return slots.map(s=>{if(s.preview||s.role==='fixed')return s;const a=v.convertToViewportPoint(s.x,s.y),b=v.convertToViewportPoint(s.x+s.width,s.y+s.height),w=Math.abs(b[0]-a[0]),h=Math.abs(b[1]-a[1]);const c=document.createElement('canvas'),r=Math.min(240/w,180/h,1);c.width=Math.max(1,Math.round(w*r));c.height=Math.max(1,Math.round(h*r));c.getContext('2d')?.drawImage(canvas,Math.min(a[0],b[0]),Math.min(a[1],b[1]),w,h,0,0,c.width,c.height);return {...s,preview:c.toDataURL('image/png')};});
 }catch{return slots;}finally{await task?.destroy();}
}
