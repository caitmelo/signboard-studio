import {PDFName,PDFDict} from 'pdf-lib';
import {operations,multiply,type ContentSource} from './pdf-content';
import type {FontData,TextRun} from './template-types';

type Point=number[];
function sample(path:ReturnType<typeof operations>,matrix=[1,0,0,1,0,0]){
 const points:Point[]=[];let p=[0,0],start=p;
 const add=(q:Point)=>points.push([matrix[0]*q[0]+matrix[2]*q[1]+matrix[4],matrix[1]*q[0]+matrix[3]*q[1]+matrix[5]]);
 for(const op of path){let a=op.args.map(t=>Number(t.value));
  if(op.op==='m'){if(points.length)for(let n=1;n<=8;n++)add([p[0]+(start[0]-p[0])*n/8,p[1]+(start[1]-p[1])*n/8]);p=a;start=a;add(p);}
  else if(op.op==='l'||op.op==='h'){const q=op.op==='h'?start:a;for(let n=1;n<=8;n++)add([p[0]+(q[0]-p[0])*n/8,p[1]+(q[1]-p[1])*n/8]);p=q;}
  else if(['c','v','y'].includes(op.op)){if(op.op==='v')a=[...p,...a];if(op.op==='y')a=[...a,...a.slice(2)];for(let n=1;n<=16;n++){const t=n/16,u=1-t;add([u*u*u*p[0]+3*u*u*t*a[0]+3*u*t*t*a[2]+t*t*t*a[4],u*u*u*p[1]+3*u*u*t*a[1]+3*u*t*t*a[3]+t*t*t*a[5]]);}p=a.slice(4);}
 }
 if(!points.length)return;
 for(let n=1;n<=8;n++)add([p[0]+(start[0]-p[0])*n/8,p[1]+(start[1]-p[1])*n/8]);
 const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),box=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)],w=box[2]-box[0],h=box[3]-box[1];
 if(w<=0||h<=0)return;
 return {box,w,h,points:points.filter((_,i)=>i%Math.max(1,Math.floor(points.length/120))===0).map(p=>[(p[0]-box[0])/w,(p[1]-box[1])/h])};
}
function distance(a:Point[],b:Point[]){return a.reduce((sum,p)=>sum+Math.min(...b.map(q=>(p[0]-q[0])**2+(p[1]-q[1])**2)),0)/a.length;}

/** Recover large outlined sale headings only after a close vector-font match.
 * Logos, arbitrary illustrations, reused forms and unrecognised outlines stay fixed. */
export function recoverOutlinedHeadings(stream:ContentSource|undefined,fonts:Record<string,FontData>,minimumSize:number):TextRun[]{
 if(!stream||stream.key!=='page')return [];
 const candidates=Object.entries(fonts).flatMap(([name,font])=>Object.entries(font.glyphs).filter(([cp])=>/[A-Za-z]/.test(String.fromCodePoint(+cp))&&+cp<128).map(([cp,g])=>({name,font,cp,g,shape:sample(operations(g.path))})).filter(g=>g.shape));
 let state={matrix:[1,0,0,1,0,0],color:[0,0,0,1],safe:true},stack:typeof state[]=[],path:ReturnType<typeof operations>=[],clipped=false;
 const found:TextRun[]=[];
 for(const [index,op]of stream.ops.entries()){
  const a=op.args.map(t=>Number(t.value));
  if(op.op==='q')stack.push({...state,matrix:[...state.matrix],color:[...state.color]});else if(op.op==='Q')state=stack.pop()??state;
  else if(op.op==='cm')state.matrix=multiply(state.matrix,a);
  else if(op.op==='k')state.color=a;else if(op.op==='g')state.color=[0,0,0,1-a[0]];else if(op.op==='rg'||op.cmyk){if(op.cmyk)state.color=op.cmyk;else state.safe=false;}
  else if(op.op==='gs'){const resource=stream.resources?.lookup(PDFName.of('ExtGState'),PDFDict)?.lookup(PDFName.of(String(op.args[0]?.value)),PDFDict);if(!resource||['ca','CA','SMask','BM'].some(key=>{const v=resource.get(PDFName.of(key));return v!==undefined&&!['1','/None','/Normal','/Compatible'].includes(v.toString());}))state.safe=false;}
  if(['m','l','c','v','y','h'].includes(op.op))path.push(op);
  else if(['re','W','W*'].includes(op.op))clipped=true;
  else if(['f','f*','S','s','B','B*','n'].includes(op.op)){
   if(['f','f*'].includes(op.op)&&!clipped&&state.safe&&Math.abs(state.matrix[1])+Math.abs(state.matrix[2])<.001){
    const shape=sample(path,state.matrix);
    if(shape&&shape.h>minimumSize){
     const matches=candidates.filter(g=>Math.abs(shape.w/shape.h/(g.shape!.w/g.shape!.h)-1)<.018).map(g=>({...g,error:distance(shape.points,g.shape!.points)+distance(g.shape!.points,shape.points)})).sort((a,b)=>a.error-b.error);
     const best=matches[0];

     if(best&&best.error<.0012&&(!matches[1]||matches[1].cp===best.cp||matches[1].error>best.error*2)){
      const scale=shape.h/best.shape!.h,size=scale*best.font.unitsPerEm,x=shape.box[0]-best.shape!.box[0]*scale,y=shape.box[1]-best.shape!.box[1]*scale,text=String.fromCodePoint(+best.cp);
      found.push({id:`${stream.key}:${index}`,stream:stream.key,opIndex:index,text,x,y,size,width:best.g.advance*scale,horizontalScale:1,fontName:best.name,color:[...state.color],charSpace:0,wordSpace:0,role:'custom',label:text,supported:true,encodingComplete:true,positions:[0],outlined:true});
     }
    }
   }path=[];clipped=false;
  }
 }
 const rows:TextRun[][]=[];
 for(const f of found.sort((a,b)=>a.x-b.x)){const row=rows.find(r=>Math.abs(r[0].y-f.y)<f.size*.025&&r[0].fontName===f.fontName&&Math.abs(r[0].size-f.size)<f.size*.02);if(row)row.push(f);else rows.push([f]);}
 return rows.filter(row=>/^(For|Sale|Sold|SOLD|Auction|AUCTION)$/.test(row.map(f=>f.text).join(''))).flat();
}
