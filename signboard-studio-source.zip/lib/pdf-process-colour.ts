import {PDFArray, PDFContext, PDFDict, PDFName, PDFNumber, PDFRawStream, PDFRef} from 'pdf-lib';

// Recognise spaces that already contain process inks. Keep their PDF
// definitions (including tint transforms and ICC profiles) intact.
export function isProcessColourSpace(context:PDFContext,value:unknown,resources?:PDFDict,depth=0):boolean {
  if(depth>8)return false;
  const space=value instanceof PDFRef?context.lookup(value):value;
  if(space instanceof PDFName){
    const name=space.decodeText();
    if(name==='DeviceCMYK'||name==='DeviceGray')return true;
    const aliases=resources?.lookupMaybe(PDFName.of('ColorSpace'),PDFDict);
    return !!aliases&&isProcessColourSpace(context,aliases.get(space),resources,depth+1);
  }
  if(!(space instanceof PDFArray))return false;
  const kind=space.get(0).toString();
  if(kind==='/Indexed')return isProcessColourSpace(context,space.get(1),resources,depth+1);
  if(kind==='/ICCBased'){
    const profile=context.lookup(space.get(1));
    const count=profile instanceof PDFRawStream?profile.dict.lookupMaybe(PDFName.of('N'),PDFNumber)?.asNumber():undefined;
    return count===1||count===4;
  }
  if(kind==='/DeviceN'||kind==='/Separation'){
    const inks=context.lookup(space.get(1));
    const names=inks instanceof PDFArray?inks.asArray():[inks];
    return names.length>0&&names.every(ink=>ink instanceof PDFName&&['Cyan','Magenta','Yellow','Black','None','All'].includes(ink.decodeText()))&&isProcessColourSpace(context,space.get(2),resources,depth+1);
  }
  return false;
}
