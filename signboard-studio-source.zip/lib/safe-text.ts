import type {SavedTemplate,TextRun} from './template-types';

/** Move complete editable groups by the minimum amount needed to clear the
 * printer's safe area. Do not scale fonts, move fixed artwork or conceal a
 * group that cannot fit; ordinary preflight still checks those cases. */
export function correctSafeText(template:SavedTemplate,margin:number,face:[number,number,number,number]):SavedTemplate{
 if(!margin)return template;
 const safe=[face[0]+margin+.05,face[1]+margin+.05,face[2]-margin-.05,face[3]-margin-.05];
 const ink=(f:TextRun)=>{const font=template.fonts[f.fontName];if(!font)return f.bounds??[f.x,f.y-f.size*.2,f.x+f.width,f.y+f.size*.8];let advance=0;const boxes:number[][]=[];
  for(const [i,c]of [...f.text].entries()){const g=font.glyphs[String(c.codePointAt(0))];if(!g)continue;const scale=f.size/font.unitsPerEm,offset=f.positions?.length===[...f.text].length?f.positions[i]:advance,b=g.bounds;if(b)boxes.push([f.x+offset+b[0]*scale*f.horizontalScale,f.y+b[1]*scale,f.x+offset+b[2]*scale*f.horizontalScale,f.y+b[3]*scale]);advance+=g.advance*scale*f.horizontalScale+f.charSpace+(c===' '?f.wordSpace:0);}
  return boxes.length?[Math.min(...boxes.map(b=>b[0])),Math.min(...boxes.map(b=>b[1])),Math.max(...boxes.map(b=>b[2])),Math.max(...boxes.map(b=>b[3]))]:[f.x,f.y,f.x+f.width,f.y];};
 const groups=(template.groups??[]).map(g=>g.fieldIds),used=new Set(groups.flat());for(const f of template.fields)if(!used.has(f.id))groups.push([f.id]);
 const moves=new Map<string,[number,number]>();
 for(const ids of groups){const fields=template.fields.filter(f=>ids.includes(f.id));if(!fields.length)continue;const boxes=fields.map(ink),b=[Math.min(...boxes.map(x=>x[0])),Math.min(...boxes.map(x=>x[1])),Math.max(...boxes.map(x=>x[2])),Math.max(...boxes.map(x=>x[3]))];
  if(b[2]-b[0]>safe[2]-safe[0]||b[3]-b[1]>safe[3]-safe[1])continue;
  const dx=Math.max(safe[0]-b[0],Math.min(0,safe[2]-b[2])),dy=Math.max(safe[1]-b[1],Math.min(0,safe[3]-b[3]));if(Math.abs(dx)<.0001&&Math.abs(dy)<.0001)continue;for(const f of fields)moves.set(f.id,[dx,dy]);
 }
 if(!moves.size)return template;
 const shift=(b:number[]|undefined,dx:number,dy:number)=>b?.map((v,i)=>v+(i%2?dy:dx));
 return {...template,safeTextCorrected:true,fields:template.fields.map(f=>{const m=moves.get(f.id);return m?{...f,x:f.x+m[0],y:f.y+m[1],bounds:shift(f.bounds,...m),clip:shift(f.clip,...m)}:f;})};
}
