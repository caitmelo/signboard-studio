import {PDFArray,PDFDocument,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {operations,latin,multiply} from './pdf-content';

/** Recognise a complete rectangular printer frame, never a lone artwork line. */
export async function signboardFrame(doc:PDFDocument,pageIndex:number){
 const page=doc.getPage(pageIndex),media=page.getMediaBox(),contents=page.node.Contents();
 const raw=(contents instanceof PDFArray?contents.asArray():[contents]).map(ref=>{const s=doc.context.lookup(ref);return s instanceof PDFRawStream?latin(decodePDFRawStream(s).decode()):'';}).join('\n');
 let matrix=[1,0,0,1,0,0],stack:number[][]=[],points:number[][]=[];
 const vertical:number[]=[],horizontal:number[]=[];
 for(const op of operations(raw)){
  const a=op.args.map(t=>Number(t.value));
  if(op.op==='q')stack.push([...matrix]);else if(op.op==='Q')matrix=stack.pop()??matrix;
  else if(op.op==='cm')matrix=multiply(matrix,a);
  else if(op.op==='m'||op.op==='l')points.push([matrix[0]*a[0]+matrix[2]*a[1]+matrix[4],matrix[1]*a[0]+matrix[3]*a[1]+matrix[5]]);
  else if(['c','v','y','re'].includes(op.op))points=[];
  else if(['S','s','f','f*','B','B*','n'].includes(op.op)){
   if(['S','s'].includes(op.op)&&points.length===2){const [p,q]=points;
    if(Math.abs(p[0]-q[0])<.2&&Math.abs(p[1]-q[1])>media.height*.95)vertical.push(p[0]);
    if(Math.abs(p[1]-q[1])<.2&&Math.abs(p[0]-q[0])>media.width*.95)horizontal.push(p[1]);
   }points=[];
  }
 }
 const left=vertical.find(x=>x>media.x&&x<media.x+media.width*.08),right=vertical.find(x=>x<media.x+media.width&&x>media.x+media.width*.92);
 const bottom=horizontal.find(y=>y>media.y&&y<media.y+media.height*.08),top=horizontal.find(y=>y<media.y+media.height&&y>media.y+media.height*.92);
 return left!==undefined&&right!==undefined&&bottom!==undefined&&top!==undefined?{x:left,y:bottom,width:right-left,height:top-bottom}:undefined;
}
