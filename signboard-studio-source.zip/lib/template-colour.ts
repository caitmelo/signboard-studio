export function colourConverter(table: Uint8Array) {
  if (table.length !== 33*33*33*4) throw new Error("The print colour profile could not be loaded.");
  return (rgb: number[]) => {
    const scaled=rgb.map(v=>Math.max(0,Math.min(1,v))*32),lo=scaled.map(v=>Math.min(31,Math.floor(v))),fraction=scaled.map((v,i)=>v-lo[i]);
    const out=[0,0,0,0];
    for(let r=0;r<=1;r++)for(let g=0;g<=1;g++)for(let b=0;b<=1;b++){
      const weight=(r?fraction[0]:1-fraction[0])*(g?fraction[1]:1-fraction[1])*(b?fraction[2]:1-fraction[2]);
      const index=(((lo[0]+r)*33+lo[1]+g)*33+lo[2]+b)*4;
      for(let c=0;c<4;c++)out[c]+=table[index+c]/255*weight;
    }
    return out.map(v=>Math.round(v*1000000)/1000000);
  };
}
