import type {MediaSlot} from './template-types';

export function combineFragments(slots:MediaSlot[],parentId:string,ids:string[]):MediaSlot[]{
 const parent=slots.find(s=>s.id===parentId);
 const children=slots.filter(s=>ids.includes(s.id)&&s.id!==parentId);
 if(!parent||!children.length)throw new Error('Select a main photo and at least one fragment.');
 if([parent,...children].some(s=>!s.supported||s.region||s.role==='qr'))throw new Error('Only supported photo frames can be combined.');
 if(children.some(s=>s.x<parent.x-2||s.y<parent.y-2||s.x+s.width>parent.x+parent.width+2||s.y+s.height>parent.y+parent.height+2))throw new Error('Fragments must sit inside the main photo frame. Adjacent tiles need a complete photo frame prepared in the source artwork.');
 const removed=new Set(children.map(s=>s.id));
 return slots.filter(s=>!removed.has(s.id)).map(s=>s.id===parentId?{...s,role:'image',assetKind:'photo',fragments:[...(s.fragments??[]),...children.flatMap(c=>[{...c,role:'image' as const,fragments:undefined},...(c.fragments??[])])],flattenedShading:s.flattenedShading||children.some(c=>c.flattenedShading)}:s);
}

export function separateFragments(slots:MediaSlot[],id:string):MediaSlot[]{
 return slots.flatMap(s=>s.id===id?[{...s,fragments:undefined},...(s.fragments??[]).map(f=>({...f,flattenedShading:s.flattenedShading||f.flattenedShading}))]:[s]);
}
