import { env } from "cloudflare:workers";
class RequestError extends Error { constructor(message:string,public status:number){super(message);} }

export function storage() {
  if (!env.DB || !env.BUCKET) throw new Error("Template storage is temporarily unavailable. Your file is still open; please try saving again.");
  return { db: env.DB, bucket: env.BUCKET };
}
export function user(request: Request) {
  const id = request.headers.get("oai-authenticated-user-id");
  if (!id) throw new RequestError("Sign in to save or open your templates.",401);
  return id;
}
export function checkOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) throw new RequestError("This request must come from the template app.",403);
}
export async function ownedTemplate(request: Request, id: string) {
  const { db, bucket } = storage();
  const owner = user(request);
  const template = await db.prepare("SELECT * FROM sign_templates WHERE id = ? AND owner_id = ?").bind(id, owner).first();
  return { template, db, bucket, owner };
}
export function failure(error: unknown, status = 503) {
  console.error("Template request failed", error instanceof Error ? error.message : "Unknown error");
  return Response.json({ error: error instanceof Error ? error.message : "The template could not be saved. Please try again." }, { status:error instanceof RequestError?error.status:status });
}
