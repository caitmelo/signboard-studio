import type {TextRun} from './template-types';

/** Infer alignment only from geometric evidence; retain the source frame. */
export function inferTextAlignment(fields:TextRun[],pageWidth:number):TextRun[]{
 const centre=(f:TextRun)=>f.x+f.width/2;
 return fields.map(f=>{
  if(f.align)return f;
  const tolerance=Math.max(.4,f.size*.12);
  if(f.outlined&&Math.abs(centre(f)-pageWidth/2)<tolerance)return {...f,align:'center'};
  const pair=f.role.match(/^(agent[12])_(name|phone)$/);
  const peer=pair?fields.find(r=>r.role===`${pair[1]}_${pair[2]==='name'?'phone':'name'}`):undefined;
  // Equal left edges indicate a left-aligned card, even when widths are close.
  if(peer&&Math.abs(f.y-peer.y)>f.size*.5&&Math.abs(centre(f)-centre(peer))<tolerance&&Math.abs(f.x-peer.x)>Math.max(.4,Math.min(f.size,peer.size)*.03))
   return {...f,align:'center'};
  // Standalone centred contact lines, with no competing text in the row.
  if(/@|(?:[a-z0-9-]+\.)+(?:com|au|net|org)\b/i.test(f.text)&&Math.abs(centre(f)-pageWidth/2)<tolerance&&
    !fields.some(r=>r.id!==f.id&&Math.abs(r.y-f.y)<f.size*.6))return {...f,align:'center'};
  if(f.clip&&f.x-f.clip[0]>f.size*.5){
   if(Math.abs(centre(f)-(f.clip[0]+f.clip[2])/2)<tolerance)return {...f,align:'center'};
   if(Math.abs(f.x+f.width-f.clip[2])<.2)return {...f,align:'right'};
  }
  return f;
 });
}
