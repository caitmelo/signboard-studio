import {operations,multiply,type FontSource} from './pdf-content';
import type {FontData} from './template-types';
// PDF Type 3 fonts are embedded drawing programs, not missing font files.
// Recover monochrome vector glyphs in font units, retaining their exact shapes.
export function fontFromType3(source:FontSource):FontData{
 if(!source.type3)throw Error('Not a Type 3 font');
 const glyphs:FontData['glyphs']={},base=source.type3.matrix.map(n=>n*1000);
 for(const [cp,c]of Object.entries(source.characters??{})){
  const raw=c.glyphName&&source.type3.programs[c.glyphName];if(!raw)continue;
  let matrix=[...base],stack:number[][]=[],path:string[]=[],painted:string[]=[];const points:number[][]=[];
  const point=(x:number,y:number)=>{const p=[matrix[0]*x+matrix[2]*y+matrix[4],matrix[1]*x+matrix[3]*y+matrix[5]];points.push(p);return p.map(v=>Number(v.toFixed(6))).join(' ')};
  let current=[0,0];
  for(const op of operations(raw)){const a=op.args.map(t=>Number(t.value));switch(op.op){
   case'd0':case'd1':break;
   case'q':stack.push([...matrix]);break;case'Q':matrix=stack.pop()??base;break;
   case'cm':matrix=multiply(matrix,a);break;
   case'm':case'l':path.push(point(a[0],a[1])+' '+op.op);current=a;break;
   case'c':path.push(point(a[0],a[1])+' '+point(a[2],a[3])+' '+point(a[4],a[5])+' c');current=a.slice(4);break;
   case'v':path.push(point(current[0],current[1])+' '+point(a[0],a[1])+' '+point(a[2],a[3])+' c');current=a.slice(2);break;
   case'y':path.push(point(a[0],a[1])+' '+point(a[2],a[3])+' '+point(a[2],a[3])+' c');current=a.slice(2);break;
   case're':{const[x,y,w,h]=a;path.push(point(x,y)+' m',point(x+w,y)+' l',point(x+w,y+h)+' l',point(x,y+h)+' l','h');break;}
   case'h':path.push('h');break;
   case'f':case'F':painted.push(...path);path=[];break;case'n':path=[];break;
   default:throw Error('Complex Type 3 drawing requires original artwork');
  }}
  if(painted.length||Number(cp)===32)glyphs[cp]={advance:c.width*base[0],path:painted.join('\n'),bounds:points.length?[Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))]:null};
 }
 if(!Object.keys(glyphs).length)throw Error('No vector glyphs');
 return{name:source.name,unitsPerEm:1000,glyphs,source:'embedded',subset:true};
}
