# Template test results — 16 September 2026

Seven supplied designs were tested across 14 PDF pages. Tests used native Python, the HTTP API, the hosted Pyodide engine, and visual inspection of rendered PDFs. Browser click-through testing could not run because the managed preview service was unavailable.

## Results

| Design | PDF pages | Verified changes | Remaining source/print issues |
|---|---:|---|---|
| A4 six-panel tri-fold | 2 unfolded sheets | Agent text, photos, QR, circular crops, page order | Colour/pattern and safe-margin warnings; hiding agent 2 leaves a fixed white headshot backing |
| A5 four-page booklet | 4 | Agent names/phones, photos, QR, page order | Colour/pattern and safe-margin warnings |
| A4 double-sided | 2 | Agent text, photos, QR, page order | Colour/pattern warnings |
| Just Listed DL, one agent | 2 | Caitlin Micallef / 0449 754 440, property photos, circular headshot crop | JUST SOLD now verified with supplied MyriadPro-Regular; source still has no bleed and overlapping website text |
| One photo 6 × 4 | 1 | Agent text, photo, QR; viewing label retained | Source size conflict, colour/profile issues and low-resolution fixed artwork |
| Three-photo 6 × 4 | 1 | Three photo frames, replacement/reordering, agent text, QR | Source proportions conflict; flattened shading requires review after replacement |
| 6 × 4 portrait | 1 | Agent text and property photo | Source size conflict, colour/profile and low-resolution fixed artwork; raster lettering remains fixed |

These files remain proofs while their print issues are unresolved. They are not all approved for printing.

## Checks completed

- Unchanged and edited outputs retain all pages in source order.
- PDF trim dimensions checked at 25% of the template face; print at 400% to recover the intended physical size. Bleed and marks scale with the page.
- Six generated QR codes decoded to https://www.beleef.com.au/.
- Native API accepted a roughly 100 MB source, saved/reopened a four-page template and returned a four-page PDF.
- Multipart route checked for ownership, ordered parts, exact completed size and immutable saved assets using a mocked storage binding; real hosted browser multipart upload remains untested.
- Unknown field keys, oversized agent names and print requests for proof-only templates were rejected.
- The updated Python engine produced a two-page edited DL PDF in Pyodide.

## Changes included

Multi-page templates now share one saved document, with page-specific field keys and page navigation. Uploads allow 150 MB and use lossless structural optimisation; hosted large uploads use 8 MB parts. Optimisation does not lower photograph resolution and is not guaranteed to make every file smaller.

Recognised small-format sources with uniform surplus bleed are prepared to the configured 2 mm bleed while retaining their finished face. Size conflicts still require review. Agent pairing, right-aligned phone replacement, email visibility, QR palette decoding and photo-versus-artwork classification were improved.

## Limits

Arbitrary PDFs cannot be guaranteed to become fully editable. Rasterised text, outlined letters, flattened effects and complex clipping may require source artwork or explicit template correction. Full matching fonts are needed when replacement text uses characters absent from embedded subsets. No silent font substitution is used.

The tri-fold needs a prepared one-agent variant or a correctly isolated headshot backing before its one-agent layout is production-ready. The supplied replacement photos were used for property-image tests; circular headshots were tested with their original images and changed crop settings.

The Python package contains a native Python HTTP backend and renderer, plus a browser frontend that still performs PDF analysis in TypeScript. Docker was not available and the container image was not built here. GitHub handoff requires a selected repository; the package is available from the test site.

## Myriad Pro update

All ten supplied Myriad Pro styles are installed. The two-page DL template was reanalysed and rendered successfully with JUST SOLD using MyriadPro-Regular, at 25% size (52.5 mm trim width). The heading was visually checked. Existing saved templates can pick up the full font through Edit text, media & print settings (new copy); stale embedded subsets no longer override a newly available full font during this process. Other print warnings remain unchanged.
