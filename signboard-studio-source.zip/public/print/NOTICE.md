Ghostscript WebAssembly 9.56.0, distributed by @jspawn/ghostscript-wasm 0.0.2.
Licensed under GNU AGPLv3; see LICENSE.
Corresponding build source: https://github.com/jsscheller/ghostscript-wasm
Upstream Ghostscript source: https://github.com/ArtifexSoftware/ghostpdl
Unmodified gs.js and gs.wasm are distributed here.
