/* Isolated PDF 1.3 prepress conversion. A fresh worker releases all WASM memory. */
importScripts('/print/gs.js');
self.onmessage=async({data})=>{
 const messages=[];
 try{
  const gs=await Module({noInitialRun:true,locateFile:()=>'/print/gs.wasm',print:()=>{},printErr:m=>messages.push(String(m))});
  gs.FS.writeFile('/input.pdf',data.pdf);
  if(data.icc)gs.FS.writeFile('/output.icc',data.icc);
  const args=['-sDEVICE=pdfwrite','-dCompatibilityLevel='+data.version,'-dNoOutputFonts','-dSAFER','-dBATCH','-dNOPAUSE','-dAutoRotatePages=/None','-dDownsampleColorImages=false','-dDownsampleGrayImages=false','-dDownsampleMonoImages=false','-dAutoFilterColorImages=false','-dAutoFilterGrayImages=false','-dColorImageFilter=/FlateEncode','-dGrayImageFilter=/FlateEncode','-sColorConversionStrategy=CMYK','-sProcessColorModel=DeviceCMYK','-dPreserveSeparation=false','-dPreserveDeviceN=false','-r300','-sOutputFile=/output.pdf'];
  if(data.icc)args.push('-sOutputICCProfile=/output.icc');
  const status=gs.callMain([...args,'/input.pdf']);
  if(status!==0)throw Error(messages.slice(-3).join(' ')||'Print conversion failed.');
  const pdf=gs.FS.readFile('/output.pdf');self.postMessage({pdf},[pdf.buffer]);
 }catch(e){self.postMessage({error:'The PDF 1.3 print conversion could not finish. '+(e.message||String(e))});}
};
