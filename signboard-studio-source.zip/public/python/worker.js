/* Python executes off the UI thread. Runtime and wheels are served by this site. */
let runtime;
async function ready() {
  if (!runtime) runtime = (async () => {
    importScripts('/python/vendor/pyodide.js');
    const py = await loadPyodide({indexURL:'/python/vendor/'});
    for (const name of ['pypdf','qrcode']) {
      const response = await fetch(`/python/vendor/${name}.whl`);
      if (!response.ok) throw new Error(`Could not load ${name}. Reload and try again.`);
      py.FS.writeFile(`/tmp/${name}.whl`, new Uint8Array(await response.arrayBuffer()));
      await py.runPythonAsync(`import zipfile, sys\nzipfile.ZipFile('/tmp/${name}.whl').extractall('/home/pyodide/packages')\nif '/home/pyodide/packages' not in sys.path: sys.path.insert(0, '/home/pyodide/packages')`);
    }
    const response = await fetch('/python/engine.py', {cache:'no-cache'});
    if (!response.ok) throw new Error('Python engine could not load.');
    await py.runPythonAsync(await response.text());
    return py;
  })().catch(error=>{runtime=undefined;throw error;});
  return runtime;
}
let queue=Promise.resolve();
self.onmessage=({data})=>{
  queue=queue.then(async()=>{
    try {
      const py=await ready();
      // Large PDFs exceed the JS/Python string bridge. Transfer UTF-8 through FS.
      const {baseBytes,iccBytes,...metadata}=data.payload;
      if(baseBytes)py.FS.writeFile('/tmp/base.pdf',baseBytes);
      if(iccBytes)py.FS.writeFile('/tmp/profile.icc',iccBytes);
      py.FS.writeFile('/tmp/request.json',new TextEncoder().encode(JSON.stringify(metadata)));
      await py.runPythonAsync("request_payload = open('/tmp/request.json', encoding='utf-8').read()");
      let result;
      if(data.action==='bundle') {
        result=await py.runPythonAsync(`import zipfile\n_p=json.loads(request_payload)\n_o=io.BytesIO()\nwith zipfile.ZipFile(_o,'w',zipfile.ZIP_DEFLATED) as _z:\n    for _k,_v in _p.items(): _z.writestr(_k,base64.b64decode(_v))\nbase64.b64encode(_o.getvalue()).decode()`);
      } else if(data.action==='render') {
        await py.runPythonAsync(`_p=json.loads(request_payload)
_base=open('/tmp/base.pdf','rb').read() if 'base' not in _p else base64.b64decode(_p['base'])
_icc=open('/tmp/profile.icc','rb').read() if 'icc' not in _p else base64.b64decode(_p['icc'])
_pdf,_issues=render(_base,_p['template'],_p['job'],_icc,_p.get('assets',{}))
with open('/tmp/rendered.pdf','wb') as _out: _out.write(_pdf)
del _p, _pdf, _base, _icc`);
        const pdf=py.FS.readFile('/tmp/rendered.pdf');
        self.postMessage({id:data.id,result:{pdfBytes:pdf}},[pdf.buffer]);
        return;
      } else result=JSON.parse(await py.runPythonAsync('render_edgewrap_json(request_payload)'));
      self.postMessage({id:data.id,result});
    } catch(error) {self.postMessage({id:data.id,error:String(error.message||error).trim().split('\n').filter(Boolean).pop().replace(/^(?:JobError|ValueError): /,'')});}
    finally { if(runtime){const py=await runtime.catch(()=>null);if(py){for(const path of ['/tmp/request.json','/tmp/rendered.pdf','/tmp/base.pdf','/tmp/profile.icc']){try{py.FS.unlink(path);}catch{}}await py.runPythonAsync("request_payload = None\nimport gc\ngc.collect()");}} }
  });
};
