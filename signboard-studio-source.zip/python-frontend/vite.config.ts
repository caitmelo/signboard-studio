import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
export default defineConfig({root:path.resolve('python-frontend'),plugins:[react()],resolve:{alias:{'@':path.resolve('.')}},publicDir:false,build:{outDir:path.resolve('python/web'),emptyOutDir:true},css:{postcss:path.resolve('.')}});
