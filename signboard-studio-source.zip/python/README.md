# Signboard Studio — Python edition

## Start and test

This package includes a ready-built web editor and Python PDF engine/API. Node is **not required to run it**.

With Docker installed:

```sh
docker compose up --build
```

Open **http://localhost:8000**. The Compose port is bound to localhost. Uploaded templates persist in the `studio-data` volume.

Without Docker (Python 3.12+):

```sh
python -m venv .venv
# macOS/Linux:
. .venv/bin/activate
# Windows instead: .venv\Scripts\activate
pip install -r requirements.txt
python -m signboard_studio.server
```

Upload a PDF, confirm its suggested category and size (or select another standard size / enter millimetres), review the detected groups/media and print settings, then save. For templates already saved on the hosted test site, click **Export template for Python** in their editor, and import the ZIP under **Python package** in this app.

The hosted test site runs this same `engine.py` using browser Python (Pyodide). Here, PDF jobs run in server-side CPython. Live previews render the visible page in TypeScript without starting Python; full-document downloads and API jobs use Python. The browser editor and PDF analysis remain TypeScript/JavaScript; they are included, not rewritten as Python. No Canva dependency is needed. Existing hosted template data is not automatically copied into this package.

## API integration

Your web/mobile backend sends one job per saved template. Do not create endpoints for individual fields. Get each template's keys first:

```
GET /api/templates
GET /api/templates/{id}/schema
POST /api/templates/{id}/render
```

Example job (use keys returned by your template's schema):

```json
{
  "mode": "print",
  "agents": [{"name": "Alex Smith", "phone": "0400 123 456"}],
  "content": {
    "heading": "A place to call home",
    "viewing": {"mode": "appointment"}
  },
  "media": {
    "image_1": {"assetId": "ID_FROM_UPLOAD", "fit": "cover", "focalX": 0.5, "focalY": 0.5},
    "qr_1": {"url": "https://example.com/property/123"}
  }
}
```

Unknown keys, missing characters, overlaps and invalid URLs return 422. A print request with outstanding print issues returns `status: "proof_only"`; it never silently becomes a final print file. Send `mode: "proof"` explicitly to inspect a flagged design. A successful render returns PDF bytes and `X-Print-Scale: 25%|100%`, `X-Render-Engine: python`, `X-Print-Status: ready|proof`.

Other supported routes:

| Method / path | Purpose |
| --- | --- |
| POST `/api/templates` | Create draft: `{name, sourceName}` |
| PUT `/api/templates/{id}/assets/{asset}` | Upload `source`, `base`, `manifest`, `thumbnail` |
| POST `/api/templates/{id}/complete` | Validate and lock a reviewed template |
| POST `/api/templates/import` | Import the exported template ZIP |
| GET `/api/templates/{id}/assets/{asset}` | Get an existing template asset |
| POST `/api/templates/{id}/media` | Upload a prepared CMYK image PDF from the editor |
| GET `/api/templates/{id}/media/{assetId}` | Get image asset |
| POST `/api/python/render` | Stateless render using base64 base, manifest, job and prepared image assets |
| GET `/health` | Runtime health |

`sourceSlot` instead of `assetId` reorders an original photo from another editable image slot. Cropping values are between 0 and 1. Frames and original clipping paths stay in place, including circular headshots. The current image upload API accepts the editor's prepared CMYK image PDFs, not arbitrary remote URLs. A developer can use the included preparation utility for raw JPEG/PNG assets.

## Print contract

- Signboards export at **25%** (print at **400%**). All other print products export at **100%**, including letters, brochures, booklets and mailcards.
- Bleed, artwork and signboard registration squares scale together.
- Letters require no bleed or registration marks. All other categories require actual source bleed; an empty margin is not accepted as print-ready.
- Signboards receive the established two red 5 mm squares at full physical size (1.25 mm in the output PDF).
- Supplied fonts are retained in the web editor; dynamic text is drawn as vector glyph outlines in PDFs.
- Retains the original template coordinates. One-agent mode hides agent 2 in uploaded templates; it does not recenter agent 1. The original hand-built Edgewrap preset retains its explicit centered layout.
- Existing colour/profile, resolution and flattened-artwork guards remain. This is not a certified general-purpose PDF/X preflight system.

## Developer handoff / scale

The included HTTP server is a single-workspace local test and reference integration server, not a multi-tenant SaaS deployment. `SIGNBOARD_API_TOKEN` enables Bearer-token access to the API (the local UI can sign in under Python package). Do not expose the unauthenticated local-test mode to the internet. Use TLS and your existing authentication/authorization in production; isolate template ownership and media per tenant. Never pass a client-supplied owner ID through without checking it.

For production, call `signboard_studio.engine.render(base_bytes, manifest, job, icc_bytes, image_assets)` from a worker process. Put job IDs in your existing queue, store assets in object storage and record template/job metadata in your database. Scale worker containers independently of your web/app API. Apply process memory/time limits and per-tenant quotas for untrusted PDFs. The reference server caps concurrent renders at two and returns 429 when busy; it does not implement a distributed queue.

Template versions should be immutable. Correct an analysis once in the editor, save a new version, then map your listing/CRM fields to that version's schema. Do not re-analyse the PDF for every print job. Your app should store mappings such as `listing.address -> content.address`, `agents -> agents`, and photo asset IDs -> media keys.

`frontend-source/` contains the editor source and pinned Node dependencies for future UI changes. To rebuild it: install the lockfile with `npm ci`, run `node node_modules/vite/bin/vite.js build --config python-frontend/vite.config.ts`, then copy the built `python/web/assets` and `index.html` into this package's `web/`. Keep `public/template`, `public/pdfjs`, `public/python` and favicon assets in `web/` as well. These build commands are not required to run the packaged app.

## Large PDFs and preparation

The editor accepts PDFs up to 150 MB. It performs lossless PDF structural optimisation and sends large hosted assets in 8 MB parts. It does not downsample source photos to satisfy a file-size limit. Python output deduplicates objects where possible. Original image resources may remain referenced after replacement, so output files can still be large. No aggressive image compression is applied.

For recognised A-series/DL sheets with uniform 3–5 mm bleed, preparation removes only the surplus outside the required 2 mm, preserving the full trim face. Tri-fold A4 sheets are treated as unfolded sheets, not squeezed onto one A4 page. Conflicting signboard dimensions still require confirmation.

## Known limitations

PDF import uses the current browser analysis engine. Scanned/outlined text is not automatically OCR-reconstructed. Complex clipping and baked-in image effects can require correction or editable source artwork. Multi-page documents are saved as one template and downloaded as one PDF in original page order. Turn off “Include all pages” when a PDF contains reference-only pages. Each page has its own field and media keys (for example `p1_heading`, `p2_image_1`); `agents` or agent role keys can populate matching roles across pages. No automatic claim of 100% fidelity for arbitrary PDFs is made.

The package does not include your hosted saved templates or jobs. Export only the templates you want to hand over. GitHub upload requires a chosen destination repository; this ZIP can be committed there by your developer.

## Automatic fonts

The editor checks the supplied font catalogue first. If a family/style is absent, `/api/fonts` retrieves it from the Google Fonts CSS service and downloads the font files. No API key is needed. The browser checks the returned font's internal name before using its outlines; a wrong family or weight is rejected. Successful outlines are saved with the template, so future jobs do not need to download that font again. Provider responses are cached for up to 24 hours.

The native Python server includes the same endpoint. Outbound HTTPS access to fonts.googleapis.com and fonts.gstatic.com is required. Only family/style metadata is sent. Proprietary families absent from Google Fonts still require a matching centrally supplied font. PDF names with unusual naming conventions may require an alias; no similar-looking fallback is silently substituted.

Small-format print export requires the `gs` (Ghostscript) command. The supplied Docker image installs it. The web studio includes an isolated WebAssembly converter. Export uses PDF 1.3, CMYK process colour, outlined fonts, and 300 dpi transparency flattening without image downsampling.
