# Template test results — 16 September 2026

Seven supplied designs were tested across 14 PDF pages. Tests used native Python, the HTTP API, the hosted Pyodide engine, and visual inspection of rendered PDFs. Browser click-through testing could not run because the managed preview service was unavailable.

## Results

| Design | PDF pages | Verified changes | Remaining source/print issues |
|---|---:|---|---|
| A4 six-panel tri-fold | 2 unfolded sheets | Agent text, photos, QR, circular crops, page order | Colour/pattern and safe-margin warnings; hiding agent 2 leaves a fixed white headshot backing |
| A5 four-page booklet | 4 | Agent names/phones, photos, QR, page order | Colour/pattern and safe-margin warnings |
| A4 double-sided | 2 | Agent text, photos, QR, page order | Colour/pattern warnings |
| Just Listed DL, one agent | 2 | Caitlin Micallef / 0449 754 440, property photos, circular headshot crop | JUST SOLD now verified with supplied MyriadPro-Regular; source still has no bleed and overlapping website text |
| One photo 6 × 4 | 1 | Agent text, photo, QR; viewing label retained | Source size conflict, colour/profile issues and low-resolution fixed artwork |
| Three-photo 6 × 4 | 1 | Three photo frames, replacement/reordering, agent text, QR | Source proportions conflict; flattened shading requires review after replacement |
| 6 × 4 portrait | 1 | Agent text and property photo | Source size conflict, colour/profile and low-resolution fixed artwork; raster lettering remains fixed |

These files remain proofs while their print issues are unresolved. They are not all approved for printing.

## Checks completed

- Unchanged and edited outputs retain all pages in source order.
- PDF trim dimensions checked at 25% of the template face; print at 400% to recover the intended physical size. Bleed and marks scale with the page.
- Six generated QR codes decoded to https://www.beleef.com.au/.
- Native API accepted a roughly 100 MB source, saved/reopened a four-page template and returned a four-page PDF.
- Multipart route checked for ownership, ordered parts, exact completed size and immutable saved assets using a mocked storage binding; real hosted browser multipart upload remains untested.
- Unknown field keys, oversized agent names and print requests for proof-only templates were rejected.
- The updated Python engine produced a two-page edited DL PDF in Pyodide.

## Changes included

Multi-page templates now share one saved document, with page-specific field keys and page navigation. Uploads allow 150 MB and use lossless structural optimisation; hosted large uploads use 8 MB parts. Optimisation does not lower photograph resolution and is not guaranteed to make every file smaller.

Recognised small-format sources with uniform surplus bleed are prepared to the configured 2 mm bleed while retaining their finished face. Size conflicts still require review. Agent pairing, right-aligned phone replacement, email visibility, QR palette decoding and photo-versus-artwork classification were improved.

## Limits

Arbitrary PDFs cannot be guaranteed to become fully editable. Rasterised text, outlined letters, flattened effects and complex clipping may require source artwork or explicit template correction. Full matching fonts are needed when replacement text uses characters absent from embedded subsets. No silent font substitution is used.

The tri-fold needs a prepared one-agent variant or a correctly isolated headshot backing before its one-agent layout is production-ready. The supplied replacement photos were used for property-image tests; circular headshots were tested with their original images and changed crop settings.

The Python package contains a native Python HTTP backend and renderer, plus a browser frontend that still performs PDF analysis in TypeScript. Docker was not available and the container image was not built here. GitHub handoff requires a selected repository; the package is available from the test site.

## Myriad Pro update

All ten supplied Myriad Pro styles are installed. The two-page DL template was reanalysed and rendered successfully with JUST SOLD using MyriadPro-Regular, at 25% size (52.5 mm trim width). The heading was visually checked. Existing saved templates can pick up the full font through Edit text, media & print settings (new copy); stale embedded subsets no longer override a newly available full font during this process. Other print warnings remain unchanged.

## Letter paragraph recognition

The supplied just listed & SOLD LETTER PDF now produces two body-paragraph groups (seven source text spans and three source lines respectively). Greeting and sign-off remain separate. Both paragraph edits were rendered and visually checked. Same-row text spans use bounded widths, and unchanged spans retain original whitespace and positions. Upload the source again to apply new automatic grouping; previously saved group definitions are preserved.

## Automatic font service

Fetched Lato Bold from the live Google Fonts service through the native Python adapter. Verified its font outlines through the actual editor parser, rejected a Regular/Bold mismatch, and checked local-first resolution and repeated-lookup caching. Hosted browser end-to-end validation remains unavailable in this environment.

## Large-document live preview regression

The 101 MB A4 tri-fold previously failed in Pyodide's JavaScript-to-Python string bridge (`RangeError: Invalid array length`). The worker now passes input through its UTF-8 filesystem and returns generated PDF bytes directly. Tested the actual worker with the supplied two-page tri-fold and `Newly Updated / Traditional Home`; generated and visually checked the replacement heading in the PDF. Content edits also leave original-comparison mode automatically. This was a worker/runtime check, not a hosted browser UI test.

## Browser input transport follow-up

Retested the reattached 101,486,180-byte tri-fold using the builder's all-page values and media, with `Newly Updated / Family Residence`. The v24 worker rendered it locally; the reported hosted UI failure was not reproduced. Removed the remaining main-thread base64 conversion for browser rendering: PDF and profile now travel as byte arrays, while only metadata uses JSON. Actual worker regression passed with binary input. Hosted browser interaction remains unverified.

## 17 September: previews and content grouping

- Live editor previews now use the existing TypeScript renderer for only the visible page, independently of Pyodide initialization. Full-document downloads and API renders continue through Python at 25% scale.
- Reattached 101 MB A4 tri-fold: generated and visually inspected `Newly Updated / Family Home` and `24 Woodview Avenue / Lisarow` in the live-preview PDF. Compact auction output `Auction: 10th Sep at 12:00 pm` visually matched in TypeScript preview and two-page Python output.
- Auction text retains its source anchor, uses abbreviated months, and scales to its available width with a 55% lower bound rather than reverting a valid fitting edit. Unreadably small areas still require layout adjustment.
- Regression checks: a spaced three-number PDF run becomes three independent fields; all three values changed to 1 without moving their x anchors; adjacent address/suburb remain a separate group. Duplicate contact text painted within half a font size shares one editable field with all original operators retained for removal.
- Mailcard and three-photo signboard source PDFs were unavailable in this restored workspace; their screenshot-specific fixes are not yet visually verified. Re-import those sources to regenerate grouping and duplicate-operator mappings.
- Supervised browser infrastructure remains unavailable (`sites-previewd` mailbox missing); these are renderer and grouping tests, not an end-to-end hosted browser test.

## 17 September: eight-file regression batch

Re-imported all eight newly supplied PDFs (14 pages) and exercised selected edits through the TypeScript renderer and native Python renderer. All 14 pages generated successfully; unchanged pages were also rendered. This is not a guarantee that every possible edit or arbitrary PDF is supported.

| Source | Pages | Checks |
|---|---:|---|
| 6x4 Photo Signboard | 1 | Two agent names/numbers, 1/1/1 counts at original anchors, compact auction, website and QR |
| 8 x 4 | 1 | Agent names/numbers and website |
| A4 double-sided | 2 | Auction/QR and agent names/numbers |
| A4 tri-fold | 2 unfolded sheets | Changed heading, auction, photo order, agents, website and QR |
| A5 booklet | 4 | Auction in narrow area, both agents, website/QR and photo-only pages |
| Just Listed DL | 2 | JUST SOLD, agent name/number, website without duplicate source text, circular headshot preserved and QR |
| Three-photo signboard | 1 | Exactly three photo slots, photo order, separate address and counts, 1/1/1 at original anchors, agents, auction and QR |
| Just Listed/Sold letter | 1 | Just Sold, agent name/number, two body paragraphs and six local contact groups |

Shared fixes extend contact and sale frames into available horizontal space while keeping source anchors and checking adjacent text/media. Auction text scales within its bounded area. Contact grouping stops at a large vertical gap instead of absorbing nearby paragraphs; a half-point tolerance preserves intended three-line-height gaps. Combined viewing labels/values are split at their source character positions.

All six regenerated QR codes decoded to https://www.beleef.com.au/. Native output trim dimensions were checked at 25% for all 14 pages. Preview/Python raster comparisons differed by at most 0.153 on a 0–255 average channel scale, concentrated in QR rendering. Selected heading, auction, contact and media outputs were visually inspected. Full-document preview recovery accepted the exact tri-fold heading `Newly Updated / Family Residence` and auction edit without reverting either.

Remaining limits: browser click-through testing is still unavailable because the supervised preview service is unavailable. Some supplied sources retain colour-profile/pattern warnings, low-resolution images, missing bleed, or small QR modules. These outputs remain proofs until those issues are resolved. Flattened image effects cannot be guaranteed to transfer to arbitrary replacement photographs. Raster/outlined content is not automatically reconstructed as editable text. Test dimensions preserve source proportions and explicitly confirm the detected size; production users must confirm any source/filename size conflict.

Reproduction from repository: bundle `scripts/check-upload-batch.mts` with esbuild (`--bundle --packages=external --platform=node --format=esm`), run it with the fixture directory as its argument, then run `scripts/check-batch-python.py` with `PYTHONPATH=python`. The Python visual comparison additionally requires PyMuPDF and NumPy; application dependencies are in `python/requirements.txt`. Fixtures are user-supplied and are not committed. Existing saved templates retain their definitions; re-import to apply new grouping.

## Rich text and inline address

Verified continuous paragraph reflow, separate address token replacement, bold/italic/normal ranges, clearing positional styling after whole-paragraph replacement, and contact formatting. Native Python and hosted renderers use matching layout rules. Browser selection interaction could not be exercised because the managed preview service was unavailable.

## Sprint export rules (18 September 2026)
Verified against Sprint Solutions Sign & Print Specs 2026, pages 1 and 4: 6x4 Edgewrap face 458 x 305 mm, sheet 490.5 x 337.5 mm; 8x4 sheet 642.5 x 337.5 mm; Bannerwrap 6x4 sheet 516 x 363 mm. Brochure A4 sheet 214 x 301 mm, DL sheet 214 x 103 mm, letter 210 x 297 mm. Both renderers passed physical dimension checks. Signboard-only preparation uses explicit trim geometry, preserves red marks, removes small white registration paths and exterior trim strokes, and crops excess outer slug without rasterising. Ambiguous/flattened marks and missing trim geometry are deliberately not erased. Filename/detected-size conflict offers either size; changing proportions uses centred crop and must be visually reviewed. Synthetic tests cover excess slug, 8x6 versus 6x4 mismatch, 6x4 crop, and non-signboard preservation. Live browser flow is not verified in this session.

## Basic design builder

The home screen offers PDF import and Create your own. The builder supports text boxes, installed font styles, colour, alignment, line spacing, rectangles/ellipses/lines, opacity, multiple image uploads, rectangular/square/circular/oval/rounded image masks, crop/zoom/fit, quarter-turn rotations, flip, QR links, page colour, multiple pages, duplicate/reorder/hide/lock, undo/redo and numeric/drag positioning. Design JSON can be downloaded/reopened. Original authored scene is embedded in the source PDF and can be reopened from saved authored templates; this reopens the original layout, not subsequent job-value overrides.

New authored text boxes map directly to content groups. Editable media goes through the shared template pipeline; final print scaling follows category. The page background extends through bleed. Very low-resolution inputs remain subject to the existing resolution checks.

`node --import tsx scripts/check-design-builder.mts` passed scene metadata roundtrip, document size/category, one group per authored text box, QR recognition, compilation, changed text output, and full-size brochure dimensions. Poppler rendered the final PDF without font errors after embedding real font subsets. Typecheck passed. Managed browser preview infrastructure was unavailable; full pointer and image-upload UI interaction QA remains unverified.

## Image-to-draft integration (connection pending)

The builder includes Start from an image: JPG/PNG/WebP upload, bounded analysis preview, category/physical size selection, editable scene conversion, reference comparison and uncertainty notes. The optional `/api/design-draft` endpoint uses Responses image input with a strict layout schema, server-only OPENAI_API_KEY, authenticated owner requests and no external image URLs. Native Python includes the same optional service and contract. Cropped photo regions retain baked-in text and must be replaced with originals; there is no claimed image inpainting or font identification guarantee.

No API key was configured during this release. The UI explicitly reports the unavailable service and disables generation. Real model recognition quality and live end-to-end generation are NOT verified. Mock contract checks passed for bounds, font mapping, aspect-ratio fit, schema rejection and incomplete/refusal handling. Browser interaction QA remains unavailable in this environment.
