"""Convert a JPEG/PNG to an uploadable CMYK PDF: python prepare_image.py input.jpg output.pdf.
Requires Pillow: pip install Pillow==11.3.0
"""
import io,sys
from pathlib import Path
from PIL import Image,ImageOps,ImageCms
from pypdf import PdfWriter
from pypdf.generic import NameObject,NumberObject,DictionaryObject
from signboard_studio.engine import stream

def prepare(source):
    with Image.open(source) as image:
        if image.width*image.height>24000000: raise ValueError('Image exceeds 24 megapixels.')
        image=ImageOps.exif_transpose(image); rgba=image.convert('RGBA'); alpha=rgba.getchannel('A')
        embedded=image.info.get('icc_profile')
        profile=ImageCms.ImageCmsProfile(io.BytesIO(embedded)) if embedded else ImageCms.createProfile('sRGB')
        rgb=image.convert('RGB')
        if embedded and image.mode=='CMYK': rgb=ImageCms.profileToProfile(image,profile,ImageCms.createProfile('sRGB'),outputMode='RGB'); profile=ImageCms.createProfile('sRGB')
        target=ImageCms.getOpenProfile(str(Path(__file__).parent/'web/template/colour/CGATS001Compat-v2-micro.icc'))
        cmyk=ImageCms.profileToProfile(rgb,profile,target,outputMode='CMYK')
        w,h=cmyk.size; writer=PdfWriter(); page=writer.add_blank_page(w,h)
        im=stream(cmyk.tobytes(),Type=NameObject('/XObject'),Subtype=NameObject('/Image'),Width=NumberObject(w),Height=NumberObject(h),ColorSpace=NameObject('/DeviceCMYK'),BitsPerComponent=NumberObject(8)).flate_encode()
        if alpha.getextrema()!=(255,255): im[NameObject('/SMask')]=writer._add_object(stream(alpha.tobytes(),Type=NameObject('/XObject'),Subtype=NameObject('/Image'),Width=NumberObject(w),Height=NumberObject(h),ColorSpace=NameObject('/DeviceGray'),BitsPerComponent=NumberObject(8)).flate_encode())
        page[NameObject('/Resources')]=DictionaryObject({NameObject('/XObject'):DictionaryObject({NameObject('/Image'):writer._add_object(im)})})
        page[NameObject('/Contents')]=writer._add_object(stream(f'q {w} 0 0 {h} 0 0 cm /Image Do Q'))
        writer._root_object[NameObject('/SignboardImageAsset')]=NumberObject(1); output=io.BytesIO(); writer.write(output); return output.getvalue()
if __name__=='__main__': Path(sys.argv[2]).write_bytes(prepare(sys.argv[1]))
