"""Google Fonts adapter used by the native Python editor; no API key required."""
import base64,re,time,threading
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode,urlsplit
_CACHE={}
_LOCK=threading.Lock()
def fetch_fonts(family,weight=400,italic=False):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 -]{0,99}',family) or weight not in range(100,1000,100): raise ValueError('Invalid font request')
    key=(family,weight,italic)
    with _LOCK:
        hit=_CACHE.get(key)
        if hit and hit[0]>time.time(): return hit[1]
    def read(url,host,limit):
        with urlopen(Request(url,headers={'User-Agent':'SignboardStudio/1.0'}),timeout=15) as response:
            if urlsplit(response.url).hostname!=host: raise ValueError('Unexpected font provider redirect')
            data=response.read(limit+1)
            if len(data)>limit: raise ValueError('Font response too large')
            return data
    try:
        css=read('https://fonts.googleapis.com/css?'+urlencode({'family':f'{family}:{weight}'+('italic' if italic else '')}),'fonts.googleapis.com',100000).decode()
    except HTTPError as e:
        if e.code in (400,404): return None
        raise
    urls=list(dict.fromkeys(re.findall(r'url\((https://fonts\.gstatic\.com/[^)\s]+)\)',css)))
    if not urls or len(urls)>16:return None
    files=[];total=0
    for url in urls:
        if urlsplit(url).hostname!='fonts.gstatic.com':raise ValueError('Invalid font source')
        data=read(url,'fonts.gstatic.com',8<<20);total+=len(data)
        if total>16<<20:raise ValueError('Font family too large')
        files.append(base64.b64encode(data).decode())
    result={'provider':'Google Fonts','files':files}
    with _LOCK:
        if len(_CACHE)>=8:_CACHE.pop(next(iter(_CACHE)))
        if sum(len(f) for f in files)<2*1024*1024:_CACHE[key]=(time.time()+86400,result)
    return result
