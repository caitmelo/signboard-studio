"""Optional reference-image analysis; API key is server-only."""
import json, os, re, urllib.request, urllib.error
from pathlib import Path

def available():
    return bool(os.environ.get('OPENAI_API_KEY'))

def analyse(data):
    key=os.environ.get('OPENAI_API_KEY')
    if not key: raise ValueError('Image analysis is not connected yet. The Studio owner needs to enable it.')
    image=data.get('image','')
    if not isinstance(image,str) or len(image)>6000000 or not re.fullmatch(r'data:image/(jpeg|png);base64,[A-Za-z0-9+/]+={0,2}',image): raise ValueError('Choose a JPG or PNG image.')
    config=json.loads(Path(__file__).with_name('image_draft_config.json').read_text())
    payload={'model':os.environ.get('OPENAI_VISION_MODEL','gpt-4.1'),'store':False,'max_output_tokens':10000,'input':[{'role':'system','content':config['prompt']},{'role':'user','content':[{'type':'input_image','image_url':image,'detail':'high'}]}],'text':{'format':{'type':'json_schema','name':'image_template_draft','strict':True,'schema':config['schema']}}}
    request=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(payload).encode(),headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=90) as response: result=json.loads(response.read(2000000))
    except (urllib.error.URLError,TimeoutError): raise ValueError('Image analysis could not finish. Try again or contact the Studio owner.') from None
    if result.get('status')=='incomplete': raise ValueError('The image contains too much detail. Crop to one design and retry.')
    text=''.join(c.get('text','') for o in result.get('output',[]) for c in o.get('content',[]) if c.get('type')=='output_text')
    try:
        draft=json.loads(text)
        if not isinstance(draft,dict) or not isinstance(draft.get('elements'),list) or not 1<=len(draft['elements'])<=60: raise ValueError()
        for e in draft['elements']:
            if e.get('kind') not in ('text','image','rectangle','ellipse','line') or any(not isinstance(e.get(k),(int,float)) or not 0<=e[k]<=1 for k in ('x','y','w','h')): raise ValueError()
        return draft
    except (ValueError,TypeError,KeyError): raise ValueError('No usable layout was returned. Try a clearer image.') from None
