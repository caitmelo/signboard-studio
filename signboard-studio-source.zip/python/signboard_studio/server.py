"""Local test server and reference HTTP API. Bind behind your app's auth for deployment."""
import re, shutil, argparse, base64, io, json, mimetypes, os, secrets, sqlite3, threading, uuid, zipfile
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, unquote, parse_qs
from .font_service import fetch_fonts
from .image_draft import available as draft_available, analyse as analyse_image_draft
from .engine import render, evaluate, JobError, PdfReader, render_edgewrap_json, edgewrap_job

ROOT=Path(__file__).resolve().parents[1]
DATA=Path(os.environ.get('SIGNBOARD_DATA',ROOT/'data')).resolve()
WEB=Path(os.environ.get('SIGNBOARD_WEB',ROOT/'web')).resolve()
TOKEN=os.environ.get('SIGNBOARD_API_TOKEN','')
LOCK=threading.BoundedSemaphore(2)
TYPES={'source':'application/pdf','base':'application/pdf','manifest':'application/json','thumbnail':'image/png'}
LIMITS={'source':None,'base':None,'manifest':None,'thumbnail':3<<20}

def db():
    c=sqlite3.connect(DATA/'templates.sqlite3',timeout=30); c.row_factory=sqlite3.Row; return c

def setup():
    DATA.mkdir(parents=True,exist_ok=True)
    with db() as c: c.execute('CREATE TABLE IF NOT EXISTS templates (id TEXT PRIMARY KEY,name TEXT,source_name TEXT,status TEXT,created_at TEXT,field_count INTEGER DEFAULT 0,face_width_mm REAL DEFAULT 0,face_height_mm REAL DEFAULT 0)')

def template_path(id):
    if str(uuid.UUID(id))!=id: raise ValueError('Invalid template ID')
    path=DATA/id
    with db() as c:
        if not c.execute('SELECT id FROM templates WHERE id=?',(id,)).fetchone(): raise FileNotFoundError('Template not found')
    return path

def create(name,source_name):
    if not isinstance(name,str) or not name.strip() or len(name)>160 or not isinstance(source_name,str) or len(source_name)>240: raise ValueError('Enter a valid template name.')
    id=str(uuid.uuid4()); (DATA/id).mkdir()
    with db() as c: c.execute('INSERT INTO templates(id,name,source_name,status,created_at) VALUES (?,?,?,?,?)',(id,name.strip(),source_name,'draft',datetime.now(timezone.utc).isoformat()))
    return id

def complete(id):
    path=template_path(id)
    if any(not (path/k).exists() for k in TYPES): raise ValueError('Template upload is incomplete.')
    t=json.loads((path/'manifest').read_text())
    if t.get('schemaVersion')!=1 or not isinstance(t.get('fields'),list) or len(t['fields'])>600: raise ValueError('Invalid template schema.')
    if not t['fields'] and not any(s['role']!='fixed' for s in t.get('media',[])): raise ValueError('Template needs editable fields.')
    # Do not let callers promote a proof by omitting the review status.
    if t.get('review',{}).get('status') not in ('approved','proof'): raise ValueError('Save a reviewed template first.')
    _,_,_,issues=evaluate(t,{'mode':'proof'})
    if t['review']['status']=='approved' and issues: raise JobError(issues,'proof_only')
    with db() as c: c.execute("UPDATE templates SET status='ready',field_count=?,face_width_mm=?,face_height_mm=? WHERE id=?",(len(t['fields'])+sum(s['role']!='fixed' for s in t.get('media',[])),t['spec']['faceWidth'],t['spec']['faceHeight'],id))
    return {'id':id,'saved':True}

def image_info(raw):
    reader=PdfReader(io.BytesIO(raw)); p=reader.pages[0]
    if len(reader.pages)!=1 or reader.trailer['/Root'].get('/SignboardImageAsset')!=1: raise ValueError('Upload a CMYK image prepared by the editor.')
    im=p['/Resources']['/XObject']['/Image']
    if im.get('/ColorSpace')!='/DeviceCMYK' or im.get('/BitsPerComponent')!=8 or '/Annots' in p: raise ValueError('Invalid CMYK image asset.')
    for args,op in p.get_contents().operations:
        if op not in (b'q',b'Q',b'cm',b'Do') or (op==b'Do' and args[0]!='/Image'): raise ValueError('Image asset contains unsupported artwork.')
    w=int(im['/Width']); h=int(im['/Height'])
    if w<1 or h<1 or w*h>24000000 or w!=p.mediabox.width or h!=p.mediabox.height: raise ValueError('Invalid image dimensions.')
    return {'width':w,'height':h}

class Handler(BaseHTTPRequestHandler):
    server_version='SignboardPython/1.0'
    def log_message(self,*args): pass  # Avoid storing names, URLs or personal details.
    def send(self,data,status=200,kind='application/json',headers=None):
        if isinstance(data,(dict,list)): data=json.dumps(data).encode()
        if isinstance(data,str): data=data.encode()
        self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff')
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(data)
    def body(self,limit=64<<20):
        size=int(self.headers.get('Content-Length','0'))
        if size<0 or (limit is not None and size>limit): raise ValueError('Request is too large.')
        return self.rfile.read(size)
    def json(self,limit=32768): return json.loads(self.body(limit) or b'{}')
    def auth(self):
        if TOKEN:
            token=self.headers.get('Authorization','').removeprefix('Bearer ')
            if not token: token=next((part.strip()[16:] for part in self.headers.get('Cookie','').split(';') if part.strip().startswith('signboard_token=')),'')
            if not secrets.compare_digest(token,TOKEN): self.send({'error':'Sign in with the API token.'},401); return False
        origin=self.headers.get('Origin')
        if origin and urlsplit(origin).netloc!=self.headers.get('Host'): self.send({'error':'Cross-origin requests are not allowed.'},403); return False
        return True
    def handle_request(self):
        path=urlsplit(self.path).path; parts=path.strip('/').split('/')
        if path=='/health': return self.send({'status':'ok','engine':'python','version':'1.0.0'})
        if path=='/runtime.json': return self.send({'engine':'server-python'})
        if path=='/api/login' and self.command=='POST':
            token=self.json().get('token','')
            if not TOKEN or not secrets.compare_digest(str(token),TOKEN): return self.send({'error':'Invalid token'},401)
            return self.send({'ok':True},headers={'Set-Cookie':f'signboard_token={TOKEN}; HttpOnly; SameSite=Strict; Path=/'})
        if path.startswith('/api/') and not self.auth(): return
        if path=='/api/design-draft':
            if self.command=='GET': return self.send({'available':draft_available()})
            if self.command=='POST':
                if not draft_available(): return self.send({'error':'Image analysis is not connected yet. The Studio owner needs to enable it.'},503)
                if not LOCK.acquire(blocking=False): return self.send({'error':'Image analysis is busy. Retry shortly.'},429)
                try: return self.send(analyse_image_draft(self.json(6100000)))
                finally: LOCK.release()
        if path=='/api/fonts' and self.command=='GET':
            q=parse_qs(urlsplit(self.path).query);result=fetch_fonts(q.get('family',[''])[0],int(q.get('weight',['400'])[0]),q.get('italic',['0'])[0]=='1');return self.send(result or {'files':[]},200 if result else 404)
        if path=='/api/render' and self.command=='POST':
            p=self.json(); template=json.loads((WEB/'template/edgewrap.json').read_text()); job=edgewrap_job(template,p.get('agents'))
            result=json.loads(render_edgewrap_json(json.dumps({'template':template,'job':job})))
            return self.send(base64.b64decode(result['pdf']),kind='application/pdf',headers={'X-Render-Engine':'python','X-Print-Scale':f"{result.get('scale',.25)*100:g}%",'X-Print-Status':'ready'})
        if path=='/api/python/edgewrap' and self.command=='POST':
            result=json.loads(render_edgewrap_json(json.dumps(self.json(8<<20))))
            return self.send(base64.b64decode(result['pdf']),kind='application/pdf',headers={'X-Render-Engine':'python','X-Print-Scale':f"{result.get('scale',.25)*100:g}%"})
        if path=='/api/python/render' and self.command=='POST':
            p=self.json(450<<20)
            if not LOCK.acquire(blocking=False): return self.send({'error':'Renderer busy. Retry shortly.'},429)
            try: raw,issues=render(base64.b64decode(p['base']),p['template'],p['job'],(WEB/'template/colour/CGATS001Compat-v2-micro.icc').read_bytes(),p.get('assets',{}))
            finally: LOCK.release()
            return self.send(raw,kind='application/pdf',headers={'X-Print-Scale':('25%' if p['template']['spec'].get('product','edgewrap') in ('edgewrap','linea','bannerwrap','pointer','other_signboard') else '100%'),'X-Render-Engine':'python','X-Print-Status':'proof' if p['job'].get('mode')=='proof' else 'ready'})
        if path=='/api/templates':
            if self.command=='GET':
                with db() as c: rows=[dict(r) for r in c.execute("SELECT id,name,source_name,field_count,face_width_mm,face_height_mm,created_at FROM templates WHERE status='ready' ORDER BY created_at DESC LIMIT 200")]
                return self.send({'templates':rows})
            if self.command=='POST':
                p=self.json(); return self.send({'id':create(p.get('name'),p.get('sourceName'))},201)
            if self.command=='DELETE':
                p=self.json(16000); mode=p.get('confirm'); ids=p.get('ids')
                if mode not in ('delete-all-my-templates','delete-selected-templates'): return self.send({'error':'Confirm which templates to delete.'},400)
                if mode=='delete-selected-templates' and (not isinstance(ids,list) or not ids or len(ids)>200 or any(not isinstance(i,str) or not re.fullmatch(r'[a-zA-Z0-9-]{1,80}',i) for i in ids)): return self.send({'error':'Choose valid templates to delete.'},400)
                with db() as c:
                    rows=c.execute('SELECT id FROM templates'+(' WHERE id IN ('+','.join('?' for _ in ids)+')' if mode=='delete-selected-templates' else ''),ids if mode=='delete-selected-templates' else []).fetchall()
                    for row in rows:
                        path=template_path(row['id'])
                        if path.exists(): shutil.rmtree(path)
                        c.execute('DELETE FROM templates WHERE id=?',(row['id'],))
                return self.send({'deleted':len(rows)})

        if path=='/api/templates/import' and self.command=='POST':
            with zipfile.ZipFile(io.BytesIO(self.body(450<<20))) as z:
                if any(k not in z.namelist() for k in TYPES): raise ValueError('Bundle needs source, base, manifest and thumbnail.')
                if any(LIMITS[k] is not None and z.getinfo(k).file_size>LIMITS[k] for k in TYPES): raise ValueError('Template bundle is too large.')
                files={k:z.read(k) for k in TYPES}; t=json.loads(files['manifest']); id=create(t['name'],t['sourceName'])
                try:
                    for k,v in files.items(): (DATA/id/k).write_bytes(v)
                    return self.send(complete(id),201)
                except Exception:
                    # Failed import remains an invisible draft for diagnosis.
                    raise
        if len(parts)>=3 and parts[:2]==['api','templates']:
            id=parts[2]; folder=template_path(id)
            if len(parts)==5 and parts[3]=='assets' and parts[4] in TYPES:
                asset=parts[4]; file=folder/asset
                if self.command=='GET': return self.send(file.read_bytes(),kind=TYPES[asset])
                if self.command=='PUT':
                    with db() as c:
                        if c.execute('SELECT status FROM templates WHERE id=?',(id,)).fetchone()['status']!='draft': return self.send({'error':'Template is locked. Save a new version.'},409)
                    raw=self.body(LIMITS[asset]); temp=folder/(asset+'.tmp'); temp.write_bytes(raw); temp.replace(file); return self.send({'saved':True})
            if len(parts)==4 and parts[3]=='complete' and self.command=='POST': return self.send(complete(id))
            if len(parts)==4 and parts[3]=='schema' and self.command=='GET':
                t=json.loads((folder/'manifest').read_text()); return self.send({'id':id,'revision':t.get('review',{}).get('revision',1),'groups':t.get('groups',[]),'text':[{'id':f['id'],'role':f['role'],'label':f['label'],'default':f['text']} for f in t['fields']],'media':[{'key':s['key'],'role':s['role'],'label':s['label']} for s in t.get('media',[]) if s['role']!='fixed']})
            if len(parts)==4 and parts[3]=='media' and self.command=='POST':
                raw=self.body(25<<20); info=image_info(raw); asset=str(uuid.uuid4()); (folder/'media').mkdir(exist_ok=True); (folder/'media'/asset).write_bytes(raw); info['name']=unquote(self.headers.get('X-Image-Name','Image'))[:240]; (folder/'media'/(asset+'.json')).write_text(json.dumps(info)); return self.send(dict(info,assetId=asset),201)
            if len(parts)==5 and parts[3]=='media' and self.command=='GET':
                asset=str(uuid.UUID(parts[4])); return self.send((folder/'media'/asset).read_bytes(),kind='application/pdf')
            if len(parts)==4 and parts[3]=='render' and self.command=='POST':
                job=self.json(); t=json.loads((folder/'manifest').read_text()); assets={}
                for v in job.get('media',{}).values():
                    if 'assetId' in v:
                        asset=str(uuid.UUID(v['assetId'])); info=json.loads((folder/'media'/(asset+'.json')).read_text()); assets[asset]=dict(info,pdfBase64=base64.b64encode((folder/'media'/asset).read_bytes()).decode())
                if not LOCK.acquire(blocking=False): return self.send({'error':'Renderer busy. Retry shortly.'},429)
                try: raw,issues=render((folder/'base').read_bytes(),t,job,(WEB/'template/colour/CGATS001Compat-v2-micro.icc').read_bytes(),assets)
                finally: LOCK.release()
                return self.send(raw,kind='application/pdf',headers={'Content-Disposition':f"attachment; filename=Print_{25 if t['spec'].get('product','edgewrap') in ('edgewrap','linea','bannerwrap','pointer','other_signboard') else 100}pct.pdf",'X-Print-Scale':('25%' if t['spec'].get('product','edgewrap') in ('edgewrap','linea','bannerwrap','pointer','other_signboard') else '100%'),'X-Render-Engine':'python','X-Print-Status':'proof' if job.get('mode')=='proof' else 'ready'})
        if path.startswith('/api/'): return self.send({'error':'Not found'},404)
        if self.command!='GET': return self.send({'error':'Method not allowed'},405)
        file=(WEB/unquote(path.lstrip('/'))).resolve()
        if not file.is_relative_to(WEB): return self.send({'error':'Not found'},404)
        if not file.is_file():
            if '.' in file.name: return self.send({'error':'Not found'},404)
            file=WEB/'index.html'
        return self.send(file.read_bytes(),kind=mimetypes.guess_type(str(file))[0] or 'application/octet-stream')
    def route(self):
        try: self.handle_request()
        except JobError as e: self.send({'status':e.status,'error':str(e),'errors':e.errors},422)
        except FileNotFoundError: self.send({'error':'Not found'},404)
        except (ValueError,KeyError,TypeError,zipfile.BadZipFile) as e: self.send({'error':str(e)},422)
        except Exception: self.send({'error':'The request could not be completed.'},500)
    do_GET=route; do_POST=route; do_PUT=route; do_DELETE=route

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8000); args=parser.parse_args()
    if args.host not in ('127.0.0.1','localhost') and not TOKEN and os.environ.get('SIGNBOARD_LOCAL_TEST')!='1': parser.error('Set SIGNBOARD_API_TOKEN before binding to an external interface.')
    setup(); print(f'Signboard Studio Python: http://{args.host}:{args.port}',flush=True); ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()
if __name__=='__main__': main()
