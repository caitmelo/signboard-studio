import fs from 'node:fs';
import assert from 'node:assert/strict';
import {analyseDesign,compileDesign,evaluateTemplate,loadEngineAssets,renderTemplate} from '../lib/template-engine';
globalThis.fetch=async(input:any)=>{const path='public'+new URL(String(input),'https://example.test').pathname;return fs.existsSync(path)?new Response(fs.readFileSync(path)):new Response('',{status:404});};
const assets=await loadEngineAssets(),source=new Uint8Array(fs.readFileSync('../upload/Double sided DL Mailcard_Just Sold (1) (1).pdf'));
for(const page of [0,1]){
 const a=await analyseDesign(source,'Double sided DL Mailcard_Just Sold (1) (1).pdf',page,assets);
 const built=await compileDesign(source,a,'Mailcard anchors',assets),m=built.manifest;
 const agents=m.fields.filter(f=>f.role.startsWith('agent'));assert.equal(agents.length,2);
 for(const one of [false,true])for(const changed of [false,true]){
  const values=changed?Object.fromEntries(agents.map(f=>[f.id,f.role.endsWith('name')?'Pat Boondok':'0400 123 456'])):{};
  const fit=evaluateTemplate(m,values,one);assert.ok(fit.valid,fit.errors.join('\n'));
  for(const f of fit.fields){const original=m.fields.find(o=>o.id===f.id)!;assert.equal(f.x,original.x);assert.equal(f.y,original.y);assert.equal(f.size,original.size);}
  if(one)fs.writeFileSync(`work/mailcard-fixed-${page}-${changed?'edited':'original'}.pdf`,await renderTemplate(built.base,m,values,one,assets));
 }
 console.log('PASS mailcard page',page+1,agents.map(f=>({text:f.text,x:f.x,y:f.y})));
}
const photo=new Uint8Array(fs.readFileSync('../upload/6x4 Photo Signboard (1).pdf')),a=await analyseDesign(photo,'6x4 Photo Signboard (1).pdf',0,assets),built=await compileDesign(photo,a,'Two agents',assets);
const fit=evaluateTemplate(built.manifest,{},true);assert.ok(fit.valid);assert.ok(!fit.fields.some(f=>f.role.startsWith('agent2_')));for(const f of fit.fields){const original=built.manifest.fields.find(o=>o.id===f.id)!;assert.equal(f.x,original.x);assert.equal(f.y,original.y);}
console.log('PASS two-to-one agent selection only hides Agent 2; all remaining anchors stay unchanged.');
