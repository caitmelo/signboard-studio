import json,pathlib,fitz
from signboard_studio.engine import render,evaluate,export_scale
icc=pathlib.Path('public/template/colour/CGATS001Compat-v2-micro.icc').read_bytes()
results=[]
for row in json.load(open('work/retest/report.json')):
 prefix=row['prefix'];t=json.load(open(prefix+'-manifest.json'));job=json.load(open(prefix+'-job.json'))
 try:
  out,notes=render(pathlib.Path(prefix+'-base.pdf').read_bytes(),t,job,icc)
  pathlib.Path(prefix+'-python.pdf').write_bytes(out)
  d=fitz.open(stream=out,filetype='pdf'); trim=d[0].trimbox
  assert abs(trim.width*25.4/72-t['spec']['faceWidth']*export_scale(t))<.05
  assert abs(trim.height*25.4/72-t['spec']['faceHeight']*export_scale(t))<.05
  # Compare both engines at the same pixel dimensions; differing paths/CMYK
  # conversion can create small antialiasing differences, so retain scores for review.
  js=fitz.open(prefix+'-edited.pdf');p=d[0];q=js[0];scale=900/p.rect.width
  import numpy as np
  a=np.frombuffer(p.get_pixmap(matrix=fitz.Matrix(scale,scale)).samples,dtype=np.uint8)
  b=np.frombuffer(q.get_pixmap(matrix=fitz.Matrix(scale,scale)).samples,dtype=np.uint8)
  delta=float(np.abs(a.astype(float)-b.astype(float)).mean()) if len(a)==len(b) else None
  results.append({'name':row['name'],'page':row['page'],'ok':True,'meanPixelDifference':delta,'notes':notes})
  print(row['name'],row['page'],'PASS',delta,flush=True)
 except Exception as e:
  results.append({'name':row['name'],'page':row['page'],'ok':False,'error':str(e)});print('FAIL',row['name'],row['page'],str(e),flush=True)
 pathlib.Path('work/retest/python-report.json').write_text(json.dumps(results,indent=2))
assert all(r['ok'] for r in results)
