import json,base64,fitz
from pathlib import Path
from signboard_studio.engine import render
m=json.loads(Path('work/batch-6-0-manifest.json').read_text()); d=fitz.open();p=d.new_page(width=200,height=200);p.draw_rect(p.rect,color=(1,0,0),fill=(1,0,0));asset=d.tobytes();Path('work/mask-asset.pdf').write_bytes(asset)
out,_=render(Path('work/batch-6-0-base.pdf').read_bytes(),m,{'mode':'proof','media':{'media_2':{'pdfBase64':base64.b64encode(asset).decode(),'width':200,'height':200}}},Path('public/template/colour/CGATS001Compat-v2-micro.icc').read_bytes())
Path('work/mask-python.pdf').write_bytes(out)
def check(path):
 doc=fitz.open(path);pix=doc[0].get_pixmap(matrix=fitz.Matrix(4,4)); H=m['sourceHeight'];
 for x,y in [(47,82),(193,82),(47,228),(193,228)]:assert min(pix.pixel(round(x),round(H-y)))>240,(x,y,pix.pixel(round(x),round(H-y)))
 assert pix.pixel(120,round(H-155))[0]>180 and pix.pixel(120,round(H-155))[1]<80
 print('PASS circular alpha frame:',path)
check('work/mask-python.pdf')
