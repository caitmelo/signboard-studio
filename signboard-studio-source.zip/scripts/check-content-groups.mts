import fs from 'node:fs';
import assert from 'node:assert/strict';
import {analyseDesign,compileDesign,evaluateTemplate,loadEngineAssets,renderTemplate} from '../lib/template-engine';
import {contentGroups,defaultGroupValue,resolveContent,auctionText,viewingLimit,inferContentGroups} from '../lib/content-groups';
import {defaultMediaValues} from '../lib/template-media';
import type {ContentValues} from '../lib/template-types';
import {POST as create} from '../app/api/templates/route';
import {PUT as put} from '../app/api/templates/[id]/assets/[asset]/route';
import {POST as complete} from '../app/api/templates/[id]/complete/route';
import {POST as render} from '../app/api/templates/[id]/render/route';

globalThis.fetch=async(input:any)=>{const path='public'+new URL(String(input),'https://example.test').pathname;return fs.existsSync(path)?new Response(fs.readFileSync(path)):new Response('',{status:404});};
const assets=await loadEngineAssets(),source=new Uint8Array(fs.readFileSync('../upload/6x4 Photo Signboard (1).pdf'));
const analysis=await analyseDesign(source,'6x4 Photo Signboard (1).pdf',0,assets);
const built=await compileDesign(source,analysis,'Grouped content',assets),m=built.manifest,groups=contentGroups(m);
assert.deepEqual(groups.map(g=>g.kind),['heading','address','details','agents','sale','viewing','features','agency']);
assert.equal(groups.flatMap(g=>g.fieldIds).length,22);assert.equal(new Set(groups.flatMap(g=>g.fieldIds)).size,22);
assert.equal(groups.find(g=>g.kind==='heading')!.fieldIds.length,2);assert.equal(groups.find(g=>g.kind==='details')!.fieldIds.length,3);assert.equal(groups.find(g=>g.kind==='features')!.fieldIds.length,6);
const defaults=Object.fromEntries(groups.filter(g=>g.kind!=='agents').map(g=>[g.key,defaultGroupValue(g,m.fields)]));
const old=evaluateTemplate(m,{},false),same=evaluateTemplate(m,{},false,defaults);
assert.deepEqual(same.errors,[]);for(const field of old.fields){const current=same.fields.find(f=>f.id===field.id)!;for(const key of ['x','y','size','fontName','value','color','offsets'])assert.deepEqual(current[key],field[key],`${field.text}: ${key} must remain identical`);}
fs.writeFileSync('work/grouped-unchanged.pdf',await renderTemplate(built.base,m,{},false,assets,{},defaults));
const content:ContentValues={heading:'Elegance\nEuropean',address:'4/48-50 Gladstone Street\nNorth Sydney',details:'Modern townhouse with a designer kitchen, open living and a private garden. A comfortable home close to local shops.',sale:{type:'auction',date:'2026-09-14',time:'12:00'},viewing:{mode:'custom',text:'Saturday 12–12:30 pm'},features:{beds:'5',baths:'3',cars:'2'},agency:{visible:false}};
const fit=evaluateTemplate(m,{},false,content);console.log('Grouped fit:',fit.errors);assert.equal(fit.valid,true,fit.errors.join('\n'));
assert.equal(fit.fields.find(f=>f.text==='For Sale:')!.value,'Auction: Onsite 14th September at 12:00 pm');assert.ok(!fit.fields.some(f=>f.text==='9630 8899'||f.text==='stonerealestate.com.au'));
assert.equal(fit.fields.filter(f=>f.fontName==='StoneREIcons').length,3);
for(const f of fit.fields){const before=m.fields.find(r=>r.id===f.id)!;assert.equal(f.size,before.size);assert.equal(f.fontName,before.fontName);assert.deepEqual(f.color,before.color);}
fs.writeFileSync('work/grouped-auction.pdf',await renderTemplate(built.base,m,{},false,assets,defaultMediaValues(m),content));
const single=evaluateTemplate(m,{},true,content);assert.equal(single.valid,true,single.errors.join('\n'));assert.ok(!single.fields.some(f=>f.role.startsWith('agent2_')));
fs.writeFileSync('work/grouped-single.pdf',await renderTemplate(built.base,m,{},true,assets,defaultMediaValues(m),content));
assert.equal(evaluateTemplate(m,{},false,{details:'Long description '.repeat(60)}).valid,false);
assert.equal(evaluateTemplate(m,{},false,{heading:'New headline'}).valid,false,'Never substitute a missing matching font');
assert.equal(evaluateTemplate(m,{},false,{viewing:{mode:'custom',text:'W'.repeat(200)}}).valid,false);
assert.equal(evaluateTemplate(m,{},false,{sale:{type:'auction',date:'2026-02-31',time:'12:00'}}).valid,false);
assert.equal(evaluateTemplate(m,{},false,{features:{beds:'-1',baths:'2',cars:'2'}}).valid,false);
assert.equal(evaluateTemplate(m,{},false,{unknown:'Unknown'}).valid,false);
assert.equal(auctionText('2026-09-11','00:05'),'Auction: Onsite 11th September at 12:05 am');
const short=evaluateTemplate(m,{},false,{details:'A comfortable home.'});assert.ok(short.fields.length<m.fields.length);assert.ok(short.valid);
const phoneOnly=evaluateTemplate(m,{},false,{agency:{visible:true,phone:'9630 8899',contact:''}});assert.ok(phoneOnly.valid);assert.ok(!phoneOnly.fields.some(f=>f.text==='stonerealestate.com.au'));
const legacy={...m,groups:undefined};assert.deepEqual(contentGroups(legacy),groups,'Saved older templates gain groups without a re-upload');
// Other layouts get paragraph blocks without borrowing this source's coordinates.
const paragraph=m.fields.filter(f=>f.fontName==='Poppins-Regular'&&f.x<200).map(f=>({...f,id:'other-'+f.id,x:f.x+100,y:f.y+300}));const generic=inferContentGroups(paragraph);assert.equal(generic.length,1);assert.equal(generic[0].kind,'details');
function request(method:string,body?:BodyInit){return new Request('https://example.test/api/templates',{method,body,headers:{'oai-authenticated-user-id':'owner','content-type':'application/json'}});}
const created=await create(request('POST',JSON.stringify({name:'Grouped API',sourceName:'6x4 Photo Signboard (1).pdf'})));assert.equal(created.status,201);const{id}=await created.json()as{id:string},context={params:Promise.resolve({id})};
for(const[asset,data]of [['source',source],['base',built.base],['manifest',Buffer.from(JSON.stringify(m))],['thumbnail',fs.readFileSync('work/storage-thumbnail.png')]]as[string,Uint8Array][]){assert.equal((await put(request('PUT',new Uint8Array(data).buffer),{params:Promise.resolve({id,asset})})).status,200);}
assert.equal((await complete(request('POST'),context)).status,200);
const result=await render(request('POST',JSON.stringify({mode:'proof',content,agents:[{name:'Ashton Beukers',phone:'0410 591 789'}]})),context);assert.equal(result.status,200,result.status===200?'':await result.text());fs.writeFileSync('work/grouped-api.pdf',new Uint8Array(await result.arrayBuffer()));
assert.equal((await render(request('POST',JSON.stringify({mode:'proof',content:{viewing:{mode:'custom',text:'W'.repeat(200)}}})),context)).status,422);
assert.equal((await render(request('POST',JSON.stringify({mode:'print',content})),context)).status,422,'Grouping cannot bypass print preflight');
fs.writeFileSync('work/grouped-manifest.json',JSON.stringify(m));
console.log('PASS: eight semantic groups, unchanged glyph geometry/styles, multiline wrapping, Auction date/time, viewing cap, icon preservation, agency hiding, single agent, legacy inference and actual structured job API.');
