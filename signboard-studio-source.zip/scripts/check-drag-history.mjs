import fs from 'node:fs';
import assert from 'node:assert/strict';

// Replay React's deferred updater after the pointer handler has returned.
const source = fs.readFileSync(new URL('../components/design-builder.tsx', import.meta.url), 'utf8');
const handler = source.match(/function end\(\)\{(.*?)\}\n function size/s)[1];
const before = {pages: [{elements: [{x: 5, y: 10}]}]};
const drag = {current: {scene: before}};
const queued = [];
const end = new Function('drag', 'setPast', 'setFuture', handler)
  .bind(null, drag, update => queued.push(update), () => {});
end();
assert.equal(drag.current, null);
assert.deepEqual(queued[0]([]), [before]);
end(); // pointerup may be followed by lostpointercapture
assert.equal(queued.length, 1);
assert.deepEqual(queued[0]([]), [before]); // Strict Mode updater replay
console.log('PASS deferred drag completion, duplicate completion and updater replay');
