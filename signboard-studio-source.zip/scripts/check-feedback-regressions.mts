import fs from 'node:fs';import assert from 'node:assert/strict';import {PDFDocument} from 'pdf-lib';
import {analyseDesign,compileDesign,evaluateTemplate,renderTemplate,loadEngineAssets} from '../lib/template-engine';import {prepareSignboard} from '../lib/signboard-preparation';import {detectDocument} from '../lib/document-setup';import {optimisePdf} from '../lib/pdf-upload';import {inferTextAlignment} from '../lib/text-alignment';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets();fs.mkdirSync('work/feedback',{recursive:true});
for(const [name,index,key] of [['8 x 4(3).pdf',0,'8x4'],['6x4 Photo Signboard (1)(4).pdf',0,'photo'],['A4 Booklet 6 page Tri-Fold - Booklet     Celloglaze -(6).pdf',1,'tri']] as const){
 let source=await optimisePdf(fs.readFileSync('../upload/'+name),name);const setup=await detectDocument(source,name,index);source=await prepareSignboard(source,index,setup.spec);const a=await analyseDesign(source,name,index,assets);a.spec={...setup.spec,sizeConfirmed:true,sizeWarning:undefined};
 if(key==='8x4'){assert.equal(setup.spec.sizeName,'8x4');assert.equal(setup.spec.faceWidth,1220);assert(a.runs.some(r=>r.text==='For'));assert(a.runs.some(r=>r.text==='Sale'));assert(a.runs.filter(r=>r.role.startsWith('agent')).every(r=>r.align==='center'));}
 if(key==='tri')assert.deepEqual(a.groups?.filter(g=>g.kind==='details').map(g=>g.fieldIds.length),[14,14]);
 const built=await compileDesign(source,a,name,assets),t=built.manifest;const values:Record<string,string>={},content:any={};
 for(const f of t.fields){if(f.role.endsWith('_name'))values[f.id]=f.role.startsWith('agent1')?'Amy Park':'John Lee';if(f.role.endsWith('_phone'))values[f.id]='0400 123 456';}
 for(const g of t.groups??[]){if(g.kind==='agency')content[g.key]={visible:true,phone:'1300 123 456',contact:'qa@example.com'};if(g.kind==='heading'&&key==='8x4')content[g.key]='To\nLet';if(g.kind==='details'&&key==='tri')content[g.key]='- Bright living spaces\n- Updated kitchen\n- Convenient location';}
 const check=evaluateTemplate(t,values,false,content);console.log(key,'errors',check.errors,'issues',check.printIssues);assert.equal(check.valid,true);
 for(const f of check.fields.filter(f=>f.align==='center')){const original=t.fields.find(r=>r.id===f.id)!;assert(Math.abs(f.x+f.width/2-original.x-original.width/2)<.01);}
 for(const [suffix,v,c] of [['original',{},{}],['edited',values,content]]as const){fs.writeFileSync(`work/feedback/${key}-${suffix}.pdf`,await renderTemplate(built.base,t,v,false,assets,{},c));}
 fs.writeFileSync(`work/feedback/${key}-base.pdf`,built.base);fs.writeFileSync(`work/feedback/${key}-manifest.json`,JSON.stringify(t));fs.writeFileSync(`work/feedback/${key}-job.json`,JSON.stringify({mode:'proof',text:values,content}));
 const out=(await PDFDocument.load(fs.readFileSync(`work/feedback/${key}-edited.pdf`))).getPage(0);const scale=key==='tri'?1:.25;assert(Math.abs(out.getTrimBox().width*25.4/72-t.spec.faceWidth*scale)<.01);
}
console.log('Feedback regression checks passed');
