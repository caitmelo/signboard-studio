import fs from 'node:fs';import assert from 'node:assert/strict';
import {PDFDocument,PDFName} from 'pdf-lib';
import {analyseDesign,compileDesign,renderTemplate,evaluateTemplate,loadEngineAssets} from '../lib/template-engine';
import {fontFromType3} from '../lib/type3-font';
import {matchEmbeddedFont} from '../lib/match-embedded-font';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets(),font=(await assets.loadFont!('NimbusRomNo9L-Med'))!;
const doc=await PDFDocument.create(),page=doc.addPage([600,400]),context=doc.context;
const text='Spacious Family Retreat',chars=[...new Set(text)],programs:any={},widths=Array.from({length:95},()=>500),diff:any[]=[];
for(const c of chars){const cp=c.charCodeAt(0),g=font.glyphs[String(cp)],name=c===' '?'space':c;assert.ok(g);widths[cp-32]=g.advance/font.unitsPerEm*1000;diff.push(cp,PDFName.of(name));programs[name]=context.register(context.flateStream(`${widths[cp-32]} 0 0 -250 1100 1100 d1\n${g.path}\nf`));}
const type3=context.obj({Type:'Font',Subtype:'Type3',FontBBox:[0,-250,1100,1100],FontMatrix:[1/font.unitsPerEm,0,0,1/font.unitsPerEm,0,0],FirstChar:32,LastChar:126,Widths:widths,Encoding:{Type:'Encoding',BaseEncoding:'WinAnsiEncoding',Differences:diff},CharProcs:programs,Resources:{}});
page.node.set(PDFName.of('Resources'),context.obj({Font:{R39:context.register(type3)}}));page.node.addContentStream(context.register(context.flateStream('BT /R39 26 Tf 40 300 Td (Spacious Family) Tj 0 -35 Td (Retreat) Tj ET')));
const source=await doc.save();fs.writeFileSync('work/r39-font-fixture.pdf',source);
const a=await analyseDesign(source,'A4 letter.pdf',0,assets);assert.deepEqual(a.errors,[]);assert.ok(a.runs.every(r=>!!a.fonts[r.fontName]));assert.ok(a.runs.every(r=>r.fontName==='NimbusRomNo9L-Med'),'Anon Type3 outline resolves to the full supplied font');
a.spec={...a.spec,product:'letter',bleed:0,faceWidth:600*25.4/72,faceHeight:400*25.4/72,productConfirmed:true,sizeConfirmed:true};for(const r of a.runs)r.role='custom';
const built=await compileDesign(source,a,'Recovered heading',assets);built.manifest=JSON.parse(JSON.stringify(built.manifest));fs.writeFileSync('work/r39-original-render.pdf',await renderTemplate(built.base,built.manifest,{},false,assets));const values=Object.fromEntries(built.manifest.fields.map((r,i)=>[r.id,i?'Garden':'Beautiful Home']));assert.equal(evaluateTemplate(built.manifest,values,false).valid,true);const pdf=await renderTemplate(built.base,built.manifest,values,false,assets);fs.writeFileSync('work/r39-edited.pdf',pdf);
// Unknown or ambiguous outlines must not silently be replaced by a lookalike.
const modified=structuredClone(font);for(const g of Object.values(modified.glyphs))g.advance+=80;
assert.equal(await matchEmbeddedFont(modified,['NimbusRomNo9L-Med'],assets.loadFont!),undefined);
console.log('PASS: anonymous R39 Type3 headings resolve to full supplied Nimbus, new characters render, mismatched fonts are rejected.');
