import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PDFDocument} from 'pdf-lib';
import {POST as create} from '../app/api/templates/route';
import {PUT as put} from '../app/api/templates/[id]/assets/[asset]/route';
import {POST as complete} from '../app/api/templates/[id]/complete/route';
import {POST as upload} from '../app/api/templates/[id]/media/route';
import {GET as getImage} from '../app/api/templates/[id]/media/[assetId]/route';
import {POST as render} from '../app/api/templates/[id]/render/route';
function request(method='GET',body?:BodyInit|Uint8Array,user='owner',extra:Record<string,string>={}){return new Request('https://example.test/api/templates',{method,body:body instanceof Uint8Array?new Uint8Array(body).buffer:body,headers:{...(user?{'oai-authenticated-user-id':user}:{}),...extra}});}
const source=fs.readFileSync(process.argv[2]??'../upload/6x4 Photo Signboard (1).pdf');
const row=await create(request('POST',JSON.stringify({name:'Photo API test',sourceName:'6x4 Photo Signboard (1).pdf'})));
assert.equal(row.status,201);const{id}=await row.json()as{id:string};const context={params:Promise.resolve({id})};
for(const[asset,data]of [['source',source],['base',fs.readFileSync('work/photo-base.pdf')],['manifest',fs.readFileSync('work/photo-manifest.json')],['thumbnail',fs.readFileSync('work/storage-thumbnail.png')]]as[string,Buffer][]){assert.equal((await put(request('PUT',data),{params:Promise.resolve({id,asset})})).status,200);}
assert.equal((await complete(request('POST'),context)).status,200);
const prepared=fs.readFileSync('work/prepared-image.pdf');const headers={'content-type':'application/pdf','x-image-name':'Replacement%20photo.png'};
assert.equal((await upload(request('POST',prepared,'outsider',headers),context)).status,404);
assert.equal((await upload(request('POST',prepared,'owner',{...headers,origin:'https://outsider.test'}),context)).status,403);
const uploaded=await upload(request('POST',prepared,'owner',headers),context);assert.equal(uploaded.status,201);const asset=await uploaded.json()as{assetId:string;width:number;height:number;name:string};assert.equal(asset.width,4000);assert.equal(asset.name,'Replacement photo.png');
const imageContext={params:Promise.resolve({id,assetId:asset.assetId})};const stored=await getImage(request(),imageContext);assert.deepEqual(Buffer.from(await stored.arrayBuffer()),prepared);assert.equal((await getImage(request('GET',undefined,'outsider'),imageContext)).status,404);
const job={mode:'proof',agents:[{name:'Zoë Anderson',phone:'0412 345 678'}],media:{image_1:{assetId:asset.assetId,fit:'cover',focalX:.2,focalY:.8},qr_1:{url:'https://example.com/property/api'}}};
async function send(value:unknown,user='owner'){return render(request('POST',JSON.stringify(value),user,{'content-type':'application/json'}),context);}
assert.equal((await send(job,'')).status,401);assert.equal((await send(job,'outsider')).status,404);
const result=await send(job);if(result.status!==200)throw new Error(await result.text());assert.equal(result.headers.get('X-Print-Status'),'proof');const pdf=new Uint8Array(await result.arrayBuffer());assert.equal((await PDFDocument.load(pdf)).getPageCount(),1);fs.writeFileSync('work/photo-api.pdf',pdf);
const blocked=await send({...job,mode:'print'});assert.equal(blocked.status,422);assert.ok((await blocked.text()).includes('filename'));
assert.equal((await send({...job,agents:[{name:'Missing phone'}]})).status,422);
assert.equal((await send({...job,text:{not_a_field:'Unmapped'}})).status,422);
assert.equal((await send({...job,media:{unknown:{url:'https://example.com'}}})).status,422);
assert.equal((await send({...job,media:{image_1:{assetId:crypto.randomUUID()}}})).status,422);
assert.equal((await send({...job,media:{image_1:{assetId:asset.assetId,focalX:2}}})).status,422);
assert.equal((await send({...job,media:{qr_1:{url:'javascript:alert(1)'}}})).status,422);
assert.equal((await upload(request('POST',source,'owner',headers),context)).status,422);
// A saved template may contain media fields only.
const mediaRow=await create(request('POST',JSON.stringify({name:'Media-only API test',sourceName:'Media.pdf'})));const{id:mediaId}=await mediaRow.json()as{id:string};const m=JSON.parse(fs.readFileSync('work/photo-manifest.json','utf8'));m.fields=[];m.fonts={};for(const[asset,data]of [['source',source],['base',fs.readFileSync('work/photo-base.pdf')],['manifest',Buffer.from(JSON.stringify(m))],['thumbnail',fs.readFileSync('work/storage-thumbnail.png')]]as[string,Buffer][]){assert.equal((await put(request('PUT',data),{params:Promise.resolve({id:mediaId,asset})})).status,200);}assert.equal((await complete(request('POST'),{params:Promise.resolve({id:mediaId})})).status,200);
console.log('PASS: saved media assets, actual JSON job generation, single-agent data, proof/print gating, media-only templates, private ownership, origin checks and invalid-job rejection.');
