import fs from 'node:fs';
import assert from 'node:assert/strict';
import{encode}from'fast-png';
import{PDFDocument,PDFName,PDFArray,PDFRawStream,decodePDFRawStream}from'pdf-lib';
import{analyseDesign,compileDesign,renderTemplate,evaluateTemplate,loadEngineAssets}from'../lib/template-engine';
import{defaultMediaValues,evaluateMedia,prepareImage,validatePreparedImage}from'../lib/template-media';
import type{MediaSlot}from'../lib/template-types';
const sourcePath=process.argv[2]??'../upload/6x4 Photo Signboard (1).pdf';
globalThis.fetch=async(input:any)=>{const path='public'+new URL(String(input),'https://example.test').pathname;return fs.existsSync(path)?new Response(fs.readFileSync(path)):new Response('',{status:404});};
const assets=await loadEngineAssets(),source=new Uint8Array(fs.readFileSync(sourcePath));
const analysis=await analyseDesign(source,'6x4 Photo Signboard (1).pdf',0,assets);assert.deepEqual(analysis.errors,[]);assert.equal(analysis.runs.filter(f=>f.role.startsWith('agent')).length,4);assert.ok(analysis.runs.every(f=>f.size>0));
console.log('Media found:',analysis.media?.map(m=>({id:m.id,key:m.key,role:m.role,url:m.sourceUrl,frame:[m.x,m.y,m.width,m.height]})));
assert.equal(analysis.media?.filter(s=>s.role==='image').length,1);assert.equal(analysis.media?.filter(s=>s.role==='qr').length,1);
for(const r of analysis.runs)if(r.supported&&r.fontName.startsWith('Poppins')&&r.role==='fixed'){r.role='custom';r.label=r.text;}
const built=await compileDesign(source,analysis,'Photo template',assets),values=Object.fromEntries(built.manifest.fields.map(f=>[f.id,f.text]));const original=defaultMediaValues(built.manifest);assert.equal(evaluateTemplate(built.manifest,values,false).valid,true);
fs.writeFileSync('work/photo-original-full.pdf',analysis.preview!);fs.writeFileSync('work/photo-recreated.pdf',await renderTemplate(built.base,built.manifest,values,false,assets,original));
const w=4000,h=2700,pixels=new Uint8Array(w*h*3);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*3;pixels[i]=Math.floor(x/w*220)+20;pixels[i+1]=Math.floor(y/h*200)+30;pixels[i+2]=(Math.floor(x/300)+Math.floor(y/300))%2?100:200;}
const prepared=await prepareImage(encode({width:w,height:h,channels:3,data:pixels}),'New photo.png',assets.table);assert.deepEqual(await validatePreparedImage(prepared.pdf),{width:w,height:h});fs.writeFileSync('work/prepared-image.pdf',prepared.pdf);
const image=built.manifest.media!.find(s=>s.role==='image')!,qr=built.manifest.media!.find(s=>s.role==='qr')!;
const media={...original,[image.id]:{kind:'image' as const,image:prepared},[qr.id]:{kind:'qr' as const,url:'https://example.com/property/updated'}};
assert.equal(evaluateMedia(built.manifest,media).valid,true);assert.deepEqual(evaluateMedia(built.manifest,media).printIssues,[]);assert.ok(evaluateMedia(built.manifest,original).printIssues.some(s=>s.includes('dpi')));
for(const f of built.manifest.fields){if(f.role==='agent1_name')values[f.id]='Zoë Anderson';if(f.role==='agent1_phone')values[f.id]='0412 345 678';if(f.role==='agent2_name')values[f.id]='James Carter';if(f.text.startsWith('Modern elegance'))values[f.id]='Beautifully renovated and ready to call home';if(f.text==='By Appointment')values[f.id]='Saturday 12 pm';}
fs.writeFileSync('work/photo-with-media.pdf',await renderTemplate(built.base,built.manifest,values,false,assets,media));
fs.writeFileSync('work/photo-single.pdf',await renderTemplate(built.base,built.manifest,values,true,assets,media));
const singleAgent=evaluateTemplate(built.manifest,values,true).fields.filter(f=>f.role.startsWith('agent1_'));const twoAgents=evaluateTemplate(built.manifest,values,false).fields;for(const f of singleAgent){const original=twoAgents.find(v=>v.id===f.id)!;assert.equal(f.x,original.x);assert.equal(f.y,original.y);}
assert.equal(evaluateMedia(built.manifest,{...media,[qr.id]:{kind:'qr',url:'javascript:alert(1)'}}).valid,false);
fs.writeFileSync('work/photo-manifest.json',JSON.stringify(built.manifest));fs.writeFileSync('work/photo-base.pdf',built.base);
// A marked region supports vector/flattened QR codes without removing surrounding artwork.
const marked=structuredClone(analysis);marked.media=marked.media!.filter(s=>s.role!=='qr');const region:MediaSlot={...qr,id:'marked_qr',key:'marked_qr',region:true,stream:'page',opIndex:-1,resourceName:'',matrix:[qr.width,0,0,qr.height,qr.x,qr.y],viewport:[0,0,1,1]};marked.media.push(region);
const markedBase=await compileDesign(source,marked,'Marked QR',assets);fs.writeFileSync('work/photo-marked-qr.pdf',await renderTemplate(markedBase.base,markedBase.manifest,{},false,assets,{marked_qr:{kind:'qr',url:'https://example.com/marked'}}));
// A second placement of the same image must have an independent replacement wrapper.
const duplicate=await PDFDocument.load(source);const page=duplicate.getPage(0);page.node.addContentStream(duplicate.context.register(duplicate.context.flateStream(new TextEncoder().encode('q 300 0 0 -200 200 600 cm /I1 Do Q'))));const twoSource=await duplicate.save();const twoAnalysis=await analyseDesign(twoSource,'6x4 Photo Signboard.pdf',0,assets);const two=await compileDesign(twoSource,twoAnalysis,'Two photos',assets);const photos=two.manifest.media!.filter(s=>s.role==='image');assert.equal(photos.length,2);const swapped={...defaultMediaValues(two.manifest),[photos[0].id]:{kind:'original' as const,slotId:photos[1].id},[photos[1].id]:{kind:'image' as const,image:prepared}};fs.writeFileSync('work/two-photo-slots.pdf',await renderTemplate(two.base,two.manifest,{},false,assets,swapped));
const output=await PDFDocument.load(fs.readFileSync('work/photo-with-media.pdf'));const slots=output.context.enumerateIndirectObjects().filter(([,o])=>o instanceof PDFRawStream&&o.dict.has(PDFName.of('SignboardSlot')));assert.equal(slots.length,2);assert.equal(output.getPageCount(),1);
for(const[,o]of output.context.enumerateIndirectObjects())if(o instanceof PDFRawStream&&o.dict.get(PDFName.of('Subtype'))?.toString()==='/Image')assert.ok(!o.dict.get(PDFName.of('ColorSpace'))?.toString().includes('DeviceRGB'));
console.log('PASS: automatic photo/QR detection, supplied fonts, CMYK image preparation, replacement inside original layer, multi-slot ordering, QR link generation, marked QR regions, original agent positions and resolution/URL preflight.');
