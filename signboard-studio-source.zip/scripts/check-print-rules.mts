import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PDFDocument,PDFArray,PDFName,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {analyseDesign,compileDesign,evaluateTemplate,layoutIssues,renderTemplate} from '../lib/template-engine';
import {printRuleIssues,suggestPrintSpec} from '../lib/print-specs';
import {latin,operations} from '../lib/pdf-content';
import {POST as create} from '../app/api/templates/route';
import {PUT as put} from '../app/api/templates/[id]/assets/[asset]/route';
import {POST as complete} from '../app/api/templates/[id]/complete/route';
import {POST as render} from '../app/api/templates/[id]/render/route';
import {env} from './test-storage-env.mjs';
const p=JSON.parse(fs.readFileSync('public/template/edgewrap.json','utf8'));
const assets={poppins:{name:'Poppins-SemiBold',unitsPerEm:p.unitsPerEm,glyphs:p.glyphs},icc:new Uint8Array(fs.readFileSync('template-source/source-swop.icc')),table:new Uint8Array(fs.readFileSync('public/template/rgb-to-cmyk-33.bin'))};
const mm=25.4/72;
function near(actual:number,expected:number){assert.ok(Math.abs(actual-expected)<.01,`${actual} != ${expected}`);}
const expected=[
 ['A4_Brochure.pdf','brochure',210,297,2,0,214,301],
 ['DL_Mailcard.pdf','mailcard',210,99,2,0,214,103],
 ['Business_Card.pdf','business_card',90,55,2,0,94,59],
 ['600x450_Corflute.pdf','pointer',600,450,2,2,610,457],
 ['6x4_Bannerwrap.pdf','bannerwrap',1832,1220,116,2,2064,1452],
]as const;
let brochure:any;
for(const[name,product,width,height,bleed,count,sheetW,sheetH]of expected){
 const source=new Uint8Array(fs.readFileSync(`work/${name}`));const analysis=await analyseDesign(source,name,0,assets);
 assert.equal(analysis.spec.product,product);assert.equal(analysis.spec.sourceIncludesBleed,true,name);near(analysis.spec.faceWidth,width);near(analysis.spec.faceHeight,height);assert.equal(analysis.spec.bleed,bleed);
 // A legacy false marks flag must not disable compulsory signboard marks.
 analysis.spec.marks=false;
 const built=await compileDesign(source,analysis,name,assets);assert.deepEqual(built.manifest.printIssues,[]);const fit=evaluateTemplate(built.manifest,{},false);assert.deepEqual(fit.errors,[]);assert.deepEqual(fit.printIssues,[]);
 const result=await renderTemplate(built.base,built.manifest,{},false,assets);fs.writeFileSync(`work/verified-${name}`,result);
 const doc=await PDFDocument.load(result),page=doc.getPage(0),trim=page.getTrimBox(),b=page.getBleedBox();
 near(page.getWidth()*mm,sheetW);near(page.getHeight()*mm,sheetH);near(trim.width*mm,width);near(trim.height*mm,height);
 near((trim.x-b.x)*mm,bleed);near((trim.y-b.y)*mm,bleed);near((b.x+b.width-trim.x-trim.width)*mm,bleed);near((b.y+b.height-trim.y-trim.height)*mm,bleed);
 const contents=page.node.Contents()as PDFArray,final=doc.context.lookup(contents.get(contents.size()-1))as PDFRawStream;
 const rectangles=operations(latin(decodePDFRawStream(final).decode())).filter(op=>op.op==='re');assert.equal(rectangles.length,count);
 for(const[index,op]of rectangles.entries()){const[x,y,w,h]=op.args.map(arg=>Number(arg.value)*mm);near(w,5);near(h,5);near(y+5,trim.y*mm);near(index===0?x+5:x,(trim.x+(index?trim.width:0))*mm);assert.ok(x>=-.01&&y>=-.01&&x+w<=sheetW+.01&&y+h<=sheetH+.01,'Mark must fit on the media page');}
 if(product==='brochure')brochure={source,...built};
 console.log(`PASS ${product}: ${width} × ${height} mm face, ${bleed} mm bleed, ${count} full 5 mm squares.`);
}
for(const name of ['A4_Brochure_NoBleed.pdf','A4_Brochure_Unsafe.pdf']){
 const source=new Uint8Array(fs.readFileSync(`work/${name}`)),analysis=await analyseDesign(source,name,0,assets),built=await compileDesign(source,analysis,name,assets);
 const issues=[...built.manifest.printIssues,...evaluateTemplate(built.manifest,{},false).printIssues];assert.ok(issues.some(i=>name.includes('NoBleed')?i.includes('no confirmed bleed'):i.includes('5 mm safe text margin')),issues.join('\n'));
}
const zero={...brochure.manifest.spec,bleed:0};assert.ok(layoutIssues(zero,brochure.manifest.sourceWidth,brochure.manifest.sourceHeight).length);
const incomplete={...brochure.manifest.spec,bleedInsets:{top:2,bottom:2,left:2}};assert.ok(layoutIssues(incomplete,brochure.manifest.sourceWidth,brochure.manifest.sourceHeight).length,'All four bleed edges are required');
const wrong={...brochure.manifest.spec,bleed:65};assert.ok(printRuleIssues(wrong).some(i=>i.includes('requires 2 mm')));
const square=suggestPrintSpec('600x600_Corflute.pdf',600/mm/4,600/mm/4);assert.equal(square.spec.sourceIncludesBleed,false,'A square ratio alone is not proof of bleed');
const unknown=suggestPrintSpec('Artwork.pdf',210/mm,297/mm);assert.equal(unknown.spec.productConfirmed,false);assert.ok(printRuleIssues(unknown.spec).length);
const customSource=new Uint8Array(fs.readFileSync('work/Custom_Asymmetric.pdf'));const custom=await analyseDesign(customSource,'Custom_Asymmetric.pdf',0,assets);
custom.spec={faceWidth:210,faceHeight:297,bleed:2,bleedInsets:{left:2,bottom:3,right:4,top:5},sourceIncludesBleed:true,marks:false,product:'other_print',productConfirmed:true,bleedConfirmed:true};
const customBuilt=await compileDesign(customSource,custom,'Asymmetric',assets);const customPdf=await renderTemplate(customBuilt.base,customBuilt.manifest,{},false,assets);fs.writeFileSync('work/verified-asymmetric.pdf',customPdf);
const customPage=(await PDFDocument.load(customPdf)).getPage(0),ct=customPage.getTrimBox();near(ct.x*mm,2);near(ct.y*mm,3);near(customPage.getWidth()*mm,216);near(customPage.getHeight()*mm,305);
assert.deepEqual(evaluateTemplate(customBuilt.manifest,{},false).printIssues,[]);

function request(method:string,body?:BodyInit){return new Request('https://example.test/api/templates',{method,body,headers:{'oai-authenticated-user-id':'owner','content-type':'application/json'}});}
const created=await create(request('POST',JSON.stringify({name:'Print rules',sourceName:'A4_Brochure.pdf'})));assert.equal(created.status,201);const{id}=await created.json()as{id:string},context={params:Promise.resolve({id})};
for(const[asset,data]of [['source',brochure.source],['base',brochure.base],['manifest',Buffer.from(JSON.stringify(brochure.manifest))],['thumbnail',fs.readFileSync('work/storage-thumbnail.png')]]as[string,Uint8Array][]){assert.equal((await put(request('PUT',new Uint8Array(data).buffer),{params:Promise.resolve({id,asset})})).status,200);}
assert.equal((await complete(request('POST'),context)).status,200);
let result=await render(request('POST',JSON.stringify({mode:'print'})),context);assert.equal(result.status,200,await(result.status===200?Promise.resolve(''):result.text()));assert.equal(result.headers.get('X-Print-Status'),'ready');
// Model old or inconsistent stored manifests: cached printIssues=[] cannot bypass
// current bleed and safe-margin requirements in the actual job route.
const bad=structuredClone(brochure.manifest);bad.spec.sourceIncludesBleed=false;bad.spec.faceWidth=214;bad.spec.faceHeight=301;bad.printIssues=[];
await env.BUCKET.put(`templates/${id}/manifest`,JSON.stringify(bad));result=await render(request('POST',JSON.stringify({mode:'print'})),context);assert.equal(result.status,422);assert.ok((await result.text()).includes('no confirmed bleed'));
assert.equal((await render(request('POST',JSON.stringify({mode:'proof'})),context)).status,200);
const legacy=structuredClone(brochure.manifest);delete legacy.spec.product;delete legacy.spec.productConfirmed;legacy.printIssues=[];
await env.BUCKET.put(`templates/${id}/manifest`,JSON.stringify(legacy));assert.equal((await render(request('POST',JSON.stringify({mode:'print'})),context)).status,200,'Legacy brochure must receive the card/brochure rule');
legacy.spec.bleed=65;legacy.spec.faceWidth=legacy.sourceWidth*mm-130;legacy.spec.faceHeight=legacy.sourceHeight*mm-130;await env.BUCKET.put(`templates/${id}/manifest`,JSON.stringify(legacy));result=await render(request('POST',JSON.stringify({mode:'print'})),context);assert.equal(result.status,422);
console.log('PASS mandatory bleed, safe text, asymmetric bleed, square-page detection and current-rule enforcement in the actual saved job API.');
