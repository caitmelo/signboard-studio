import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PDFDocument,PDFArray,PDFName,PDFNumber,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {analyseDesign,compileDesign,evaluateTemplate,renderTemplate} from '../lib/template-engine';
import {operations,latin,inspectPdf} from '../lib/pdf-content';
import {colourConverter} from '../lib/template-colour';
const p=JSON.parse(fs.readFileSync('public/template/edgewrap.json','utf8'));
const assets={poppins:{name:'Poppins-SemiBold',unitsPerEm:p.unitsPerEm,glyphs:p.glyphs},icc:new Uint8Array(fs.readFileSync('template-source/source-swop.icc')),table:new Uint8Array(fs.readFileSync('public/template/rgb-to-cmyk-33.bin'))};
const escaped=operations('BT /F1 20 Tf [(Sam \\(Test\\)) -30 <2030313233>] TJ ET');
assert.equal(escaped[2].op,'TJ');assert.equal(escaped[2].args[0].value[0].value,'Sam (Test)');
const paths=[['../upload/Sprint Solutions_6x4 Edgewrap_Signboard Specs(1).pdf','imported'],['work/New_8x4_Edgewrap.pdf','landscape']];
for(const[path,key]of paths){
 if(!fs.existsSync(path)){console.log(`SKIP unavailable optional reference: ${path}`);continue;}
 const source=new Uint8Array(fs.readFileSync(path));
 const analysis=await analyseDesign(source,path,0,assets);
 assert.deepEqual(analysis.errors,[]);assert.equal(analysis.pageCount,2);assert.equal(analysis.spec.sourceIncludesBleed,true);
 assert.equal(analysis.runs.filter(r=>r.role.startsWith('agent')).length,4);assert.ok(analysis.runs.filter(r=>r.supported&&r.encodingComplete).every(r=>r.role!=='fixed'));
 const built=await compileDesign(source,analysis,key,assets);console.log(key,'print issues:',built.manifest.printIssues);
 assert.deepEqual(built.manifest.printIssues,[]);
 fs.writeFileSync(`work/${key}-manifest.json`,JSON.stringify(built.manifest));fs.writeFileSync(`work/${key}-base.pdf`,built.base);
 const values=Object.fromEntries(built.manifest.fields.map(f=>[f.id,f.text]));
 const initial=evaluateTemplate(built.manifest,values,false);assert.equal(initial.valid,true,initial.errors.join('\n'));
 for(const f of initial.fields){const original=built.manifest.fields.find(x=>x.id===f.id)!;assert.ok(Math.abs(f.x-original.x)<1e-6);assert.equal(f.size,original.size);}
 const result=await renderTemplate(built.base,built.manifest,values,false,assets);fs.writeFileSync(`work/${key}-two.pdf`,result);
 const checked=await PDFDocument.load(result);assert.equal(checked.getPageCount(),1);const page=checked.getPage(0),mm=25.4/72;
 assert.ok(Math.abs(page.getWidth()*mm-(analysis.spec.faceWidth+2*analysis.spec.bleed))<.01);
 assert.ok(Math.abs(page.getTrimBox().width*mm-analysis.spec.faceWidth)<.01);
 const inspected=await inspectPdf(result,0,colourConverter(assets.table));
 assert.equal([...inspected.streams.values()].flatMap(s=>s.ops).filter(o=>['rg','RG'].includes(o.op)).length,0);
 const content=page.node.Contents()as PDFArray;const final=checked.context.lookup(content.get(content.size()-1))as PDFRawStream;
 const marks=operations(latin(decodePDFRawStream(final).decode())).filter(o=>o.op==='re');assert.equal(marks.length,2);
 for(const mark of marks){assert.ok(Math.abs(mark.args[2].value*mm-5)<1e-6);assert.ok(Math.abs(mark.args[3].value*mm-5)<1e-6);}
 for(const image of inspected.images.values()){const space=checked.context.lookup(image.object.dict.get(PDFName.of('ColorSpace')));assert.ok(!String(space).includes('DeviceRGB'));}
 for(const f of built.manifest.fields)if(f.role==='agent1_name')values[f.id]='Zoë Anderson';
 const single=evaluateTemplate(built.manifest,values,true);assert.equal(single.valid,true,single.errors.join('\n'));assert.equal(single.fields.length,built.manifest.fields.length-2);
 for(const field of single.fields.filter(f=>f.role.startsWith('agent1_')))assert.ok(Math.abs(field.x-built.manifest.fields.find(f=>f.id===field.id)!.x)<1e-6);
 fs.writeFileSync(`work/${key}-one.pdf`,await renderTemplate(built.base,built.manifest,values,true,assets));
 const name=built.manifest.fields.find(f=>f.role==='agent1_name')!;
 assert.equal(evaluateTemplate(built.manifest,{...values,[name.id]:'W'.repeat(100)},true).valid,false);
 assert.equal(evaluateTemplate(built.manifest,{...values,[name.id]:'Agent 🏠'},true).valid,false);
 assert.equal(evaluateTemplate(built.manifest,{...values,[name.id]:''},true).valid,false);
 const vertical=structuredClone(built.manifest);vertical.fields.find(f=>f.id===name.id)!.y=0;assert.equal(evaluateTemplate(vertical,values,true).valid,false);
 const fixed=structuredClone(built.manifest);fixed.fixedText=[{text:'Fixed obstacle',x:analysis.width/2-10,y:name.y,width:20,size:name.size}];assert.equal(evaluateTemplate(fixed,values,true).valid,false);
 const noBleed=structuredClone(analysis);noBleed.spec={...analysis.spec,sourceIncludesBleed:false,faceWidth:analysis.spec.faceWidth+130,faceHeight:analysis.spec.faceHeight+130};assert.ok((await compileDesign(source,noBleed,'proof',assets)).manifest.printIssues.some(i=>i.includes('bleed')));
 if(key==='landscape'){
  const second=await analyseDesign(source,path,1,assets);assert.equal(second.runs[0].text,'Reference page only');
  const large=structuredClone(built.manifest);large.spec.faceWidth*=3;large.spec.faceHeight*=3;large.spec.bleed*=3;
  const largePdf=await renderTemplate(built.base,large,values,true,assets);fs.writeFileSync('work/large-format.pdf',largePdf);
  const largeDoc=await PDFDocument.load(largePdf);const lp=largeDoc.getPage(0);const unit=lp.node.lookup(PDFName.of('UserUnit'),PDFNumber).asNumber();assert.ok(lp.getWidth()<=14400);assert.ok(Math.abs(lp.getWidth()*unit*mm-(large.spec.faceWidth+2*large.spec.bleed))<.01);
 }
 console.log(`PASS ${key}: original layout, CMYK vector/image output, full dimensions, two 5 mm marks, single-agent source anchors, missing glyph/overflow/collision blocking.`);
}
