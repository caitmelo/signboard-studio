import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GET as list,POST as create} from '../app/api/templates/route';
import {GET as get,PUT as put} from '../app/api/templates/[id]/assets/[asset]/route';
import {POST as complete} from '../app/api/templates/[id]/complete/route';
async function catalogue(req:Request){return await(await list(req)).json()as{templates:{field_count:number}[]};}
function request(method='GET',body?:BodyInit,user='owner',extra:Record<string,string>={}){return new Request('https://example.test/api/templates',{method,body,headers:{...(user?{'oai-authenticated-user-id':user}:{}),...extra}});}
assert.equal((await list(request('GET',undefined,''))).status,401);
assert.equal((await create(request('POST','{}','owner',{origin:'https://unrelated.test'}))).status,403);
const row=await create(request('POST',JSON.stringify({name:'Integration template',sourceName:'New_8x4.pdf'})));
assert.equal(row.status,201);const{id}=await row.json()as{id:string};
const context={params:Promise.resolve({id})};
assert.equal((await catalogue(request())).templates.length,0,'Partial uploads are not listed');
assert.equal((await complete(request('POST'),context)).status,409);
for(const[asset,file]of [['source','work/New_8x4_Edgewrap.pdf'],['base','work/landscape-base.pdf'],['manifest','work/landscape-manifest.json'],['thumbnail','work/storage-thumbnail.png']]){
 const data=fs.readFileSync(file);const args={params:Promise.resolve({id,asset})};
 assert.equal((await put(request('PUT',data,'someone-else'),args)).status,404);
 assert.equal((await put(request('PUT',data),args)).status,200,'Uploads without Content-Length are supported');
 const restored=await get(request(),args);assert.equal(restored.status,200);assert.deepEqual(Buffer.from(await restored.arrayBuffer()),data);
}
assert.equal((await complete(request('POST'),context)).status,200);
assert.equal((await complete(request('POST'),context)).status,200,'Finalization is idempotent');
const ready=await catalogue(request());assert.equal(ready.templates.length,1);const manifest=JSON.parse(fs.readFileSync('work/landscape-manifest.json','utf8'));assert.equal(ready.templates[0].field_count,manifest.fields.length+(manifest.media??[]).filter((s:any)=>s.role!=='fixed').length);
assert.equal((await catalogue(request('GET',undefined,'someone-else'))).templates.length,0);
assert.equal((await get(request('GET',undefined,'someone-else'),{params:Promise.resolve({id,asset:'manifest'})})).status,404);
assert.equal((await put(request('PUT','replacement'),{params:Promise.resolve({id,asset:'base'})})).status,409);
assert.equal((await put(request('PUT','x','owner',{'content-length':String(60*1024*1024)}),{params:Promise.resolve({id,asset:'base'})})).status,413);
console.log('PASS: real SQLite migration, draft lifecycle, complete/reopen, exact asset bytes, missing-length uploads, owner isolation, authentication, origin checks, upload limits and immutable saved templates.');
