import fs from 'node:fs';
import assert from 'node:assert/strict';
import {PDFDocument} from 'pdf-lib';
import {loadEngineAssets,analyseDesign,compileDesign,evaluateTemplate,renderTemplate} from '../lib/template-engine';
import {detectDocument} from '../lib/document-setup';
import {defaultMediaValues} from '../lib/template-media';
import type {ContentValues} from '../lib/template-types';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets();
const input=process.argv[2];if(!input)throw new Error('Pass a directory containing PDF fixtures. Outputs go to work/batch-*');fs.mkdirSync('work',{recursive:true});
const names=fs.readdirSync(input).filter(n=>n.endsWith('.pdf'));let report:any[]=[];
for(const [idx,name] of names.entries()){

 const source=new Uint8Array(fs.readFileSync(input+'/'+name)),doc=await PDFDocument.load(source);console.log('START',idx,name,source.length);
 for(let p=0;p<doc.getPageCount();p++){
  const prefix=`work/batch-${idx}-${p}`;
  try{
  const a=await analyseDesign(source,name,p,assets),setup=await detectDocument(source,name,p);a.spec={...setup.spec,productConfirmed:true,sizeConfirmed:true};
  const b=await compileDesign(source,a,name,assets),t=b.manifest;
  fs.writeFileSync(prefix+'-manifest.json',JSON.stringify(t));fs.writeFileSync(prefix+'-base.pdf',b.base);
  const values=Object.fromEntries(t.fields.map(f=>[f.id,f.text]));const baseline=evaluateTemplate(t,values,false);const content:ContentValues={};
  for(const f of t.fields){if(f.role.endsWith('_name'))values[f.id]='Caitlin Micallef';if(f.role.endsWith('_phone'))values[f.id]='0449 754 440';if(/just listed/i.test(f.text))values[f.id]=f.text.replace(/just listed/ig,'JUST SOLD');}
  for(const g of t.groups??[]){if(g.kind==='sale')content[g.key]={type:'auction',date:'2026-09-10',time:'12:00'};if(g.kind==='features')content[g.key]={beds:'1',baths:'1',cars:'1'};}
  for(const g of t.groups??[]){const text=g.fieldIds.map(id=>t.fields.find(f=>f.id===id)?.text).join(' ');if(g.kind==='heading'&&/Freshly Updated/.test(text))content[g.key]='Newly Updated\nFamily Home';if(g.kind==='heading'&&/just\s+listed/i.test(text))content[g.key]=g.fieldIds.length===2?'Just\nSold':'JUST SOLD';if(g.kind==='agency'&&g.bindings?.contact){content[g.key]={visible:true,phone:t.fields.find(f=>f.id===g.bindings?.phone)?.text??'',contact:'beleef.com.au'};}}
  const media=defaultMediaValues(t);for(const m of t.media??[]){if(m.role==='qr')media[m.id]={kind:'qr',url:'https://www.beleef.com.au/'};}
  const photos=(t.media??[]).filter(m=>m.role==='image'&&!m.agent&&m.width>t.sourceWidth*.25);if(photos.length>1){photos.forEach((m,i)=>media[m.id]={kind:'original',slotId:photos[(i+1)%photos.length].id,fit:'cover',focalX:.5,focalY:.5});}
  const edited=evaluateTemplate(t,values,false,content);
  const cases:any[]=[];
  for(const g of t.groups??[]){if(content[g.key])cases.push({key:g.key,kind:g.kind,errors:evaluateTemplate(t,Object.fromEntries(t.fields.map(f=>[f.id,f.text])),false,{[g.key]:content[g.key]}).errors});}
  if(edited.valid)fs.writeFileSync(prefix+'-edited.pdf',await renderTemplate(b.base,t,values,false,assets,media,content));
  fs.writeFileSync(prefix+'-job.json',JSON.stringify({text:values,content,oneAgent:false,mode:'proof',media:Object.fromEntries(Object.entries(media).map(([k,v])=>[k,v.kind==='qr'?{url:v.url}:v.kind==='original'?{sourceSlot:v.slotId,fit:v.fit,focalX:v.focalX,focalY:v.focalY}:{}]))}));
  const row={name,page:p+1,prefix,groups:t.groups?.map(g=>({kind:g.kind,key:g.key,text:g.fieldIds.map(id=>t.fields.find(f=>f.id===id)?.text).join(' | ')})),media:t.media?.map(m=>({role:m.role,x:m.x,y:m.y,width:m.width,height:m.height})),baseline:baseline.errors,errors:edited.errors,cases,printIssues:edited.printIssues,warnings:a.warnings};report.push(row);console.log(JSON.stringify({name,page:p+1,groups:row.groups,baseline:row.baseline,errors:row.errors,cases}));
  }catch(e){report.push({name,page:p+1,error:String(e)});console.log('ERROR',name,p,String(e));}
  fs.writeFileSync('work/batch-report.json',JSON.stringify(report,null,2));
 }
}

assert.ok(report.length>0,'No PDF fixtures found');
assert.ok(report.every(r=>!r.error&&!r.baseline?.length&&!r.errors?.length),'See work/batch-report.json for failed imports or edits');
console.log(`PASS ${names.length} PDFs, ${report.length} pages. Print warnings remain separately reported.`);
