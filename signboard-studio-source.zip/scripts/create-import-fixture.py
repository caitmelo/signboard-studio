"""Generate an independent live-text landscape fixture; no user artwork required."""
from pathlib import Path
from fontTools.ttLib import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLFont
from reportlab.lib.utils import ImageReader
from PIL import Image

root = Path(__file__).resolve().parent.parent
out = root / 'work'
out.mkdir(exist_ok=True)
font = TTFont(root / 'template-source/Poppins-SemiBold-latin.woff')
font.flavor = None
font.save(out / 'fixture-poppins.ttf')
pdfmetrics.registerFont(RLFont('Poppins', str(out / 'fixture-poppins.ttf')))
w, h = 2570 * 72 / 25.4 / 4, 1350 * 72 / 25.4 / 4
c = Canvas(str(out / 'New_8x4_Edgewrap.pdf'), pagesize=(w, h), pageCompression=1)
c.setFillColorRGB(.04, .25, .22)
c.rect(0, 0, w, h, fill=1, stroke=0)
c.setFillColorRGB(1, .72, .34)
c.rect(w * .5, 0, w * .5, h, fill=1, stroke=0)
c.setFillColorRGB(1, 1, 1)
c.setFont('Poppins', 65)
c.drawString(85, h - 150, 'Open home')
c.setFont('Poppins', 22)
c.drawString(88, h - 195, 'Saturday 12:00 pm')
image = Image.new('RGB', (400, 240))
image.putdata([(int(x / 399 * 255), int(y / 239 * 220), 100) for y in range(240) for x in range(400)])
c.drawImage(ImageReader(image), w * .57, h * .29, width=w * .35, height=h * .51)
for name, phone, x in [('Ava Chen', '0401 234 567', w * .26), ('Liam Reed', '0408 765 432', w * .73)]:
    c.setFont('Poppins', 29)
    c.drawCentredString(x, 155, name)
    c.setFont('Poppins', 31)
    c.drawCentredString(x, 108, phone)
c.setFont('Poppins', 19)
c.drawString(85, 55, 'EXAMPLE REAL ESTATE')
c.showPage()
c.setFont('Poppins', 20)
c.drawString(50, h - 70, 'Reference page only')
c.save()
# Tiny valid thumbnail fixture for storage tests; not an app preview.
Image.new('RGB', (2, 2), 'white').save(out / 'storage-thumbnail.png')
print('Created two-page landscape 8x4 fixture.')
