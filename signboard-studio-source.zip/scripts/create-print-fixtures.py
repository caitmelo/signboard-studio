"""Independent Sprint print fixtures, all dimensions explicitly in millimetres."""
from pathlib import Path
from fontTools.ttLib import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLFont

root = Path(__file__).resolve().parent.parent
out = root / 'work'
out.mkdir(exist_ok=True)
font = TTFont(root / 'template-source/Poppins-SemiBold-latin.woff')
font.flavor = None
font.save(out / 'fixture-poppins.ttf')
pdfmetrics.registerFont(RLFont('Poppins', str(out / 'fixture-poppins.ttf')))

def fixture(name, width, height, bleed, quarter=False, safe=True):
    left, bottom, right, top = bleed
    factor = 72 / 25.4 / (4 if quarter else 1)
    w, h = (width + left + right) * factor, (height + bottom + top) * factor
    c = Canvas(str(out / name), pagesize=(w, h), pageCompression=1)
    c.setTrimBox((left * factor, bottom * factor, (left + width) * factor, (bottom + height) * factor))
    c.setFillColorCMYK(.8, .2, .1, .4)
    c.rect(0, 0, w, h, stroke=0, fill=1)
    c.setFillColorCMYK(0, 0, 0, 0)
    c.setFont('Poppins', 8 if quarter else 12)
    c.drawString((left + (20 if safe else 1)) * factor, (bottom + height / 2) * factor, 'Print sample')
    c.save()

fixture('A4_Brochure.pdf', 210, 297, (2, 2, 2, 2))
fixture('DL_Mailcard.pdf', 210, 99, (2, 2, 2, 2))
fixture('Business_Card.pdf', 90, 55, (2, 2, 2, 2))
fixture('600x450_Corflute.pdf', 600, 450, (2, 2, 2, 2), quarter=True)
fixture('6x4_Bannerwrap.pdf', 1832, 1220, (116, 116, 116, 116), quarter=True)
fixture('A4_Brochure_NoBleed.pdf', 210, 297, (0, 0, 0, 0))
fixture('A4_Brochure_Unsafe.pdf', 210, 297, (2, 2, 2, 2), safe=False)
fixture('Custom_Asymmetric.pdf', 210, 297, (2, 3, 4, 5))
fixture('Square_NoBleed.pdf', 600, 600, (0, 0, 0, 0), quarter=True)
print('Created nine independent print fixtures.')
