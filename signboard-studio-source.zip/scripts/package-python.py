"""Run after building python-frontend. Creates a self-contained developer ZIP."""
import pathlib,shutil,zipfile,hashlib,json
root=pathlib.Path(__file__).resolve().parents[1]; package=root/'python'; web=package/'web'
for path in (root/'public').iterdir():
    if path.name=='downloads': continue
    target=web/path.name
    if path.is_dir(): shutil.copytree(path,target,dirs_exist_ok=True)
    else: shutil.copy2(path,target)
# Render engine deployed to browser is byte-for-byte the server engine.
assert (root/'public/python/engine.py').read_bytes()==(package/'signboard_studio/engine.py').read_bytes()
source=package/'frontend-source'; source.mkdir(exist_ok=True)
for name in ['components','lib','python-frontend']:
    shutil.copytree(root/name,source/name,dirs_exist_ok=True)
(source/'app/edgewrap').mkdir(parents=True,exist_ok=True)
for name in ['globals.css','templates.css','edgewrap/page.tsx']:
    shutil.copy2(root/'app'/name,source/'app'/name)
for name in ['package.json','package-lock.json','postcss.config.mjs','tsconfig.json']:
    shutil.copy2(root/name,source/name)
# Include public assets once in web/. Frontend rebuild directions reuse them.
meta={'version':'1.0.0','engine_sha256':hashlib.sha256((package/'signboard_studio/engine.py').read_bytes()).hexdigest(),'python_dependencies':(package/'requirements.txt').read_text().splitlines()}
(package/'build-info.json').write_text(json.dumps(meta,indent=2))
output=root/'public/downloads/signboard-studio-python.zip';output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(package.rglob('*')):
        if not path.is_file() or any(p in {'data','__pycache__','.venv'} for p in path.relative_to(package).parts) or path.suffix=='.pyc': continue
        # The native Python server finalizes through installed Ghostscript.
        if path.relative_to(package).parts[:2] == ('web','print'): continue
        archive.write(path,'signboard-studio-python/'+str(path.relative_to(package)))
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'engine':meta['engine_sha256']}))
