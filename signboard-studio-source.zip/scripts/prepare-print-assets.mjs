import {mkdir,copyFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
await mkdir(new URL('public/print/',root),{recursive:true});
for(const name of ['gs.js','gs.wasm','LICENSE'])await copyFile(new URL('node_modules/@jspawn/ghostscript-wasm/'+name,root),new URL('public/print/'+name,root));
