import fs from 'node:fs';
import {PDFDocument} from 'pdf-lib';
import {analyseDesign,compileDesign,loadEngineAssets} from '../lib/template-engine';
import {detectDocument} from '../lib/document-setup';
import {optimisePdf} from '../lib/pdf-upload';
import {prepareSignboard} from '../lib/signboard-preparation';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const names=['6x4 Photo Signboard (1)(5).pdf','8 x 4(4).pdf','A4 Booklet 6 page Tri-Fold - Booklet     Celloglaze -(7).pdf','A5 Booklet 4 page - Booklet(5).pdf','A4     Doublesided(5).pdf','Just Listed DL One Agent (1)(4).pdf','photo signboard 6 x 4(6).pdf','just listed & SOLD LETTER(5).pdf'];
fs.mkdirSync('work/fixes',{recursive:true});const assets=await loadEngineAssets();
for(const number of process.argv.slice(2).map(Number)) {const name=names[number-1];let source=await optimisePdf(new Uint8Array(fs.readFileSync('../upload/'+name)),name);const count=(await PDFDocument.load(source)).getPageCount();for(let i=0;i<count;i++){const prefix=`work/fixes/${number}-${i+1}`;if(fs.existsSync(prefix+'.json'))continue;const setup=await detectDocument(source,name,i);if(number===7)setup.spec={...setup.spec,faceWidth:2440,faceHeight:1832,bleed:95,bleedInsets:undefined,resizeMode:'fit'};source=await prepareSignboard(source,i,setup.spec);const a=await analyseDesign(source,name,i,assets);a.spec={...setup.spec,productConfirmed:true,sizeConfirmed:true};const built=await compileDesign(source,a,name,assets);fs.writeFileSync(prefix+'.json',JSON.stringify(built.manifest));fs.writeFileSync(prefix+'.pdf',built.base);console.log('Prepared',number,i+1);}}
