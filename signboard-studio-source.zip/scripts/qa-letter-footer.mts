import fs from 'node:fs';import assert from 'node:assert/strict';import {spawnSync}from'node:child_process';
import {normalizeSavedTemplate}from'../lib/print-specs';import {evaluateTemplate,renderTemplate,loadEngineAssets}from'../lib/template-engine';import {defaultRichText}from'../lib/rich-text';import {groupRuns}from'../lib/content-groups';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets();fs.mkdirSync('work/builder-fixes',{recursive:true});
for(const prefix of ['8-1','5-2']){
 const t=normalizeSavedTemplate(JSON.parse(fs.readFileSync(`work/fixes/${prefix}.json`,'utf8'))),text:any={},content:any={};
 if(prefix==='8-1'){
  const g=t.groups!.find(g=>g.kind==='details'&&groupRuns(g,t.fields).some(f=>f.text.includes('Woodbury')))!;
  assert(g);const v=defaultRichText(g,groupRuns(g,t.fields));assert(v.inline?.address);
  const bad=evaluateTemplate(t,{},false,{[g.key]:{...v,text:'A replacement paragraph without the address.'}});assert(bad.errors.some(e=>e.includes('Keep {{address}}')));
  content[g.key]={...v,text:v.text.replace('delighted','pleased'),inline:{...v.inline,address:'12 Harbour Street, Mardi.'}};
  const second=t.groups!.find(x=>x.kind==='details'&&x.key!==g.key)!;assert(second);
 }else{
  const g=t.groups!.find(g=>g.kind==='agents')!;const formatting:any={};
  for(const f of groupRuns(g,t.fields)){text[f.id]=f.role.endsWith('name')?(f.role.startsWith('agent1')?'Alex Taylor':'Morgan Lee'):f.role.endsWith('phone')?(f.role.startsWith('agent1')?'0400 123 456':'0411 987 654'):(f.role.startsWith('agent1')?'alex@example.com':'morgan@example.com');formatting[f.id]=[];}
  content[g.key]={fieldFormatting:formatting};
 }
 const fit=evaluateTemplate(t,text,false,content);assert.deepEqual(fit.errors,[]);assert.deepEqual(fit.printIssues,[]);
 if(prefix==='8-1'){const all=fit.fields.map(f=>f.value).join(' ');assert(all.includes('12 Harbour Street, Mardi.'));assert(all.includes('If you know of anyone'));}
 else for(const n of [1,2]){const name=fit.fields.find(f=>f.role===`agent${n}_name`),email=fit.fields.find(f=>f.role===`agent${n}_email`),phone=fit.fields.find(f=>f.role===`agent${n}_phone`),original=t.fields.find(f=>f.role===`agent${n}_phone`)!;assert(Math.abs(name.x-email.x)<.01);assert(Math.abs(name.y-phone.y)<.01);assert(Math.abs(phone.x+phone.width-original.x-original.width)<.01);}
 const out=`work/builder-fixes/${prefix}`;fs.writeFileSync(out+'.json',JSON.stringify(t));fs.writeFileSync(out+'-job.json',JSON.stringify({mode:'print',text,content}));
 const py=spawnSync('python',['-c',"import sys,json;sys.path.insert(0,'public/python');import engine;t=json.load(open(sys.argv[1]));j=json.load(open(sys.argv[2]));_,f,_,_=engine.evaluate(t,j);print(json.dumps([{'id':x['id'],'x':x['x'],'value':x['value']} for x in f]))",out+'.json',out+'-job.json'],{encoding:'utf8'});assert.equal(py.status,0,py.stderr);const p=JSON.parse(py.stdout);for(const f of fit.fields){const q=p.find((x:any)=>x.id===f.id);assert(q);assert.equal(q.value,f.value);assert(Math.abs(q.x-f.x)<.02);}
 fs.writeFileSync(out+'.pdf',await renderTemplate(fs.readFileSync(`work/fixes/${prefix}.pdf`),t,text,false,assets,{},content));console.log(prefix,'JS/Python edited preview and address guard pass');
}
