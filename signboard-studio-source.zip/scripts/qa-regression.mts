import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';
import {evaluateTemplate,renderTemplate,loadEngineAssets} from '../lib/template-engine';
import {normalizeSavedTemplate} from '../lib/print-specs';import {contentGroups} from '../lib/content-groups';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets();const report=[];
for(const file of fs.readdirSync('work/fixes').filter(f=>/^\d-\d\.json$/.test(f)).sort()){
 const prefix='work/fixes/'+file.slice(0,-5),t=normalizeSavedTemplate(JSON.parse(fs.readFileSync(prefix+'.json','utf8')));t.groups=contentGroups(t);
 const text:any={},content:any={};
 for(const g of t.groups!){const fields=g.fieldIds.map(id=>t.fields.find(f=>f.id===id)!);
  if(['heading','address','details','text'].includes(g.kind)){
   let value=g.kind==='heading'?'Just\nSold':g.kind==='address'?(file==='6-1.json'?'12 Harbour Street, Mardi':'12 Forest Road\nKulnura'):g.kind==='details'?'A bright home with spacious rooms and a private garden. Close to local shops and transport.':fields[0].text.includes('Regards')?'Warm Regards,':fields[0].text.includes('Dear')?'Dear Neighbour,':fields.length>1?'Local home.':'Call today.';
   if(g.kind==='details'&&fields[0].text.startsWith('•'))value=fields.map(()=> '• New detail').join('\n');
   content[g.key]={rich:true,text:value,styles:[]};
  }else if(g.kind==='sale')content[g.key]={type:'auction',date:'2026-09-26',time:'13:30'};
  else if(g.kind==='viewing')content[g.key]={mode:'custom',text:file==='3-1.json'?'Sat 10:00':'Saturday 10:00-10:30',fieldFormatting:{[g.bindings!.text]:[]}};
  else if(g.kind==='features')content[g.key]={beds:'4',baths:'2',cars:'1'};
  else if(g.kind==='agency')content[g.key]={visible:true,phone:'02 9000 1234',contact:'qa@example.com',fieldFormatting:Object.fromEntries(fields.map(f=>[f.id,[]]))};
  else {const formatting:any={};for(const f of fields){text[f.id]=/@/.test(f.text)?'john@example.com':/^[+\d(][\d\s().-]{7,}$/.test(f.text.trim())?'0400 123 456':/^[MEPT]:?$/.test(f.text.trim())?'T:':/agent/i.test(f.text)?'Property Agent':/\d/.test(f.text)?'12 Garden Road':f.role.endsWith('name')?'John Lee':'Local Office';formatting[f.id]=[];}content[g.key]={fieldFormatting:formatting};}
 }
 const fit=evaluateTemplate(t,text,false,content);fs.writeFileSync(prefix+'-normalized.json',JSON.stringify(t));fs.writeFileSync(prefix+'-job.json',JSON.stringify({mode:'proof',text,content}));
 const py=spawnSync('python',['-c',"import sys,json;sys.path.insert(0,'public/python');import engine;t=json.load(open(sys.argv[1]));j=json.load(open(sys.argv[2]));\ntry:\n _,f,_,notes=engine.evaluate(t,j);print(json.dumps({'errors':[],'fields':[{'id':v['id'],'value':v['value'],'x':v['x'],'y':v['y'],'width':engine.text_width(v,v['value'],t)} for v in f]}))\nexcept Exception as e:print(json.dumps({'errors':[str(e)]}))",prefix+'-normalized.json',prefix+'-job.json'],{encoding:'utf8'});
 const result=JSON.parse(py.stdout);const row={file,jsErrors:fit.errors,pythonErrors:result.errors,printIssues:fit.printIssues};report.push(row);console.log(file,JSON.stringify(row));
 if(!fit.errors.length&&!result.errors.length){for(const f of fit.fields){const p=result.fields.find((p:any)=>p.id===f.id);assert(p,'Missing Python field '+f.id);assert.equal(p.value,f.value);assert(Math.abs(p.x-f.x)<.02,`${file}: x differs for ${f.id}`);}fs.writeFileSync(prefix+'-edited.pdf',await renderTemplate(fs.readFileSync(prefix+'.pdf'),t,text,false,assets,{},content));}
}
fs.writeFileSync('work/fixes/regression.json',JSON.stringify(report,null,2));
