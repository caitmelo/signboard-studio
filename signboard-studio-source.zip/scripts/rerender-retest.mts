import fs from 'node:fs';
import {loadEngineAssets,renderTemplate} from '../lib/template-engine';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
const assets=await loadEngineAssets();
for(const r of JSON.parse(fs.readFileSync('work/retest/report.json','utf8'))){const p=r.prefix,t=JSON.parse(fs.readFileSync(p+'-manifest.json','utf8')),j=JSON.parse(fs.readFileSync(p+'-job.json','utf8'));fs.writeFileSync(p+'-edited.pdf',await renderTemplate(fs.readFileSync(p+'-base.pdf'),t,j.text,false,assets,{},j.content));console.log(r.name,r.page);}
