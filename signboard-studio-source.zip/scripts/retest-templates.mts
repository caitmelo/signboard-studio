import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {extendPaperBleed,requiresPaperBleed} from '../lib/paper-bleed';
import {documentColour} from '../lib/document-colour';
import {PDFDocument} from 'pdf-lib';
import {analyseDesign,compileDesign,evaluateTemplate,loadEngineAssets,renderTemplate} from '../lib/template-engine';
import {detectDocument} from '../lib/document-setup';
import {optimisePdf} from '../lib/pdf-upload';
import {prepareSignboard} from '../lib/signboard-preparation';
import {exportScale} from '../lib/print-specs';
globalThis.fetch=async(input:any)=>{const p='public'+new URL(String(input),'https://test.local').pathname;return fs.existsSync(p)?new Response(fs.readFileSync(p)):new Response('',{status:404});};
// Runs against the user's attached test set; writes proof outputs, never labels preflight failures print-ready.
fs.mkdirSync('work/retest',{recursive:true});const assets=await loadEngineAssets(),report:any[]=[];
const files=fs.readdirSync('../upload').filter(n=>n.endsWith('.pdf')&&!n.startsWith('1809')&&!n.startsWith('1 ('));
for(const name of files){try{let source=(await optimisePdf(new Uint8Array(fs.readFileSync('../upload/'+name)),name));const doc=await PDFDocument.load(source);
for(let i=0;i<doc.getPageCount();i++){const setup=await detectDocument(source,name,i);source=await prepareSignboard(source,i,setup.spec);
if(requiresPaperBleed(setup.spec)){
 fs.writeFileSync('work/retest/bleed-input.pdf',source);
 const rendered=spawnSync('python',['-c',"import fitz,json,sys;from PIL import Image;d=fitz.open('work/retest/bleed-input.pdf');p=d[int(sys.argv[1])].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);im=Image.frombytes('RGB',(p.width,p.height),p.samples).convert('RGBA');open('work/retest/bleed.rgba','wb').write(im.tobytes());print(json.dumps({'width':p.width,'height':p.height}))",String(i)],{encoding:'utf8'});if(rendered.status!==0)throw Error(rendered.stderr);
 const raster={...JSON.parse(rendered.stdout),data:fs.readFileSync('work/retest/bleed.rgba')},colour=await documentColour(source);source=await extendPaperBleed(source,i,setup.spec,raster,colour?.table??assets.table);setup.spec.sourceIncludesBleed=true;
}
const a=await analyseDesign(source,name,i,assets);a.spec={...setup.spec,productConfirmed:true,sizeConfirmed:true};const built=await compileDesign(source,a,name,assets),t=built.manifest;const values=Object.fromEntries(t.fields.filter(f=>f.role==='agent1_name'||f.role==='agent1_phone').map(f=>[f.id,f.role==='agent1_name'?'Caitlin Micallef':'0449 754 440']));const content:any={};for(const g of t.groups??[]){if(g.kind==='sale')content[g.key]={type:'auction',date:'2026-09-10',time:'12:00'};if(g.kind==='features')content[g.key]={beds:'1',baths:'1',cars:'1'};if(g.kind==='heading')content[g.key]='Just Sold';}
const initial=evaluateTemplate(t,{},false),edited=evaluateTemplate(t,values,false,content),prefix='work/retest/'+report.length;const row:any={name,page:i+1,groups:t.groups?.map(g=>({kind:g.kind,text:g.fieldIds.map(id=>t.fields.find(f=>f.id===id)?.text).join(' | ')})),photos:t.media?.filter(m=>m.role==='image').length,initialErrors:initial.errors,editedErrors:edited.errors,printIssues:[...t.printIssues,...edited.printIssues],spec:t.spec,prefix};fs.writeFileSync(prefix+'-manifest.json',JSON.stringify(t));fs.writeFileSync(prefix+'-base.pdf',built.base);fs.writeFileSync(prefix+'-job.json',JSON.stringify({mode:'proof',text:values,content}));if(edited.valid){const pdf=await renderTemplate(built.base,t,values,false,assets,{},content);fs.writeFileSync(prefix+'-edited.pdf',pdf);const out=(await PDFDocument.load(pdf)).getPage(0),trim=out.getTrimBox(),scale=exportScale(t.spec);row.dimensionsPass=Math.abs(trim.width*25.4/72-t.spec.faceWidth*scale)<.05&&Math.abs(trim.height*25.4/72-t.spec.faceHeight*scale)<.05;}
report.push(row);fs.writeFileSync('work/retest/report.json',JSON.stringify(report,null,2));console.log(name,i+1,'initial',initial.errors.length,'edited',edited.errors.length,'print',row.printIssues.length);}}
catch(e){report.push({name,error:String(e)});console.log(name,String(e));fs.writeFileSync('work/retest/report.json',JSON.stringify(report,null,2));}}
