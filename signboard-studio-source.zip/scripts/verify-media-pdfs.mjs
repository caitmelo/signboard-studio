// Independent raster/QR verification of generated PDFs, separate from the renderer.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {decode} from 'fast-png';
import jsQR from 'jsqr';
const expected={'photo-with-media':'https://example.com/property/updated','photo-marked-qr':'https://example.com/marked','photo-api':'https://example.com/property/api','photo-rounded-qr':'https://example.com/rounded'};
execFileSync('python',['-c',`import fitz,json
m=json.load(open('work/photo-manifest.json'))
s=next(s for s in m['media'] if s['role']=='qr')
for name in ${JSON.stringify(Object.keys(expected))}:
 d=fitz.open('work/'+name+'.pdf');p=d[0];scale=p.rect.width/m['sourceWidth']
 rect=fitz.Rect(s['x']*scale,(m['sourceHeight']-s['y']-s['height'])*scale,(s['x']+s['width'])*scale,(m['sourceHeight']-s['y'])*scale)
 p.get_pixmap(matrix=fitz.Matrix(800/rect.width,800/rect.width),clip=rect,alpha=False).save('work/'+name+'-qr.png')
`]);
for(const[name,url]of Object.entries(expected)){
 const p=decode(fs.readFileSync(`work/${name}-qr.png`));assert.equal(p.channels,3);const data=new Uint8ClampedArray(p.width*p.height*4);
 for(let i=0;i<p.width*p.height;i++)data.set([p.data[i*3],p.data[i*3+1],p.data[i*3+2],255],i*4);
 assert.equal(jsQR(data,p.width,p.height)?.data,url,`${name}: final PDF QR must decode to the requested link`);
}
console.log('PASS: regenerated image-slot QR, marked-region QR and API QR independently scan from the final PDFs.');
