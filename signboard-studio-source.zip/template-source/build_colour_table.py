"""Build the sRGB → original SWOP CMYK interpolation table using LittleCMS."""
from pathlib import Path
from PIL import Image, ImageCms

root = Path(__file__).resolve().parent.parent
source = ImageCms.createProfile('sRGB')
target = ImageCms.getOpenProfile(str(root / 'template-source/source-swop.icc'))
transform = ImageCms.buildTransformFromOpenProfiles(source, target, 'RGB', 'CMYK', renderingIntent=0)
samples = Image.new('RGB', (33 * 33, 33))
samples.putdata([(round(r * 255 / 32), round(g * 255 / 32), round(b * 255 / 32))
                 for r in range(33) for g in range(33) for b in range(33)])
table = ImageCms.applyTransform(samples, transform).tobytes()
assert len(table) == 33 ** 3 * 4
(root / 'public/template/rgb-to-cmyk-33.bin').write_bytes(table)
print(f'Wrote {len(table)} CMYK lookup bytes.')
