"""Regenerate the portable template asset. Requires Ghostscript and the PDF Python tools.
The font outlines are Poppins SemiBold from Fontsource 5.3.0, verified against the reference.
No fonts or PDF tooling are needed by the deployed renderer.
"""
from pathlib import Path
import base64, io, json, os, re, subprocess
from fontTools.ttLib import TTFont
from fontTools.pens.reportLabPen import ReportLabPen
from fontTools.pens.boundsPen import BoundsPen
from reportlab.pdfgen.pathobject import PDFPathObject
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'template-source'
WORK = ROOT / 'work'
WORK.mkdir(exist_ok=True)
OUT = ROOT / 'public/template'
OUT.mkdir(parents=True, exist_ok=True)
palette = [[.796,.675,.459,.337],[.734,.013,.297,0],[.76,0,.3,0],[.478,.404,.275,.204],[0,1,1,0],[0,0,0,0]]
subprocess.run(['gs','-q','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=pdfwrite','-dCompatibilityLevel=1.3','-dNoOutputFonts','-sColorConversionStrategy=CMYK','-dProcessColorModel=/DeviceCMYK',f'-sDefaultCMYKProfile={SOURCE}/source-swop.icc',f'-sOutputICCProfile={SOURCE}/source-swop.icc',f'-sOutputFile={WORK}/static-outlined.pdf',str(SOURCE/'static-quarter-source.pdf')],check=True,env={**os.environ,'TMPDIR':str(WORK)})
page = PdfReader(WORK/'static-outlined.pdf').pages[0]
assert list(page['/Resources'].keys()) == ['/ProcSet'], page['/Resources']
commands = page.get_contents().get_data().decode('ascii')
def restore(m):
    color=list(map(float,m.group(1).split()))
    nearest=min(palette,key=lambda p:sum((a-b)**2 for a,b in zip(color,p)))
    assert max(abs(a-b) for a,b in zip(color,nearest)) < .002
    return ' '.join(str(c) for c in nearest)+' k'
commands = re.sub(r'([-\d.]+\s+[-\d.]+\s+[-\d.]+\s+[-\d.]+)\s+k\b',restore,commands)
assert not re.search(r'\b(?:rg|RG|Do|Tf)\b',commands)

class OutlinePen(ReportLabPen):
    def _closePath(self): self.path.close()

glyphs={}
for filename in ['Poppins-SemiBold-latin-ext.woff','Poppins-SemiBold-latin.woff']:
    font=TTFont(SOURCE/filename)
    glyphset=font.getGlyphSet()
    for codepoint, name in font.getBestCmap().items():
        # Input is a single horizontal Latin line. Exclude control/combining characters.
        import unicodedata
        category=unicodedata.category(chr(codepoint))
        if category[0] in ['C','M'] or category.startswith('Z') and codepoint not in [32,160]: continue
        glyph=glyphset[name]
        bounds=BoundsPen(glyphset);glyph.draw(bounds)
        pen=OutlinePen(glyphset,PDFPathObject());glyph.draw(pen)
        glyphs[str(codepoint)]={'advance':glyph.width,'path':pen.path.getCode() if bounds.bounds else '', 'bounds':bounds.bounds}

data={'id':'stone-6x4-edgewrap-v1','version':1,'staticCommands':commands,'iccBase64':base64.b64encode((SOURCE/'source-swop.icc').read_bytes()).decode(),'unitsPerEm':1000,'glyphs':glyphs}
(OUT/'edgewrap.json').write_text(json.dumps(data,separators=(',',':')))
print(json.dumps({'glyphs':len(glyphs),'static_bytes':len(commands),'asset_bytes':(OUT/'edgewrap.json').stat().st_size}))
